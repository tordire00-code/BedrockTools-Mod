// Zaphkiel Panel v6 - RE control surface (file-bridge)
//   v6: smart verb buttons, copy-to-clipboard (JNI, file fallback), keyboard fix (< > 0x, symbols page)
//   Panel engine ko kabhi nahi chhuta: zinput.txt likhta hai, result files padhta hai.
//   Control: launcher Mod Menu (Scale / Opacity / Pos X / Pos Y). Panel board locked hai.
//   Base = v4 (official pl::input callbacks + EGL swap hook), SDK 'main' (ABI fix).
#include <jni.h>
#include <android/input.h>
#include <android/keycodes.h>
#include <android/log.h>
#include <EGL/egl.h>
#include <pthread.h>
#include <unistd.h>
#include <dlfcn.h>
#include <sys/stat.h>

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cfloat>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <memory>
#include <mutex>
#include <string>
#include <string_view>
#include <thread>
#include <type_traits>
#include <vector>

#include <pl/Mod.hpp>
#include <pl/ModMenu.hpp>
#include <pl/Input.hpp>
#include <pl/Logger.hpp>
#include <pl/memory/Hook.hpp>

#include "ImGui/imgui.h"
#include "ImGui/backends/imgui_impl_android.h"
#include "ImGui/backends/imgui_impl_opengl3.h"

#define TAG "PanelMod"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)

namespace {

constexpr std::string_view kModuleId = "panelmod.main";

// ------------------------------------------------------------ paths (yahan edit karo)
#ifndef PANEL_ROOT
#define PANEL_ROOT "/storage/emulated/0/Android/media/org.levimc.launcher/"
#endif
const char* kKurumiDir = PANEL_ROOT "kurumi/";   // engine ka ghar
const char* kHomeDir   = PANEL_ROOT "levire/";   // panel ka apna ghar
// Device pe dikhi file 'zinput.txt' hai (13 bytes, engine ne chalaya). Qwen ke doc me 'input.txt' likha tha - galat.
const char* kInputName = "zinput.txt";
const char* kFontCandidates[] = {
    "/system/fonts/Roboto-Regular.ttf",
    "/system/fonts/RobotoStatic-Regular.ttf",
    "/system/fonts/NotoSans-Regular.ttf",
    "/system/fonts/DroidSans.ttf",
};

enum FileId { F_OUT, F_LOG, F_RTTI, F_VT, F_DYN, F_SIG, F_CFG, F_COUNT };
const char* kFileNames[F_COUNT] = {
    "zaphkiel_out.txt", "zaphkiel_log.txt", "rtti_dump.txt", "vtable_dump.txt",
    "dynsym_dump.txt", "signatures.txt", "zaphkiel_config.txt",
};
const size_t kFileTail[F_COUNT] = {
    256 * 1024, 64 * 1024, 512 * 1024, 512 * 1024, 256 * 1024, 256 * 1024, 32 * 1024,
};

constexpr float kMinScale = 0.8f, kMaxScale = 2.5f;
constexpr float kBaseW = 780.0f, kBaseH = 520.0f;   // window px at scale 1.0
constexpr float kScreenFrac = 0.96f;
constexpr int   kSilentSecs = 45;                   // engine slow hai => lamba intezaar

// ------------------------------------------------------------ theme (3 eye-comfort colors)
const ImVec4 C_BG    (0.133f, 0.125f, 0.114f, 1.0f);   // #22201D
const ImVec4 C_BG2   (0.165f, 0.157f, 0.145f, 1.0f);
const ImVec4 C_TEXT  (0.918f, 0.902f, 0.867f, 1.0f);   // #EAE6DD
const ImVec4 C_ACC   (0.561f, 0.737f, 0.561f, 1.0f);   // #8FBC8F
const ImVec4 C_ACC_H (0.639f, 0.796f, 0.639f, 1.0f);
const ImVec4 C_ACC_A (0.435f, 0.627f, 0.435f, 1.0f);
const ImVec4 C_BORDER(0.227f, 0.216f, 0.200f, 1.0f);
const ImVec4 C_TITLE (0.106f, 0.102f, 0.094f, 1.0f);
const ImVec4 C_DARKTXT(0.10f, 0.12f, 0.10f, 1.0f);
const ImVec4 C_GREY  (0.62f, 0.60f, 0.56f, 1.0f);
const ImVec4 C_AMBER (0.95f, 0.75f, 0.30f, 1.0f);
const ImVec4 C_RED   (0.90f, 0.45f, 0.35f, 1.0f);

// ------------------------------------------------------------ state
std::atomic_bool g_Visible{false};
std::atomic_bool g_Initialized{false};
std::atomic_bool g_ResetInput{false};
std::atomic_bool g_WantText{false};
std::atomic_bool g_RefreshNow{true};
// mod menu sliders (menu thread -> render thread)
std::atomic<float> g_TargetScale{1.4f};
std::atomic<float> g_Opacity{0.95f};
std::atomic<float> g_PosXPct{4.0f};
std::atomic<float> g_PosYPct{6.0f};
std::atomic<float> g_RectX{0}, g_RectY{0}, g_RectW{0}, g_RectH{0};

// render-thread only
float g_AppliedScale = -1.0f;
double g_LastRebuild = 0.0, g_LastSave = 0.0, g_LastAuto = 0.0;
bool  g_DeviceReady = false;
int   g_Section = 0;
bool  g_KbOpen = false, g_KbShift = false;
char  g_Status[360] = "Ready";

int g_Width = 0, g_Height = 0;
EGLContext g_TargetContext = EGL_NO_CONTEXT;
EGLSurface g_TargetSurface = EGL_NO_SURFACE;

// text buffers
char g_ZInput[8192] = "";
char g_Notes[8192]  = "";
char g_QuickCmd[256] = "";
char g_Filt[5][128] = {};
char g_Arg[128] = "", g_Extra[64] = "";   // smart builder (Terminal + Tools me shared)
bool g_BuilderAdd = false, g_KbSym = false;
std::vector<std::string> g_Pins;
std::string g_LastWs, g_LastNotes;
int g_RunsSent = 0, g_LastCmds = 0;

// on-screen keyboard target
char*       g_KbTarget = nullptr;
size_t      g_KbSize = 0;
const char* g_KbName = "-";

using SwapFn = EGLBoolean (*)(EGLDisplay, EGLSurface);
SwapFn g_OrigSwap = nullptr;
pl::memory::HookHandle g_SwapHook;

double nowSec() {
    using namespace std::chrono;
    return duration_cast<duration<double>>(steady_clock::now().time_since_epoch()).count();
}
void setStatus(const char* s) { std::snprintf(g_Status, sizeof(g_Status), "%s", s); }
void setStatusf(const char* fmt, const char* a) { std::snprintf(g_Status, sizeof(g_Status), fmt, a); }
std::string clockStr() {
    time_t t = time(nullptr); struct tm tmv; localtime_r(&t, &tmv);
    char b[16]; std::snprintf(b, sizeof(b), "%02d:%02d:%02d", tmv.tm_hour, tmv.tm_min, tmv.tm_sec);
    return b;
}

// ------------------------------------------------------------ files
bool readFile(const std::string& path, std::string& out) {
    FILE* f = std::fopen(path.c_str(), "rb");
    if (!f) return false;
    char buf[4096]; size_t n;
    out.clear();
    while ((n = std::fread(buf, 1, sizeof(buf), f)) > 0) out.append(buf, n);
    std::fclose(f);
    return true;
}
bool readTail(const std::string& path, std::string& out, size_t maxBytes) {
    FILE* f = std::fopen(path.c_str(), "rb");
    if (!f) return false;
    std::fseek(f, 0, SEEK_END);
    long sz = std::ftell(f);
    long start = sz > (long)maxBytes ? sz - (long)maxBytes : 0;
    std::fseek(f, start, SEEK_SET);
    out.resize((size_t)(sz - start));
    size_t n = out.empty() ? 0 : std::fread(&out[0], 1, out.size(), f);
    out.resize(n);
    std::fclose(f);
    if (start > 0) out.insert(0, "...(purana hissa hata diya)...\n");
    return true;
}
bool writeFile(const std::string& path, const char* data, size_t len) {
    FILE* f = std::fopen(path.c_str(), "wb");
    if (!f) return false;
    std::fwrite(data, 1, len, f);
    std::fclose(f);
    return true;
}

// ------------------------------------------------------------ clipboard (JNI) - fail ho to levire/copy.txt
std::string jniSafe(const std::string& in) {   // NewStringUTF modified-UTF8 maangta hai: sirf safe ASCII bhejo
    std::string o; o.reserve(in.size());
    for (unsigned char c : in) {
        if (c == '\n' || c == '\t') o.push_back((char)c);
        else if (c >= 32 && c < 127) o.push_back((char)c);
        else if (c == '\r') { }
        else o.push_back('?');
    }
    return o;
}

JavaVM* g_JVM = nullptr;
JavaVM* findJvm() {
    typedef jint (*GetVMsFn)(JavaVM**, jsize, jsize*);
    GetVMsFn fn = (GetVMsFn)dlsym(RTLD_DEFAULT, "JNI_GetCreatedJavaVMs");
    if (!fn) {
        const char* libs[] = { "libnativehelper.so", "libart.so" };
        for (const char* l : libs) {
            void* h = dlopen(l, RTLD_NOW);
            if (h) fn = (GetVMsFn)dlsym(h, "JNI_GetCreatedJavaVMs");
            if (fn) break;
        }
    }
    if (!fn) return nullptr;
    JavaVM* vms[4] = { nullptr, nullptr, nullptr, nullptr };
    jsize n = 0;
    if (fn(vms, 4, &n) != JNI_OK || n < 1) return nullptr;
    return vms[0];
}

bool jniCopy(const std::string& text, std::string& err) {
    if (!g_JVM) g_JVM = findJvm();
    if (!g_JVM) { err = "JavaVM nahi mila"; return false; }
    JNIEnv* env = nullptr;
    bool attached = false;
    const jint r = g_JVM->GetEnv((void**)&env, JNI_VERSION_1_6);
    if (r == JNI_EDETACHED) {
        if (g_JVM->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) { err = "thread attach fail"; return false; }
        attached = true;
    } else if (r != JNI_OK || !env) { err = "GetEnv fail"; return false; }

    bool ok = false;
    env->PushLocalFrame(48);
#define JCHK(msg) if (env->ExceptionCheck()) { env->ExceptionClear(); err = msg; break; }
    do {
        jclass at = env->FindClass("android/app/ActivityThread");               JCHK("ActivityThread class") if (!at) { err = "ActivityThread null"; break; }
        jmethodID cur = env->GetStaticMethodID(at, "currentApplication", "()Landroid/app/Application;"); JCHK("currentApplication") if (!cur) { err = "currentApplication null"; break; }
        jobject app = env->CallStaticObjectMethod(at, cur);                     JCHK("currentApplication call") if (!app) { err = "Application null"; break; }
        jclass ctx = env->FindClass("android/content/Context");                 JCHK("Context class")
        jmethodID gss = env->GetMethodID(ctx, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;"); JCHK("getSystemService")
        jstring svc = env->NewStringUTF("clipboard");
        jobject mgr = env->CallObjectMethod(app, gss, svc);                     JCHK("clipboard service") if (!mgr) { err = "ClipboardManager null"; break; }
        jclass cd = env->FindClass("android/content/ClipData");                 JCHK("ClipData class")
        jmethodID np = env->GetStaticMethodID(cd, "newPlainText", "(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;"); JCHK("newPlainText")
        jstring label = env->NewStringUTF("Zaphkiel");
        jstring body = env->NewStringUTF(text.c_str());
        jobject clip = env->CallStaticObjectMethod(cd, np, label, body);        JCHK("newPlainText call") if (!clip) { err = "ClipData null"; break; }
        jclass cm = env->FindClass("android/content/ClipboardManager");         JCHK("ClipboardManager class")
        jmethodID spc = env->GetMethodID(cm, "setPrimaryClip", "(Landroid/content/ClipData;)V"); JCHK("setPrimaryClip")
        env->CallVoidMethod(mgr, spc, clip);                                    JCHK("setPrimaryClip call")
        ok = true;
    } while (false);
#undef JCHK
    env->PopLocalFrame(nullptr);
    if (attached) g_JVM->DetachCurrentThread();
    return ok;
}

void doCopy(const std::string& raw, const char* what) {
    if (raw.empty()) { setStatus("Copy karne ko kuch nahi"); return; }
    std::string text = jniSafe(raw);
    const size_t cap = 150 * 1024;      // binder limit ~1MB; safe cap
    const bool capped = text.size() > cap;
    if (capped) text.resize(cap);
    std::string err;
    const unsigned kb = (unsigned)((text.size() + 1023) / 1024);
    if (jniCopy(text, err)) {
        std::snprintf(g_Status, sizeof(g_Status), "Copy ho gaya: %s (%u KB%s)", what, kb, capped ? ", cap 150KB" : "");
    } else {
        mkdir(kHomeDir, 0777);
        const bool w = writeFile(std::string(kHomeDir) + "copy.txt", text.data(), text.size());
        std::snprintf(g_Status, sizeof(g_Status), "Clipboard fail (%s) -> %s", err.c_str(),
                      w ? "levire/copy.txt me likha" : "file bhi nahi likhi");
        LOGW("clipboard fail: %s", err.c_str());
    }
}

// ------------------------------------------------------------ line documents (bg thread builds, render thread reads)
struct Doc {
    std::string text;
    std::vector<uint32_t> starts;
    size_t longest = 0;
    int lines() const { return (int)starts.size(); }
    const char* lb(int i) const { return text.data() + starts[i]; }
    const char* le(int i) const {
        size_t e = (i + 1 < (int)starts.size()) ? starts[i + 1] - 1 : text.size();
        if (e > starts[i] && text[e - 1] == '\r') --e;
        if (i + 1 == (int)starts.size() && e > starts[i] && text[e - 1] == '\n') --e;
        return text.data() + e;
    }
};
std::shared_ptr<const Doc> makeDoc(std::string&& s) {
    auto d = std::make_shared<Doc>();
    d->text = std::move(s);
    if (!d->text.empty()) {
        d->starts.push_back(0);
        for (size_t i = 0; i < d->text.size(); ++i)
            if (d->text[i] == '\n' && i + 1 < d->text.size()) d->starts.push_back((uint32_t)(i + 1));
        size_t best = 0;
        for (int i = 0; i < d->lines(); ++i) {
            size_t len = (size_t)(d->le(i) - d->lb(i));
            if (len > best) { best = len; d->longest = (size_t)i; }
        }
    }
    return d;
}

struct Snap {
    std::shared_ptr<const Doc> d[F_COUNT];
    time_t inMt = 0, logMt = 0;
    bool logDone = false;
};
std::mutex g_Mx;
Snap g_Snap;

// ------------------------------------------------------------ persistence (levire/)
void saveConfig() {
    mkdir(kHomeDir, 0777);
    char b[400];
    std::snprintf(b, sizeof(b), "scale=%f\nopacity=%f\nposx=%f\nposy=%f\nsection=%d\n",
                  g_TargetScale.load(), g_Opacity.load(), g_PosXPct.load(), g_PosYPct.load(), g_Section);
    writeFile(std::string(kHomeDir) + "panel.cfg", b, std::strlen(b));
}
void loadConfig() {
    std::string s;
    if (!readFile(std::string(kHomeDir) + "panel.cfg", s)) return;
    size_t i = 0;
    while (i < s.size()) {
        size_t e = s.find('\n', i);
        if (e == std::string::npos) e = s.size();
        std::string line = s.substr(i, e - i);
        i = e + 1;
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string k = line.substr(0, eq);
        float v = (float)std::atof(line.c_str() + eq + 1);
        if (k == "scale" && v >= kMinScale && v <= kMaxScale) g_TargetScale = v;
        else if (k == "opacity" && v >= 0.2f && v <= 1.0f) g_Opacity = v;
        else if (k == "posx" && v >= 0 && v <= 100) g_PosXPct = v;
        else if (k == "posy" && v >= 0 && v <= 100) g_PosYPct = v;
        else if (k == "section" && v >= 0 && v <= 9) g_Section = (int)v;
    }
}

const char* kPinMarker = "=====PINS=====";
std::string serializeNotes() {
    std::string s = g_Notes;
    s += "\n"; s += kPinMarker; s += "\n";
    for (auto& p : g_Pins) { s += p; s += "\n"; }
    return s;
}
void loadNotes() {
    std::string s;
    if (!readFile(std::string(kHomeDir) + "notes.txt", s)) return;
    size_t m = s.find(kPinMarker);
    std::string free = s.substr(0, m);
    while (!free.empty() && free.back() == '\n') free.pop_back();
    std::snprintf(g_Notes, sizeof(g_Notes), "%s", free.c_str());
    g_Pins.clear();
    if (m != std::string::npos) {
        size_t i = s.find('\n', m);
        while (i != std::string::npos && i + 1 < s.size()) {
            size_t e = s.find('\n', i + 1);
            if (e == std::string::npos) e = s.size();
            if (e > i + 1) g_Pins.push_back(s.substr(i + 1, e - i - 1));
            i = e;
        }
    }
    g_LastNotes = serializeNotes();
}
void autosave() {   // render thread, 2s debounce, sirf badla ho tab
    const double t = nowSec();
    if (t - g_LastAuto < 2.0) return;
    g_LastAuto = t;
    mkdir(kHomeDir, 0777);
    std::string ws = g_ZInput;
    if (ws != g_LastWs) { writeFile(std::string(kHomeDir) + "workspace.txt", ws.data(), ws.size()); g_LastWs = ws; }
    std::string nt = serializeNotes();
    if (nt != g_LastNotes) { writeFile(std::string(kHomeDir) + "notes.txt", nt.data(), nt.size()); g_LastNotes = nt; }
}

// ------------------------------------------------------------ input queue (input thread -> render thread)
struct InEv {
    enum Type { Pos, Btn, Char, KeyDown, KeyUp } type;
    float x = 0, y = 0;
    bool down = false;
    unsigned int ch = 0;
    int code = 0;
};
std::mutex g_QMutex;
std::vector<InEv> g_Queue;
std::vector<int> g_ToRelease;

void pushEv(const InEv& e) {
    std::lock_guard<std::mutex> l(g_QMutex);
    if (g_Queue.size() < 512) g_Queue.push_back(e);
}
bool insideRect(float x, float y) {
    const float m = 6.0f;
    const float rw = g_RectW.load(), rh = g_RectH.load();
    if (rw <= 0 || rh <= 0) return false;
    const float rx = g_RectX.load(), ry = g_RectY.load();
    return x >= rx - m && x <= rx + rw + m && y >= ry - m && y <= ry + rh + m;
}

int  g_Follow = -1;
bool g_Owned = false;

bool onTouch(const pl::input::TouchEvent& e) {
    static std::atomic_bool logged{false};
    if (!logged.exchange(true)) LOGI("touch callback: alive");
    if (!g_Visible.load() || !g_Initialized.load()) { g_Follow = -1; g_Owned = false; return false; }
    const int act = e.action & 0xFF;
    const bool isDown = (act == AMOTION_EVENT_ACTION_DOWN || act == AMOTION_EVENT_ACTION_POINTER_DOWN);
    const bool isUp   = (act == AMOTION_EVENT_ACTION_UP || act == AMOTION_EVENT_ACTION_POINTER_UP ||
                         act == AMOTION_EVENT_ACTION_CANCEL);
    const bool isMove = (act == AMOTION_EVENT_ACTION_MOVE);
    if (isDown && g_Follow == -1) {
        g_Follow = e.pointerId;
        g_Owned = insideRect(e.x, e.y);
        InEv p; p.type = InEv::Pos; p.x = e.x; p.y = e.y; pushEv(p);
        InEv b; b.type = InEv::Btn; b.down = true; pushEv(b);
        return g_Owned;
    }
    if (e.pointerId != g_Follow) return false;
    if (isMove) { InEv p; p.type = InEv::Pos; p.x = e.x; p.y = e.y; pushEv(p); return g_Owned; }
    if (isUp) {
        InEv p; p.type = InEv::Pos; p.x = e.x; p.y = e.y; pushEv(p);
        InEv b; b.type = InEv::Btn; b.down = false; pushEv(b);
        const bool owned = g_Owned;
        g_Follow = -1; g_Owned = false;
        return owned;
    }
    return false;
}

bool isSystemKey(int k) {
    return k == AKEYCODE_BACK || k == AKEYCODE_HOME || k == AKEYCODE_POWER || k == AKEYCODE_APP_SWITCH ||
           k == AKEYCODE_VOLUME_UP || k == AKEYCODE_VOLUME_DOWN || k == AKEYCODE_VOLUME_MUTE;
}
bool isEditKey(int k) {
    return k == AKEYCODE_DEL || k == AKEYCODE_FORWARD_DEL || k == AKEYCODE_ENTER || k == AKEYCODE_NUMPAD_ENTER ||
           k == AKEYCODE_DPAD_LEFT || k == AKEYCODE_DPAD_RIGHT || k == AKEYCODE_DPAD_UP || k == AKEYCODE_DPAD_DOWN ||
           k == AKEYCODE_MOVE_HOME || k == AKEYCODE_MOVE_END || k == AKEYCODE_TAB;
}
bool onKey(const pl::input::KeyEvent& e) {   // sirf hardware/BT keyboard ke liye
    if (!g_Visible.load() || !g_Initialized.load() || !g_WantText.load()) return false;
    if (isSystemKey(e.keyCode)) return false;
    if (e.isKeyDown && e.unicodeChar >= 32 && e.unicodeChar != 127) {
        InEv c; c.type = InEv::Char; c.ch = e.unicodeChar; pushEv(c);
    }
    if (isEditKey(e.keyCode) && e.keyCode >= 0 && e.keyCode < 512) {
        InEv k; k.type = e.isKeyDown ? InEv::KeyDown : InEv::KeyUp; k.code = e.keyCode; pushEv(k);
    }
    return true;
}
void flushInput(ImGuiIO& io) {
    for (int c : g_ToRelease) if (c >= 0 && c < 512) io.KeysDown[c] = false;
    g_ToRelease.clear();
    std::vector<InEv> q;
    { std::lock_guard<std::mutex> l(g_QMutex); q.swap(g_Queue); }
    for (const InEv& e : q) {
        switch (e.type) {
            case InEv::Pos:     io.AddMousePosEvent(e.x, e.y); break;
            case InEv::Btn:     io.AddMouseButtonEvent(0, e.down); break;
            case InEv::Char:    io.AddInputCharacter(e.ch); break;
            case InEv::KeyDown: io.KeysDown[e.code] = true; break;
            case InEv::KeyUp:   g_ToRelease.push_back(e.code); break;
        }
    }
}

// ------------------------------------------------------------ font + style
void applyFontAndStyle(float scale, bool rebuildTex) {
    ImGuiIO& io = ImGui::GetIO();
    if (rebuildTex) ImGui_ImplOpenGL3_DestroyFontsTexture();
    io.Fonts->Clear();
    ImFontConfig fc;
    fc.OversampleH = 2; fc.OversampleV = 2;
    ImFont* font = nullptr;
    for (const char* path : kFontCandidates) {
        if (access(path, R_OK) != 0) continue;
        font = io.Fonts->AddFontFromFileTTF(path, 20.0f * scale, &fc);
        if (font) break;
    }
    if (!font) { fc.SizePixels = 13.0f * scale * 1.6f; io.Fonts->AddFontDefault(&fc); }
    if (rebuildTex) ImGui_ImplOpenGL3_CreateFontsTexture();

    ImGuiStyle& st = ImGui::GetStyle();
    st = ImGuiStyle();
    st.ScaleAllSizes(scale);
    st.WindowRounding = 8; st.ChildRounding = 6; st.FrameRounding = 5; st.GrabRounding = 4;
    st.ScrollbarSize = 14.0f * scale;
    st.GrabMinSize = 20.0f * scale;
    st.TouchExtraPadding = ImVec2(4, 4);
    ImVec4* c = st.Colors;
    c[ImGuiCol_Text] = C_TEXT;
    c[ImGuiCol_TextDisabled] = C_GREY;
    c[ImGuiCol_WindowBg] = C_BG;
    c[ImGuiCol_ChildBg] = C_BG2;
    c[ImGuiCol_PopupBg] = C_BG2;
    c[ImGuiCol_Border] = C_BORDER;
    c[ImGuiCol_FrameBg] = ImVec4(0.20f, 0.19f, 0.175f, 1);
    c[ImGuiCol_FrameBgHovered] = ImVec4(0.24f, 0.23f, 0.21f, 1);
    c[ImGuiCol_FrameBgActive] = ImVec4(0.28f, 0.27f, 0.25f, 1);
    c[ImGuiCol_TitleBg] = C_TITLE;
    c[ImGuiCol_TitleBgActive] = C_TITLE;
    c[ImGuiCol_Button] = ImVec4(0.27f, 0.26f, 0.24f, 1);
    c[ImGuiCol_ButtonHovered] = ImVec4(0.33f, 0.32f, 0.29f, 1);
    c[ImGuiCol_ButtonActive] = C_ACC_A;
    c[ImGuiCol_Header] = ImVec4(0.30f, 0.40f, 0.30f, 1);
    c[ImGuiCol_HeaderHovered] = ImVec4(0.36f, 0.48f, 0.36f, 1);
    c[ImGuiCol_HeaderActive] = C_ACC_A;
    c[ImGuiCol_SliderGrab] = C_ACC;
    c[ImGuiCol_SliderGrabActive] = C_ACC_H;
    c[ImGuiCol_CheckMark] = C_ACC;
    c[ImGuiCol_ScrollbarBg] = ImVec4(0.12f, 0.115f, 0.105f, 1);
    c[ImGuiCol_ScrollbarGrab] = ImVec4(0.40f, 0.38f, 0.35f, 1);
    c[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.48f, 0.46f, 0.42f, 1);
    c[ImGuiCol_ScrollbarGrabActive] = C_ACC;
    c[ImGuiCol_Separator] = C_BORDER;
    c[ImGuiCol_TextSelectedBg] = ImVec4(0.56f, 0.74f, 0.56f, 0.35f);
}

void setup() {
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_IsTouchScreen;
    io.IniFilename = nullptr;
    io.MouseDragThreshold = 14.0f;      // touch: chhota hilna = tap, drag nahi
    ImGui_ImplAndroid_Init();
    ImGui_ImplOpenGL3_Init(nullptr);
    loadConfig();
    const float s = std::min(std::max(g_TargetScale.load(), kMinScale), kMaxScale);
    applyFontAndStyle(s, false);
    g_AppliedScale = s;
    g_LastRebuild = nowSec();
    // terminal editor: workspace.txt, warna engine ki zinput.txt
    std::string z;
    if (!readFile(std::string(kHomeDir) + "workspace.txt", z)) readFile(std::string(kKurumiDir) + kInputName, z);
    std::snprintf(g_ZInput, sizeof(g_ZInput), "%s", z.c_str());
    g_LastWs = g_ZInput;
    loadNotes();
    g_Initialized = true;
}

void syncMenuOff() {
#if defined(HAVE_SET_MODULE_ENABLED)
    pl::modmenu::setModuleEnabled(std::string(kModuleId), false);
#endif
}

bool g_HasCfgCallback = false;

// ------------------------------------------------------------ commands -> zinput.txt
int countCmds(const char* t) {
    int n = 0; bool any = false;
    for (const char* p = t;; ++p) {
        if (*p == '\n' || *p == 0) { if (any) ++n; any = false; if (!*p) break; }
        else if (!std::isspace((unsigned char)*p)) any = true;
    }
    return n;
}
bool sendCommands(const char* text, const char* what) {
    mkdir(kKurumiDir, 0777);
    if (!writeFile(std::string(kKurumiDir) + kInputName, text, std::strlen(text))) {
        setStatus("WRITE FAIL (kurumi folder / permission?)");
        return false;
    }
    ++g_RunsSent;
    g_LastCmds = countCmds(text);
    g_RefreshNow = true;
    std::snprintf(g_Status, sizeof(g_Status), "%s likha %s - engine uthayega", what, clockStr().c_str());
    return true;
}
void fillQuick(const std::string& cmd) {
    std::snprintf(g_QuickCmd, sizeof(g_QuickCmd), "%s", cmd.c_str());
    setStatusf("Command taiyar: %s  (neeche Run dabao)", g_QuickCmd);
}

// ------------------------------------------------------------ on-screen keyboard (ek hi keyboard)
void kbAppend(const char* s) {
    if (!g_KbTarget) return;
    const size_t l = std::strlen(g_KbTarget), n = std::strlen(s);
    if (l + n + 1 <= g_KbSize) std::memcpy(g_KbTarget + l, s, n + 1);
}
void kbBackspace() {
    if (!g_KbTarget) return;
    size_t l = std::strlen(g_KbTarget);
    if (!l) return;
    do { --l; } while (l > 0 && ((unsigned char)g_KbTarget[l] & 0xC0) == 0x80);
    g_KbTarget[l] = 0;
}
void trackTarget(char* buf, size_t sz, const char* name) {   // InputText ke turant baad
    if (ImGui::IsItemActive()) { g_KbTarget = buf; g_KbSize = sz; g_KbName = name; }
}
float kbHeight(float S) { return 6.0f * (30.0f * S + ImGui::GetStyle().ItemSpacing.y) + ImGui::GetFrameHeightWithSpacing() + 12.0f * S; }

void kbRow(const char* row, int r, const ImVec2& bsz) {
    for (int i = 0; row[i]; i++) {
        if (i) ImGui::SameLine();
        char ch = row[i];
        if (g_KbShift && ch >= 'a' && ch <= 'z') ch = (char)(ch - 'a' + 'A');
        const char lab[2] = { ch, 0 };
        ImGui::PushID(r * 100 + i);
        if (ImGui::Button(lab, bsz)) kbAppend(lab);
        ImGui::PopID();
    }
}

void drawKeyboard(float S) {
    if (!g_KbTarget) { g_KbTarget = g_QuickCmd; g_KbSize = sizeof(g_QuickCmd); g_KbName = "quick cmd"; }
    ImGui::TextDisabled("Keyboard -> %s", g_KbName);
    static const char* abc[5] = { "1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm", "<>./-_:=()" };
    static const char* sym[5] = { "1234567890", "<>()[]{}/\\", "!@#$%^&*+=", "-_:;'\"~|?`", ".," };
    const char* const* rows = g_KbSym ? sym : abc;
    const float sp = ImGui::GetStyle().ItemSpacing.x;
    const float bw = std::max(20.0f * S, (ImGui::GetContentRegionAvail().x - sp * 9) / 10.0f);
    const ImVec2 bsz(bw, 30.0f * S);
    for (int r = 0; r < 5; r++) kbRow(rows[r], r, bsz);

    // control row: ?123 | SHIFT | 0x | SPACE | DEL | ENTER  (weights 2,2,1,2,1.5,1.5)
    const float total = ImGui::GetContentRegionAvail().x - sp * 5;
    const float wt[6] = { 2, 2, 1, 2, 1.5f, 1.5f };
    ImGui::PushID(900);
    if (ImGui::Button(g_KbSym ? "ABC" : "?123", ImVec2(total * wt[0] / 10, bsz.y))) g_KbSym = !g_KbSym;
    ImGui::SameLine();
    if (ImGui::Button(g_KbShift ? "SHIFT*" : "SHIFT", ImVec2(total * wt[1] / 10, bsz.y))) g_KbShift = !g_KbShift;
    ImGui::SameLine();
    if (ImGui::Button("0x", ImVec2(total * wt[2] / 10, bsz.y))) kbAppend("0x");
    ImGui::SameLine();
    if (ImGui::Button("SPACE", ImVec2(total * wt[3] / 10, bsz.y))) kbAppend(" ");
    ImGui::SameLine();
    if (ImGui::Button("DEL", ImVec2(total * wt[4] / 10, bsz.y))) kbBackspace();
    ImGui::SameLine();
    if (ImGui::Button("ENTER", ImVec2(total * wt[5] / 10, bsz.y))) kbAppend("\n");
    ImGui::PopID();
}

// ------------------------------------------------------------ touch scroll (child ke andar drag = scroll)
void touchScroll(bool itemDragging) {
    ImGuiIO& io = ImGui::GetIO();
    if (!ImGui::IsMouseDragging(0)) return;
    const ImVec2 cp = io.MouseClickedPos[0];
    const ImVec2 wp = ImGui::GetWindowPos(), ws = ImGui::GetWindowSize();
    if (cp.x < wp.x || cp.y < wp.y || cp.x > wp.x + ws.x || cp.y > wp.y + ws.y) return;   // drag yahin se shuru hua?
    if (itemDragging || (!ImGui::IsAnyItemActive() && ImGui::IsWindowHovered())) {
        ImGui::SetScrollY(ImGui::GetScrollY() - io.MouseDelta.y);
        ImGui::SetScrollX(ImGui::GetScrollX() - io.MouseDelta.x);
    }
}

// ------------------------------------------------------------ pins / templates
void addPin(const char* sec, const char* b, const char* e) {
    std::string s = std::string("[") + sec + " " + clockStr() + "] " + std::string(b, (size_t)std::min<ptrdiff_t>(e - b, 300));
    for (auto& p : g_Pins) if (p == s) return;
    g_Pins.push_back(s);
    setStatusf("Pinned -> Notes (%s)", sec);
}

std::string cmdFromPin(const std::string& pin) {
    const size_t rb = pin.find("] ");
    if (rb == std::string::npos || pin.size() < 3) return "";
    const std::string sec = pin.substr(1, pin.find(' ') - 1);
    const std::string text = pin.substr(rb + 2);
    std::string hex, ident;
    size_t i = 0;
    while (i < text.size()) {
        while (i < text.size() && std::isspace((unsigned char)text[i])) ++i;
        size_t j = i;
        while (j < text.size() && !std::isspace((unsigned char)text[j])) ++j;
        if (j > i) {
            std::string tok = text.substr(i, j - i);
            const bool isHex = tok.size() > 2 && tok[0] == '0' && (tok[1] == 'x' || tok[1] == 'X');
            bool digits = !tok.empty();
            for (char ch : tok) if (!std::isdigit((unsigned char)ch)) { digits = false; break; }
            if (isHex) { if (hex.empty()) hex = tok; }
            else if (!digits && ident.empty() && std::isalpha((unsigned char)tok[0])) ident = tok;
        }
        i = j;
    }
    if (sec == "RTTI" && !ident.empty()) return "findclass<" + ident + ">";
    if (sec == "VTable" && !ident.empty()) return "vt<" + ident + ">";
    if (sec == "Sig" && !hex.empty()) return "sig<" + hex + ">";
    if (sec == "DynSym" && !hex.empty()) return "disasm<" + hex + ">";
    return "";
}

// ------------------------------------------------------------ doc viewer (filter + clipper + horizontal scroll + pin)
struct ViewState {
    const Doc* doc = nullptr;
    std::string filt;
    std::vector<int> idx;
    float longestPx = 0, scaleFor = 0;
};
ViewState g_VS[5];

bool ciContains(const char* b, const char* e, const std::string& lowNeedle) {
    const size_t n = lowNeedle.size();
    if (n == 0) return true;
    if ((size_t)(e - b) < n) return false;
    for (const char* p = b; p + n <= e; ++p) {
        size_t k = 0;
        while (k < n && std::tolower((unsigned char)p[k]) == (unsigned char)lowNeedle[k]) ++k;
        if (k == n) return true;
    }
    return false;
}

void drawDocView(int vs, const std::shared_ptr<const Doc>& doc, bool pinnable, const char* secName, float S) {
    ViewState& st = g_VS[vs];
    const float copyW = ImGui::CalcTextSize("Copy").x + ImGui::GetStyle().FramePadding.x * 2;
    ImGui::SetNextItemWidth(std::max(80.0f * S, ImGui::GetContentRegionAvail().x - copyW - ImGui::GetStyle().ItemSpacing.x));
    char hint[48]; std::snprintf(hint, sizeof(hint), "filter (%s)...", secName);
    char idb[16]; std::snprintf(idb, sizeof(idb), "##flt%d", vs);
    ImGui::InputTextWithHint(idb, hint, g_Filt[vs], sizeof(g_Filt[vs]));
    trackTarget(g_Filt[vs], sizeof(g_Filt[vs]), secName);
    ImGui::SameLine();
    const bool copyClicked = ImGui::Button("Copy");

    if (!doc || doc->lines() == 0) {
        if (copyClicked) setStatus("Copy karne ko kuch nahi");
        ImGui::TextDisabled("(file khali / nahi mili - Run karke Refresh dabao)");
        return;
    }

    const bool filtering = g_Filt[vs][0] != 0;
    if (st.doc != doc.get() || st.filt != g_Filt[vs]) {
        st.doc = doc.get();
        st.filt = g_Filt[vs];
        st.idx.clear();
        if (filtering) {
            std::string low = st.filt;
            for (auto& ch : low) ch = (char)std::tolower((unsigned char)ch);
            for (int i = 0; i < doc->lines(); ++i)
                if (ciContains(doc->lb(i), doc->le(i), low)) st.idx.push_back(i);
        }
        st.scaleFor = 0;
    }
    if (st.scaleFor != S) {
        const int li = (int)doc->longest;
        st.longestPx = ImGui::CalcTextSize(doc->lb(li), doc->le(li)).x;
        st.scaleFor = S;
    }
    const int count = filtering ? (int)st.idx.size() : doc->lines();
    if (copyClicked) {   // jo dikh raha hai (filtered ya poora) wahi copy hota hai
        std::string out;
        for (int i = 0; i < count && out.size() < 160 * 1024; ++i) {
            const int li = filtering ? st.idx[i] : i;
            out.append(doc->lb(li), doc->le(li));
            out.push_back('\n');
        }
        char what[64]; std::snprintf(what, sizeof(what), "%s (%d lines)", secName, count);
        doCopy(out, what);
    }
    ImGui::TextDisabled("%d / %d lines%s", count, doc->lines(), pinnable ? "  (line tap = pin)" : "");

    const float contentW = st.longestPx + 24.0f * S;
    ImGui::SetNextWindowContentSize(ImVec2(contentW, 0));
    ImGui::BeginChild("##view", ImVec2(0, 0), false, ImGuiWindowFlags_HorizontalScrollbar);
    ImGuiIO& io = ImGui::GetIO();
    const float textH = ImGui::GetTextLineHeight();
    const float rowH = pinnable ? textH + 12.0f * S : textH;
    const float itemH = rowH + ImGui::GetStyle().ItemSpacing.y;
    bool dragItem = false;
    ImGuiListClipper clipper;
    clipper.Begin(count, itemH);
    while (clipper.Step()) {
        for (int i = clipper.DisplayStart; i < clipper.DisplayEnd; ++i) {
            const int li = filtering ? st.idx[i] : i;
            const char* b = doc->lb(li); const char* e = doc->le(li);
            if (!pinnable) {
                ImGui::TextUnformatted(b, e);
            } else {
                ImGui::PushID(li);
                const ImVec2 p = ImGui::GetCursorScreenPos();
                const bool clicked = ImGui::InvisibleButton("##l", ImVec2(std::max(contentW, ImGui::GetContentRegionAvail().x), rowH));
                if (ImGui::IsItemActive()) {
                    ImGui::GetWindowDrawList()->AddRectFilled(p, ImVec2(p.x + contentW, p.y + rowH), ImGui::GetColorU32(ImVec4(0.56f, 0.74f, 0.56f, 0.18f)));
                    if (ImGui::IsMouseDragging(0)) dragItem = true;
                }
                ImGui::GetWindowDrawList()->AddText(ImVec2(p.x, p.y + (rowH - textH) * 0.5f), ImGui::GetColorU32(C_TEXT), b, e);
                if (clicked && io.MouseDragMaxDistanceSqr[0] < io.MouseDragThreshold * io.MouseDragThreshold)
                    addPin(secName, b, e);
                ImGui::PopID();
            }
        }
    }
    clipper.End();
    touchScroll(dragItem);
    ImGui::EndChild();
}

// ------------------------------------------------------------ sections
enum Sec { SEC_TERMINAL, SEC_OUTPUT, SEC_PROCESS, SEC_CONFIG, SEC_RTTI, SEC_VTABLE, SEC_DYNSYM, SEC_SIG, SEC_TOOLS, SEC_NOTES };
const char* kSecNames[10] = { "1. Terminal", "2. Output", "3. Process", "4. Config", "5. RTTI",
                              "6. VTable", "7. DynSym", "8. Sig", "9. Tools", "10. Notes" };
const char* kHints[10] = {
    "Arg likho -> verb button. Ya neeche editor me list banao -> Run All.",
    "Run ke baad: strings/ctor/hook/disasm/hash/scan yahin aate hain.",
    "Engine ki diary + knobs. Knobs sirf game restart ke baad lagte hain.",
    "zaphkiel_config.txt (read-only). Badalna ho to 3. Process.",
    "Class mili? -> line tap = pin, phir 6. VTable kholo.",
    "Slot mila? -> 8. Sig me pehchaan banao.",
    "Public symbols = game ke entry points.",
    "Update-proof pehchaan: pattern ya rva se.",
    "Class ya 0xaddr likho, verb dabao. Result: 2. Output.",
    "Pin: line tap karo. [Cmd] = pin se command template (neeche quick box me).",
};

enum State { ST_IDLE, ST_RUNNING, ST_DONE, ST_SILENT };
State computeState(const Snap& s) {
    if (s.inMt == 0) return ST_IDLE;
    if (s.logMt < s.inMt) return (time(nullptr) - s.inMt < kSilentSecs) ? ST_RUNNING : ST_SILENT;
    return s.logDone ? ST_DONE : ST_IDLE;
}

// engine knobs (zaphkiel_config.txt key=value)
struct Knob { std::string key; char val[96]; bool isBool; bool b; };
std::vector<Knob> g_Knobs;
const Doc* g_KnobsDoc = nullptr;
bool g_KnobsDirty = false;

void rebuildKnobs(const std::shared_ptr<const Doc>& cfg) {
    g_Knobs.clear();
    g_KnobsDoc = cfg.get();
    if (!cfg) return;
    for (int i = 0; i < cfg->lines(); ++i) {
        std::string line(cfg->lb(i), cfg->le(i));
        const size_t eq = line.find('=');
        if (eq == std::string::npos || eq == 0) continue;
        Knob k; k.key = line.substr(0, eq);
        std::string v = line.substr(eq + 1);
        std::snprintf(k.val, sizeof(k.val), "%s", v.c_str());
        k.isBool = (v == "true" || v == "false");
        k.b = (v == "true");
        g_Knobs.push_back(k);
    }
}
bool saveKnobs() {
    std::string out;
    for (auto& k : g_Knobs) {
        out += k.key; out += "=";
        out += k.isBool ? (k.b ? "true" : "false") : k.val;
        out += "\n";
    }
    mkdir(kKurumiDir, 0777);
    return writeFile(std::string(kKurumiDir) + "zaphkiel_config.txt", out.data(), out.size());
}

// smart builder: arg + verb button => "verb<arg>" banta hai (< > type nahi karna)
bool usesExtra(const char* verb) { return !std::strcmp(verb, "vt") || !std::strcmp(verb, "hook"); }

void runVerb(const char* verb) {
    if (!g_Arg[0]) { setStatus("Pehle Arg likho (class naam ya 0xaddr)"); return; }
    std::string cmd = std::string(verb) + "<" + g_Arg + ">";
    if (g_Extra[0] && usesExtra(verb)) cmd += std::string("<") + g_Extra + ">";
    if (g_BuilderAdd) {
        const size_t l = std::strlen(g_ZInput);
        if (l + cmd.size() + 2 >= sizeof(g_ZInput)) { setStatus("Terminal list bhar gayi"); return; }
        if (l > 0 && g_ZInput[l - 1] != '\n') std::strcat(g_ZInput, "\n");
        std::strcat(g_ZInput, cmd.c_str());
        std::strcat(g_ZInput, "\n");
        setStatusf("List me jodi: %s  (Terminal > Run All se chalao)", cmd.c_str());
    } else {
        sendCommands(cmd.c_str(), cmd.c_str());     // zinput.txt me sirf yahi ek command
    }
}

void drawBuilder(const char* const* verbs, int n, float S) {
    ImGui::SetNextItemWidth(std::max(200.0f * S, ImGui::GetContentRegionAvail().x * 0.55f));
    ImGui::InputTextWithHint("##arg", "Arg: class naam ya 0xaddr", g_Arg, sizeof(g_Arg));
    trackTarget(g_Arg, sizeof(g_Arg), "Arg");
    ImGui::SameLine();
    ImGui::SetNextItemWidth(std::max(90.0f * S, ImGui::GetContentRegionAvail().x));
    ImGui::InputTextWithHint("##ext", "2nd (slot)", g_Extra, sizeof(g_Extra));
    trackTarget(g_Extra, sizeof(g_Extra), "2nd arg");
    ImGui::Checkbox("Bhejo nahi, Terminal list me jodo", &g_BuilderAdd);
    ImGui::PushStyleColor(ImGuiCol_Text, C_DARKTXT);
    ImGui::PushStyleColor(ImGuiCol_Button, C_ACC);
    for (int i = 0; i < n; ++i) {
        if (i) ImGui::SameLine();
        char lab[48]; std::snprintf(lab, sizeof(lab), "%s< >", verbs[i]);
        if (ImGui::Button(lab)) runVerb(verbs[i]);
    }
    ImGui::PopStyleColor(2);
}

void secTerminal(float S) {
    static const char* verbs[] = { "findclass", "vt", "sig" };
    drawBuilder(verbs, 3, S);
    ImGui::TextDisabled("findclass: class naam | vt: class (+ 2nd = slot) | sig: rva");
    ImGui::Separator();
    ImGui::TextDisabled("kurumi/%s editor", kInputName);
    const float reserve = ImGui::GetFrameHeightWithSpacing() + 6.0f * S;
    ImGui::InputTextMultiline("##zin", g_ZInput, sizeof(g_ZInput),
                              ImVec2(-FLT_MIN, std::max(70.0f * S, ImGui::GetContentRegionAvail().y - reserve)));
    trackTarget(g_ZInput, sizeof(g_ZInput), "Terminal");
    ImGui::PushStyleColor(ImGuiCol_Text, C_DARKTXT);
    ImGui::PushStyleColor(ImGuiCol_Button, C_ACC);
    if (ImGui::Button("Run All")) sendCommands(g_ZInput, "Run All");
    ImGui::PopStyleColor(2);
    ImGui::SameLine();
    if (ImGui::Button("File se load")) {
        std::string z;
        if (readFile(std::string(kKurumiDir) + kInputName, z)) {
            std::snprintf(g_ZInput, sizeof(g_ZInput), "%s", z.c_str());
            setStatus("zinput.txt editor me load hui");
        } else setStatus("zinput.txt nahi mili");
    }
    ImGui::SameLine();
    if (ImGui::Button("Copy")) doCopy(g_ZInput, "Terminal");
}

void secProcess(const Snap& snap, State stt, float S) {
    const char* names[] = { "IDLE", "RUNNING", "DONE", "SILENT" };
    const ImVec4 cols[] = { C_GREY, C_AMBER, C_ACC, C_RED };
    ImGui::TextColored(cols[stt], "State: %s", names[stt]);
    ImGui::SameLine();
    ImGui::TextDisabled("| bheje: %d | last file me cmds: %d", g_RunsSent, g_LastCmds);
    if (stt == ST_SILENT)
        ImGui::TextColored(C_RED, "Engine %d sec se jawab nahi de raha -> Zaphkiel mod loaded hai?", kSilentSecs);
    ImGui::Separator();

    if (g_KnobsDoc != snap.d[F_CFG].get() && !g_KnobsDirty) rebuildKnobs(snap.d[F_CFG]);
    ImGui::TextDisabled("Engine knobs (zaphkiel_config.txt) - restart ke baad lagenge");
    if (g_Knobs.empty()) ImGui::TextDisabled("(config nahi mili)");
    for (size_t i = 0; i < g_Knobs.size(); ++i) {
        Knob& k = g_Knobs[i];
        ImGui::PushID((int)i);
        if (k.isBool) { if (ImGui::Checkbox(k.key.c_str(), &k.b)) g_KnobsDirty = true; }
        else {
            ImGui::SetNextItemWidth(200.0f * S);
            if (ImGui::InputText(k.key.c_str(), k.val, sizeof(k.val))) g_KnobsDirty = true;
            trackTarget(k.val, sizeof(k.val), "knob");
        }
        ImGui::PopID();
    }
    ImGui::PushStyleColor(ImGuiCol_Text, C_DARKTXT);
    ImGui::PushStyleColor(ImGuiCol_Button, C_ACC);
    if (ImGui::Button("Save knobs") && !g_Knobs.empty()) {
        if (saveKnobs()) { g_KnobsDirty = false; g_KnobsDoc = nullptr; g_RefreshNow = true; setStatus("Config saved - GAME RESTART karo (engine boot pe padhta hai)"); }
        else setStatus("Config WRITE FAIL");
    }
    ImGui::PopStyleColor(2);
    if (g_KnobsDirty) { ImGui::SameLine(); ImGui::TextColored(C_AMBER, "unsaved"); }

    if (!g_HasCfgCallback) {   // menu sliders connect na hon to sirf tab yeh fallback dikhta hai
        ImGui::Separator();
        ImGui::TextColored(C_AMBER, "Mod Menu sliders connect nahi hue (SDK callback nahi mila). Fallback:");
        float sc = g_TargetScale.load(), op = g_Opacity.load(), px = g_PosXPct.load(), py = g_PosYPct.load();
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::SliderFloat("##fsc", &sc, kMinScale, kMaxScale, "Scale %.2f")) { }
        if (ImGui::IsItemDeactivatedAfterEdit()) g_TargetScale = sc;
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::SliderFloat("##fop", &op, 0.2f, 1.0f, "Opacity %.2f")) g_Opacity = op;
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::SliderFloat("##fpx", &px, 0.0f, 100.0f, "Pos X %.0f%%")) g_PosXPct = px;
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::SliderFloat("##fpy", &py, 0.0f, 100.0f, "Pos Y %.0f%%")) g_PosYPct = py;
    }

    ImGui::Separator();
    ImGui::TextDisabled("zaphkiel_log.txt");
    ImGui::SameLine();
    if (ImGui::Button("Copy log")) { const auto& d = snap.d[F_LOG]; doCopy(d ? d->text : std::string(), "Log"); }
    ImGui::BeginChild("##log", ImVec2(0, std::max(160.0f * S, ImGui::GetContentRegionAvail().y)), true, ImGuiWindowFlags_HorizontalScrollbar);
    {
        const auto& d = snap.d[F_LOG];
        ImGui::TextUnformatted(d && !d->text.empty() ? d->text.c_str() : "(log khali)");
    }
    touchScroll(false);
    ImGui::EndChild();
}

void secConfig(const Snap& snap) {
    ImGui::TextDisabled("zaphkiel_config.txt (read-only)");
    ImGui::SameLine();
    if (ImGui::Button("Copy")) { const auto& d = snap.d[F_CFG]; doCopy(d ? d->text : std::string(), "Config"); }
    ImGui::TextColored(C_AMBER, "Engine config sirf game boot pe padhta hai - badalne ke baad restart.");
    ImGui::BeginChild("##cfg", ImVec2(0, 0), true, ImGuiWindowFlags_HorizontalScrollbar);
    const auto& d = snap.d[F_CFG];
    ImGui::TextUnformatted(d && !d->text.empty() ? d->text.c_str() : "(config nahi mili)");
    touchScroll(false);
    ImGui::EndChild();
}

void secTools(float S) {
    static const char* verbs[] = { "ctor", "hook", "fn", "disasm", "hash", "scan" };
    drawBuilder(verbs, 6, S);
    ImGui::TextDisabled("ctor/hook: class naam (hook + 2nd = slot) | fn/disasm/hash/scan: 0xaddr");
    ImGui::Separator();
    ImGui::TextDisabled("Result: 2. Output. Command ka format status line me dikhta hai - galat ho to Terminal me khud edit karo.");
}

void secNotes(float S) {
    const float freeH = std::max(80.0f * S, ImGui::GetContentRegionAvail().y * 0.38f);
    ImGui::TextDisabled("Free notes (levire/notes.txt)");
    ImGui::SameLine();
    if (ImGui::Button("Copy all")) doCopy(serializeNotes(), "Notes + pins");
    ImGui::InputTextMultiline("##notes", g_Notes, sizeof(g_Notes), ImVec2(-FLT_MIN, freeH));
    trackTarget(g_Notes, sizeof(g_Notes), "Notes");
    ImGui::TextDisabled("Pins (%d)", (int)g_Pins.size());
    ImGui::BeginChild("##pins", ImVec2(0, 0), true, ImGuiWindowFlags_HorizontalScrollbar);
    int del = -1;
    for (int i = 0; i < (int)g_Pins.size(); ++i) {
        ImGui::PushID(i);
        if (ImGui::Button("Cmd")) {
            const std::string c = cmdFromPin(g_Pins[i]);
            if (c.empty()) setStatus("Is pin se command nahi bana - 9. Tools use karo"); else fillQuick(c);
        }
        ImGui::SameLine();
        if (ImGui::Button("x")) del = i;
        ImGui::SameLine();
        ImGui::TextUnformatted(g_Pins[i].c_str());
        ImGui::PopID();
    }
    if (del >= 0) g_Pins.erase(g_Pins.begin() + del);
    if (g_Pins.empty()) ImGui::TextDisabled("(koi pin nahi - RTTI/VTable/DynSym/Sig me line tap karo)");
    touchScroll(false);
    ImGui::EndChild();
}

// ------------------------------------------------------------ main window
void drawTopBar(State stt, float S) {
    const ImVec4 cols[] = { C_GREY, C_AMBER, C_ACC, C_RED };
    const char* names[] = { "IDLE", "RUNNING", "DONE", "SILENT" };
    ImGui::AlignTextToFramePadding();
    ImGui::TextColored(C_ACC, "Zaphkiel Panel");
    ImGui::SameLine(0, 20.0f * S);
    const float fh = ImGui::GetFrameHeight();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const float r = fh * 0.2f;
    ImGui::GetWindowDrawList()->AddCircleFilled(ImVec2(p.x + r + 2, p.y + fh * 0.5f), r, ImGui::GetColorU32(cols[stt]));
    ImGui::Dummy(ImVec2(r * 2 + 8, fh));
    ImGui::SameLine(0, 0);
    ImGui::AlignTextToFramePadding();
    ImGui::TextColored(cols[stt], "%s  #%d", names[stt], g_RunsSent);
    ImGui::SameLine(ImGui::GetWindowWidth() - fh * 1.6f - ImGui::GetStyle().WindowPadding.x);
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.45f, 0.22f, 0.20f, 1));
    const bool x = ImGui::Button("X", ImVec2(fh * 1.6f, fh));
    ImGui::PopStyleColor();
    if (x) {
        g_Visible = false; g_WantText = false; g_RectW = 0; g_RectH = 0;
        saveConfig(); syncMenuOff();
    }
}

void drawMenu(const Snap& snap) {
    if (!g_Visible.load()) return;
    ImGuiIO& io = ImGui::GetIO();
    const float S = g_AppliedScale;
    const ImVec2 ds = io.DisplaySize;
    const float W = std::min(kBaseW * S, ds.x * kScreenFrac);
    const float H = std::min(kBaseH * S, ds.y * kScreenFrac);
    const float px = std::min(std::max(g_PosXPct.load(), 0.0f), 100.0f) / 100.0f * std::max(0.0f, ds.x - W);
    const float py = std::min(std::max(g_PosYPct.load(), 0.0f), 100.0f) / 100.0f * std::max(0.0f, ds.y - H);
    ImGui::SetNextWindowPos(ImVec2(px, py), ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(W, H), ImGuiCond_Always);
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, std::min(std::max(g_Opacity.load(), 0.2f), 1.0f));

    ImGui::Begin("##zpanel", nullptr,
                 ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize |
                 ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings |
                 ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    const ImVec2 wp = ImGui::GetWindowPos(), wsz = ImGui::GetWindowSize();
    g_RectX = wp.x; g_RectY = wp.y; g_RectW = wsz.x; g_RectH = wsz.y;

    const State stt = computeState(snap);
    drawTopBar(stt, S);
    ImGui::Separator();

    const float bottomH = ImGui::GetFrameHeightWithSpacing() + 6.0f * S;
    const float kbH = g_KbOpen ? kbHeight(S) : 0.0f;
    const float bodyH = -(bottomH + kbH);

    // left: sections (28%)
    const float leftW = std::floor(ImGui::GetContentRegionAvail().x * 0.28f);
    ImGui::BeginChild("##sec", ImVec2(leftW, bodyH), true);
    for (int i = 0; i < 10; i++) {
        if (i == 5) { ImGui::Separator(); ImGui::TextDisabled("-- Others --"); }
        const bool sel = (g_Section == i);
        if (sel) { ImGui::PushStyleColor(ImGuiCol_Button, C_ACC); ImGui::PushStyleColor(ImGuiCol_Text, C_DARKTXT); }
        if (ImGui::Button(kSecNames[i], ImVec2(-FLT_MIN, 34.0f * S))) { g_Section = i; saveConfig(); }
        if (sel) ImGui::PopStyleColor(2);
    }
    touchScroll(false);
    ImGui::EndChild();

    // right: function area (72%)
    ImGui::SameLine();
    const bool selfScroll = (g_Section != SEC_PROCESS && g_Section != SEC_TOOLS);
    ImGui::BeginChild("##func", ImVec2(0, bodyH), true,
                      selfScroll ? (ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse) : 0);
    ImGui::TextDisabled("%s", kHints[g_Section]);
    switch (g_Section) {
        case SEC_TERMINAL: secTerminal(S); break;
        case SEC_OUTPUT:   drawDocView(0, snap.d[F_OUT], false, "Output", S); break;
        case SEC_PROCESS:  secProcess(snap, stt, S); break;
        case SEC_CONFIG:   secConfig(snap); break;
        case SEC_RTTI:   drawDocView(1, snap.d[F_RTTI], true, "RTTI", S); break;
        case SEC_VTABLE: drawDocView(2, snap.d[F_VT], true, "VTable", S); break;
        case SEC_DYNSYM: drawDocView(3, snap.d[F_DYN], true, "DynSym", S); break;
        case SEC_SIG:    drawDocView(4, snap.d[F_SIG], true, "Sig", S); break;
        case SEC_TOOLS: secTools(S); break;
        case SEC_NOTES: secNotes(S); break;
    }
    if (!selfScroll) touchScroll(false);
    ImGui::EndChild();

    // on-screen keyboard (sab sections me ek hi)
    if (g_KbOpen) {
        ImGui::BeginChild("##kb", ImVec2(0, kbH - ImGui::GetStyle().ItemSpacing.y), true,
                          ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
        drawKeyboard(S);
        ImGui::EndChild();
    }

    // bottom bar (fixed)
    if (ImGui::Button(g_KbOpen ? "KB: ON" : "KB: OFF")) g_KbOpen = !g_KbOpen;
    ImGui::SameLine();
    const float btnW = ImGui::CalcTextSize("Refresh").x + ImGui::GetStyle().FramePadding.x * 2;
    ImGui::SetNextItemWidth(std::max(120.0f * S, ImGui::GetContentRegionAvail().x * 0.34f));
    ImGui::InputTextWithHint("##quick", "quick command: verb<arg>", g_QuickCmd, sizeof(g_QuickCmd));
    trackTarget(g_QuickCmd, sizeof(g_QuickCmd), "quick cmd");
    ImGui::SameLine();
    if (ImGui::Button("Refresh", ImVec2(btnW, 0))) { g_RefreshNow = true; setStatus("Refresh"); }
    ImGui::SameLine();
    ImGui::PushStyleColor(ImGuiCol_Text, C_DARKTXT);
    ImGui::PushStyleColor(ImGuiCol_Button, C_ACC);
    if (ImGui::Button("Run")) {
        if (g_QuickCmd[0]) sendCommands(g_QuickCmd, g_QuickCmd);
        else setStatus("Quick line khali - Terminal me Run All use karo");
    }
    ImGui::PopStyleColor(2);
    ImGui::SameLine();
    ImGui::TextDisabled("%s", g_Status);

    ImGui::End();
    ImGui::PopStyleVar();

    g_WantText = io.WantTextInput;   // hardware keyboard consume ke liye
}

void render() {
    ImGuiIO& io = ImGui::GetIO();
    if (g_ResetInput.exchange(false)) {
        { std::lock_guard<std::mutex> l(g_QMutex); g_Queue.clear(); }
        g_ToRelease.clear();
        std::memset(io.KeysDown, 0, sizeof(io.KeysDown));
        io.AddMouseButtonEvent(0, false);
    }
    const float tgt = std::min(std::max(g_TargetScale.load(), kMinScale), kMaxScale);
    const double t = nowSec();
    if (std::fabs(tgt - g_AppliedScale) > 0.005f && t - g_LastRebuild > 0.25) {
        applyFontAndStyle(tgt, g_DeviceReady);
        g_AppliedScale = tgt;
        g_LastRebuild = t;
        for (auto& v : g_VS) v.scaleFor = 0;
    }
    flushInput(io);
    Snap snap;
    { std::lock_guard<std::mutex> l(g_Mx); snap = g_Snap; }

    ImGui_ImplOpenGL3_NewFrame();
    g_DeviceReady = true;
    ImGui_ImplAndroid_NewFrame(g_Width, g_Height);
    ImGui::NewFrame();
    drawMenu(snap);
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    if (g_Visible.load()) {
        autosave();
        if (t - g_LastSave > 1.0) { g_LastSave = t; saveConfig(); }
    }
}

EGLBoolean hook_swap(EGLDisplay dpy, EGLSurface surf) {
    if (!g_OrigSwap) return EGL_FALSE;
    EGLContext ctx = eglGetCurrentContext();
    if (ctx == EGL_NO_CONTEXT) return g_OrigSwap(dpy, surf);
    EGLint w = 0, h = 0;
    eglQuerySurface(dpy, surf, EGL_WIDTH, &w);
    eglQuerySurface(dpy, surf, EGL_HEIGHT, &h);
    if (w < 500 || h < 500) return g_OrigSwap(dpy, surf);
    if (g_TargetContext == EGL_NO_CONTEXT) {
        EGLint buf = 0;
        eglQuerySurface(dpy, surf, EGL_RENDER_BUFFER, &buf);
        if (buf == EGL_BACK_BUFFER) { g_TargetContext = ctx; g_TargetSurface = surf; }
    }
    if (ctx != g_TargetContext || surf != g_TargetSurface) return g_OrigSwap(dpy, surf);
    g_Width = w; g_Height = h;
    if (g_Visible.load()) {
        if (!g_Initialized.load()) setup();
        render();
    }
    return g_OrigSwap(dpy, surf);
}

// ------------------------------------------------------------ background reader (UI thread pe file I/O nahi)
struct Stamp { time_t mt = 0; off_t sz = -1; };

void bgReader() {
    Stamp st[F_COUNT];
    for (;;) {
        const bool force = g_RefreshNow.exchange(false);
        if (force || g_Visible.load()) {
            struct stat s;
            // order slip + diary ke mtimes (state chip ke liye)
            time_t inMt = 0, logMt = 0;
            if (stat((std::string(kKurumiDir) + kInputName).c_str(), &s) == 0) inMt = s.st_mtime;
            for (int i = 0; i < F_COUNT; ++i) {
                const std::string p = std::string(kKurumiDir) + kFileNames[i];
                if (stat(p.c_str(), &s) != 0) {
                    if (st[i].sz != -1) { st[i] = Stamp(); std::lock_guard<std::mutex> k(g_Mx); g_Snap.d[i].reset(); }
                    continue;
                }
                if (i == F_LOG) logMt = s.st_mtime;
                if (!force && s.st_mtime == st[i].mt && s.st_size == st[i].sz) continue;
                st[i].mt = s.st_mtime; st[i].sz = s.st_size;
                std::string txt;
                if (!readTail(p, txt, kFileTail[i])) continue;
                const bool done = (i == F_LOG) && txt.find("run() complete") != std::string::npos;
                auto doc = makeDoc(std::move(txt));
                std::lock_guard<std::mutex> k(g_Mx);
                g_Snap.d[i] = doc;
                if (i == F_LOG) g_Snap.logDone = done;
            }
            std::lock_guard<std::mutex> k(g_Mx);
            g_Snap.inMt = inMt; g_Snap.logMt = logMt;
        }
        for (int i = 0; i < 15 && !g_RefreshNow.load(); i++) usleep(100000);   // ~1.5s ya Refresh
    }
}

void* mainThread(void*) {
    sleep(3);
    void* egl = dlopen("libEGL.so", RTLD_NOW);
    if (egl) {
        void* swap = dlsym(egl, "eglSwapBuffers");
        if (swap) g_SwapHook = pl::memory::HookHandle(swap, (void*)&hook_swap, (void**)&g_OrigSwap);
        LOGI("EGL hook: %s", g_SwapHook.installed() ? "OK" : "FAIL");
    } else {
        LOGW("libEGL.so open fail");
    }
    std::thread(bgReader).detach();
    return nullptr;
}

// ------------------------------------------------------------ mod menu
void onToggle(std::string_view moduleId, bool enabled) {
    if (moduleId != kModuleId) return;
    if (enabled) { g_ResetInput = true; g_RefreshNow = true; g_Visible = true; }
    else g_Visible = false;
}

template <class T>
std::string toStr(const T& v) {
    if constexpr (std::is_same_v<T, bool>) return v ? "1" : "0";
    else if constexpr (std::is_convertible_v<const T&, std::string_view>) return std::string(std::string_view(v));
    else if constexpr (std::is_arithmetic_v<T>) return std::to_string(v);
    else return std::string();
}

template <class... A>
void onConfig(const A&... a) {
    std::vector<std::string> v;
    (v.push_back(toStr(a)), ...);
    for (size_t i = 0; i + 1 < v.size(); ++i) {
        const float x = static_cast<float>(std::atof(v[i + 1].c_str()));
        if (v[i] == "scale")        { if (x >= kMinScale && x <= kMaxScale) g_TargetScale = x; return; }
        else if (v[i] == "opacity") { if (x >= 0.2f && x <= 1.0f) g_Opacity = x; return; }
        else if (v[i] == "posx")    { if (x >= 0 && x <= 100) g_PosXPct = x; return; }
        else if (v[i] == "posy")    { if (x >= 0 && x <= 100) g_PosYPct = x; return; }
    }
}

struct CfgFn {
    template <class... A>
    void operator()(const A&... a) const { onConfig(a...); }
};

template <class B>
constexpr bool kHasCfgCallback = requires(B b) { b.onConfigChanged(CfgFn{}); };

template <class B>
B attachCfg(B b) {
    if constexpr (kHasCfgCallback<B>) return b.onConfigChanged(CfgFn{});
    else return b;
}

bool registerMenu(ll::mod::NativeMod& self) {
    using CT = pl::modmenu::ConfigType;
    auto b = pl::modmenu::ModuleBuilder(std::string(kModuleId), "Zaphkiel Panel")
                 .modId(self.getId())
                 .description("RE control surface. Sliders: Scale / Opacity / Position. X = hide, toggle OFF->ON = wapas.")
                 .defaultEnabled(false)
                 .onToggle(onToggle)
                 .config("scale",   "Panel Size",   CT::SliderFloat, "1.4",  "0.8", "2.5")
                 .config("opacity", "Opacity",      CT::SliderFloat, "0.95", "0.2", "1.0")
                 .config("posx",    "Position X %", CT::SliderFloat, "4",    "0",   "100")
                 .config("posy",    "Position Y %", CT::SliderFloat, "6",    "0",   "100");
    g_HasCfgCallback = kHasCfgCallback<pl::modmenu::ModuleBuilder>;
    b = attachCfg(b);
    return b.registerModule();
}

std::once_flag g_CbOnce, g_HookOnce;

}  // namespace

class PanelMod {
public:
    static PanelMod& instance() { static PanelMod m; return m; }
    PanelMod() : mSelf(*ll::mod::NativeMod::current()) {}
    ll::mod::NativeMod& getSelf() const { return mSelf; }

    bool load() { getSelf().getLogger().info("Zaphkiel Panel v5 loaded"); return true; }

    bool enable() {
        std::call_once(g_CbOnce, [] {
            pl::input::registerTouchCallback(onTouch);
            pl::input::registerKeyCallback(onKey);
        });
        std::call_once(g_HookOnce, [] {
            pthread_t t;
            pthread_create(&t, nullptr, mainThread, nullptr);
        });
        const bool ok = registerMenu(getSelf());
        LOGI("Menu register: %s (cfg callback: %s)", ok ? "OK" : "FAIL", g_HasCfgCallback ? "yes" : "no");
        if (!ok) g_Visible = true;   // fallback: panel hamesha ON
        return true;
    }

    bool disable() {
        g_Visible = false;
        g_WantText = false;
        pl::modmenu::unregisterModule(kModuleId);
        return true;
    }

    bool unload() { return true; }

private:
    ll::mod::NativeMod& mSelf;
};

PL_REGISTER_MOD(PanelMod, PanelMod::instance())
