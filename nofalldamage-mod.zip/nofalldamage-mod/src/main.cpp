// No Fall Damage - Mod Menu toggle, arm64 code patch (khud ki patching, SDK ke Patch API pe nirbhar nahi)
//   ON  : libminecraftpe.so + offset pe function ke shuru me 'return' likhta hai
//   OFF : original bytes wapas
//   Safety: pehli baar original bytes save (nofall_base.txt); game update ke baad bytes alag hue to patch REFUSE.
//   Config: levire/nofall.cfg (offset, mode) - rebuild ke bina badal sakte ho. Log: levire/nofall_log.txt
#include <android/log.h>
#include <dlfcn.h>
#include <link.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#include <atomic>
#include <cerrno>
#include <chrono>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <mutex>
#include <string>
#include <string_view>
#include <thread>
#include <vector>

#include <pl/Mod.hpp>
#include <pl/ModMenu.hpp>
#include <pl/Logger.hpp>

#define TAG "NoFallDamage"

namespace {

#ifndef NOFALL_ROOT
#define NOFALL_ROOT "/storage/emulated/0/Android/media/org.levimc.launcher/"
#endif
#ifndef NOFALL_LIB
#define NOFALL_LIB "libminecraftpe.so"
#endif

constexpr std::string_view kModuleId = "nofalldamage.toggle";
const char* kDir     = NOFALL_ROOT "levire/";
const char* kCfgPath = NOFALL_ROOT "levire/nofall.cfg";
const char* kBasePath = NOFALL_ROOT "levire/nofall_base.txt";
const char* kLogPath = NOFALL_ROOT "levire/nofall_log.txt";

constexpr uint64_t kDefaultOffset = 0xf28e710;   // Zaphkiel se (is game version ke liye)
constexpr size_t   kBaseLen = 8;                 // itne bytes check/restore ke liye dekhe jate hain

// ARM64: ret = D65F03C0 ; mov x0,#0 = D2800000
const uint8_t kRet[4]  = { 0xC0, 0x03, 0x5F, 0xD6 };
const uint8_t kRet0[8] = { 0x00, 0x00, 0x80, 0xD2, 0xC0, 0x03, 0x5F, 0xD6 };

std::mutex g_Mx;
std::mutex g_LogMx;
std::atomic_bool g_Want{false};
std::atomic_bool g_RetryRunning{false};

struct PatchState {
    bool applied = false;
    uintptr_t addr = 0;
    size_t len = 0;
    uint8_t orig[kBaseLen] = {};
} g_P;

// ------------------------------------------------------------ log (logcat + levire/nofall_log.txt)
void logf(const char* fmt, ...) {
    char msg[400];
    va_list ap; va_start(ap, fmt);
    std::vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);
    __android_log_print(ANDROID_LOG_INFO, TAG, "%s", msg);
    std::lock_guard<std::mutex> l(g_LogMx);
    mkdir(kDir, 0777);
    FILE* f = std::fopen(kLogPath, "a");
    if (!f) return;
    time_t t = time(nullptr); struct tm tmv; localtime_r(&t, &tmv);
    std::fprintf(f, "%02d:%02d:%02d %s\n", tmv.tm_hour, tmv.tm_min, tmv.tm_sec, msg);
    std::fclose(f);
}

void trimLog() {   // load par: bada ho gaya to fresh
    struct stat s;
    if (stat(kLogPath, &s) == 0 && s.st_size > 64 * 1024) std::remove(kLogPath);
}

// ------------------------------------------------------------ small file helpers
bool readText(const char* path, std::string& out) {
    FILE* f = std::fopen(path, "rb");
    if (!f) return false;
    char b[1024]; size_t n; out.clear();
    while ((n = std::fread(b, 1, sizeof(b), f)) > 0) out.append(b, n);
    std::fclose(f);
    return true;
}
bool writeText(const char* path, const std::string& s) {
    FILE* f = std::fopen(path, "wb");
    if (!f) return false;
    std::fwrite(s.data(), 1, s.size(), f);
    std::fclose(f);
    return true;
}

std::string hexOf(const uint8_t* p, size_t n) {
    static const char* d = "0123456789abcdef";
    std::string s;
    for (size_t i = 0; i < n; ++i) { s.push_back(d[p[i] >> 4]); s.push_back(d[p[i] & 15]); }
    return s;
}

// ------------------------------------------------------------ config (levire/nofall.cfg)
struct Cfg { uint64_t offset = kDefaultOffset; bool ret0 = true; };

Cfg loadCfg() {
    Cfg c;
    std::string s;
    if (!readText(kCfgPath, s)) {   // pehli baar: default likh do, taaki user ko dikhe
        mkdir(kDir, 0777);
        writeText(kCfgPath,
                  "# No Fall Damage config\n"
                  "# offset = libminecraftpe.so ke andar function ka RVA (Zaphkiel wala)\n"
                  "offset=0xf28e710\n"
                  "# mode: ret0 = (mov x0,#0 ; ret)   |   ret = sirf ret\n"
                  "mode=ret0\n");
        return c;
    }
    size_t i = 0;
    while (i < s.size()) {
        size_t e = s.find('\n', i);
        if (e == std::string::npos) e = s.size();
        std::string line = s.substr(i, e - i);
        i = e + 1;
        while (!line.empty() && (line.back() == '\r' || line.back() == ' ')) line.pop_back();
        if (line.empty() || line[0] == '#') continue;
        const size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        const std::string k = line.substr(0, eq), v = line.substr(eq + 1);
        if (k == "offset") c.offset = std::strtoull(v.c_str(), nullptr, 0);
        else if (k == "mode") c.ret0 = (v != "ret");
    }
    return c;
}

// ------------------------------------------------------------ module lookup (dl_iterate_phdr)
struct FindCtx {
    explicit FindCtx(const char* n) : name(n) {}
    const char* name;
    bool found = false;
    uintptr_t bias = 0;
    std::vector<std::pair<uint64_t, uint64_t>> exec;   // executable PT_LOAD [vaddr, end)
};
int phdrCb(struct dl_phdr_info* info, size_t, void* data) {
    auto* c = static_cast<FindCtx*>(data);
    if (!info->dlpi_name || !*info->dlpi_name) return 0;
    const size_t L = std::strlen(info->dlpi_name), M = std::strlen(c->name);
    if (L < M || std::strcmp(info->dlpi_name + L - M, c->name) != 0) return 0;
    c->found = true;
    c->bias = (uintptr_t)info->dlpi_addr;
    for (int i = 0; i < info->dlpi_phnum; ++i) {
        const ElfW(Phdr)& ph = info->dlpi_phdr[i];
        if (ph.p_type == PT_LOAD && (ph.p_flags & PF_X))
            c->exec.push_back({ (uint64_t)ph.p_vaddr, (uint64_t)ph.p_vaddr + ph.p_memsz });
    }
    return 1;
}

// ------------------------------------------------------------ code write (atomic jahan ho sake)
void writeCode(uintptr_t addr, const uint8_t* src, size_t len) {
    if (len == 8 && (addr & 7) == 0) {
        uint64_t v; std::memcpy(&v, src, 8);
        __atomic_store_n(reinterpret_cast<uint64_t*>(addr), v, __ATOMIC_RELEASE);
    } else if (len == 4 && (addr & 3) == 0) {
        uint32_t v; std::memcpy(&v, src, 4);
        __atomic_store_n(reinterpret_cast<uint32_t*>(addr), v, __ATOMIC_RELEASE);
    } else {
        std::memcpy(reinterpret_cast<void*>(addr), src, len);
    }
    __builtin___clear_cache(reinterpret_cast<char*>(addr), reinterpret_cast<char*>(addr + len));
}

bool protectRWX(uintptr_t addr, size_t len, int prot) {
    const uintptr_t page = (uintptr_t)sysconf(_SC_PAGESIZE);
    const uintptr_t start = addr & ~(page - 1);
    const uintptr_t end = (addr + len + page - 1) & ~(page - 1);
    return mprotect(reinterpret_cast<void*>(start), end - start, prot) == 0;
}

enum ApplyResult { AR_OK, AR_NOT_LOADED, AR_REFUSED, AR_FAIL };

ApplyResult applyPatch() {
    std::lock_guard<std::mutex> l(g_Mx);
    if (g_P.applied) { logf("already ON"); return AR_OK; }

    const Cfg cfg = loadCfg();
    const uint8_t* patch = cfg.ret0 ? kRet0 : kRet;
    const size_t plen = cfg.ret0 ? sizeof(kRet0) : sizeof(kRet);

    FindCtx ctx(NOFALL_LIB);
    dl_iterate_phdr(phdrCb, &ctx);
    if (!ctx.found) { logf("%s abhi load nahi hui", NOFALL_LIB); return AR_NOT_LOADED; }

    bool inExec = false;
    for (auto& r : ctx.exec)
        if (cfg.offset >= r.first && cfg.offset + kBaseLen <= r.second) { inExec = true; break; }
    if (!inExec) {
        logf("REFUSE: offset 0x%llx executable segment me nahi (game version alag?)", (unsigned long long)cfg.offset);
        return AR_REFUSED;
    }

    const uintptr_t addr = ctx.bias + (uintptr_t)cfg.offset;
    if (!protectRWX(addr, kBaseLen, PROT_READ | PROT_WRITE | PROT_EXEC)) {
        logf("FAIL: mprotect RWX nahi hua (errno=%d)", errno);
        return AR_FAIL;
    }

    uint8_t cur[kBaseLen];
    std::memcpy(cur, reinterpret_cast<void*>(addr), kBaseLen);
    logf("base=0x%llx addr=0x%llx bytes=%s", (unsigned long long)ctx.bias, (unsigned long long)addr, hexOf(cur, kBaseLen).c_str());

    // pehle se patched dikh raha hai?
    if (std::memcmp(cur, patch, plen) == 0) {
        protectRWX(addr, kBaseLen, PROT_READ | PROT_EXEC);
        logf("REFUSE: bytes pehle se patch jaise hain - original pata nahi");
        return AR_REFUSED;
    }

    // baseline: pehli baar save, baad me game-update check
    char want[48];
    std::snprintf(want, sizeof(want), "offset=0x%llx\nbytes=", (unsigned long long)cfg.offset);
    std::string base;
    const bool haveBase = readText(kBasePath, base) && base.compare(0, std::strlen(want), want) == 0;
    if (haveBase) {
        const std::string saved = base.substr(std::strlen(want), kBaseLen * 2);
        if (saved != hexOf(cur, kBaseLen)) {
            protectRWX(addr, kBaseLen, PROT_READ | PROT_EXEC);
            logf("REFUSE: game update lagta hai (saved=%s abhi=%s). Naya offset nofall.cfg me daalo aur nofall_base.txt hata do",
                 saved.c_str(), hexOf(cur, kBaseLen).c_str());
            return AR_REFUSED;
        }
    } else {
        mkdir(kDir, 0777);
        writeText(kBasePath, std::string(want) + hexOf(cur, kBaseLen) + "\n");
        logf("baseline save hui (pehli baar is offset ke liye)");
    }

    std::memcpy(g_P.orig, cur, kBaseLen);
    g_P.addr = addr;
    g_P.len = plen;
    writeCode(addr, patch, plen);
    protectRWX(addr, kBaseLen, PROT_READ | PROT_EXEC);

    if (std::memcmp(reinterpret_cast<void*>(addr), patch, plen) != 0) {
        logf("FAIL: likhne ke baad verify nahi hua");
        writeCode(addr, g_P.orig, plen);
        return AR_FAIL;
    }
    g_P.applied = true;
    logf("ON: patch laga (%s, %zu bytes)", cfg.ret0 ? "ret0" : "ret", plen);
    return AR_OK;
}

void removePatch() {
    std::lock_guard<std::mutex> l(g_Mx);
    if (!g_P.applied) return;
    protectRWX(g_P.addr, kBaseLen, PROT_READ | PROT_WRITE | PROT_EXEC);
    writeCode(g_P.addr, g_P.orig, g_P.len);
    protectRWX(g_P.addr, kBaseLen, PROT_READ | PROT_EXEC);
    g_P.applied = false;
    logf("OFF: original bytes wapas");
}

void retryLoop() {   // toggle ON tha par game lib abhi load nahi: 1s ke gap pe 120 baar
    for (int i = 0; i < 120 && g_Want.load(); ++i) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
        if (!g_Want.load()) break;
        if (applyPatch() != AR_NOT_LOADED) break;
    }
    g_RetryRunning = false;
}

void startApply() {
    const ApplyResult r = applyPatch();
    if (r == AR_NOT_LOADED && !g_RetryRunning.exchange(true)) std::thread(retryLoop).detach();
}

void onToggle(std::string_view moduleId, bool enabled) {
    if (moduleId != kModuleId) return;
    g_Want = enabled;
    if (enabled) startApply();
    else removePatch();
}

}  // namespace

class NoFallMod {
public:
    static NoFallMod& instance() { static NoFallMod m; return m; }
    NoFallMod() : mSelf(*ll::mod::NativeMod::current()) {}
    ll::mod::NativeMod& getSelf() const { return mSelf; }

    bool load() {
        trimLog();
        getSelf().getLogger().info("No Fall Damage loaded");
        logf("loaded");
        return true;
    }

    bool enable() {
        const bool ok = pl::modmenu::ModuleBuilder(std::string(kModuleId), "No Fall Damage")
                            .modId(getSelf().getId())
                            .description("Fall damage band. OFF karte hi original code wapas.")
                            .defaultEnabled(false)
                            .onToggle(onToggle)
                            .registerModule();
        logf("Menu register: %s", ok ? "OK" : "FAIL");
        return true;
    }

    bool disable() {
        g_Want = false;
        removePatch();
        pl::modmenu::unregisterModule(kModuleId);
        return true;
    }

    bool unload() { removePatch(); return true; }

private:
    ll::mod::NativeMod& mSelf;
};

PL_REGISTER_MOD(NoFallMod, NoFallMod::instance())
