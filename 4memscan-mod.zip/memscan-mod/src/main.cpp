// Mem Scanner v2 - Cheat Engine jaisa chhota memory scanner (in-process, ImGui)
//   v2: COMPLETE scan (page-grouped compact store, 40M tak, koi 300k cap-bias nahi), CE jaisa New Scan reset,
//       safe read/write (direct memmove fallback HATA - wahi crash karta tha), plain 0x address, log file, selftest.
//   Engine: New Scan -> ResultList -> Next Scan (filter) -> Add -> ActiveList -> Edit / Lock.  Undo = stack.
//   Value types : Auto, Byte, 2 Bytes, 4 Bytes, 8 Bytes, Float, Double      (CE jaise)
//   Scan types  : Exact, Bigger, Smaller, Between | Increased(+by), Decreased(+by), Changed, Unchanged
//   Safety      : /proc/self/mem se padhna/likhna (galat address = error, crash nahi), mincore se sirf resident pages,
//                 apni result arrays scan se bahar (exclusion), GPU/device mappings skip.
#include <jni.h>
#include <android/input.h>
#include <android/keycodes.h>
#include <android/log.h>
#include <EGL/egl.h>
#include <pthread.h>
#include <unistd.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <sched.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/uio.h>
#include <cstdarg>

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cfloat>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <memory>
#include <mutex>
#include <string>
#include <string_view>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <vector>

#include <pl/Mod.hpp>
#include <pl/ModMenu.hpp>
#include <pl/Input.hpp>
#include <pl/Logger.hpp>
#include <pl/memory/Hook.hpp>

#include "ImGui/imgui.h"
#include "ImGui/backends/imgui_impl_android.h"
#include "ImGui/backends/imgui_impl_opengl3.h"

#define TAG "MemScan"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)

namespace {

constexpr std::string_view kModuleId = "memscan.main";

#ifndef MS_ROOT
#define MS_ROOT "/storage/emulated/0/Android/media/org.levimc.launcher/"
#endif
#ifndef MS_LIB
#define MS_LIB "libminecraftpe.so"
#endif
const char* kHomeDir = MS_ROOT "levire/";
const char* kCfgPath = MS_ROOT "levire/memscan.cfg";
const char* kLogPath = MS_ROOT "levire/memscan_log.txt";
const char* kFontCandidates[] = {
    "/system/fonts/Roboto-Regular.ttf", "/system/fonts/RobotoStatic-Regular.ttf",
    "/system/fonts/NotoSans-Regular.ttf", "/system/fonts/DroidSans.ttf",
};

constexpr float kMinScale = 0.7f, kMaxScale = 2.0f;
constexpr float kBaseW = 1040.0f, kBaseH = 620.0f;
constexpr float kScreenFrac = 0.96f;
constexpr size_t kMaxEntries = 40u * 1000 * 1000;   // andar itne results tak (2 byte each = 80MB max)
constexpr size_t kMaxPages = 2u * 1000 * 1000;
constexpr size_t kPrevCap = 4u * 1000 * 1000;       // previous values sirf itne results tak (Changed/Increased ke liye)
constexpr size_t kShowMax = 3000;                   // UI me pehle itne
constexpr size_t kMaxActive = 256;
constexpr size_t kUndoDepth = 3;
constexpr size_t kUndoMemMax = 160u * 1024 * 1024;

// ------------------------------------------------------------ theme (mockup: dark #2A2A2A + blue)
const ImVec4 C_WIN   (0.165f, 0.165f, 0.165f, 1.0f);   // #2A2A2A
const ImVec4 C_CARD  (0.145f, 0.145f, 0.145f, 1.0f);   // #252525
const ImVec4 C_FRAME (0.122f, 0.122f, 0.122f, 1.0f);   // #1F1F1F
const ImVec4 C_BORDER(0.227f, 0.227f, 0.227f, 1.0f);   // #3A3A3A
const ImVec4 C_TEXT  (0.902f, 0.902f, 0.902f, 1.0f);   // #E6E6E6
const ImVec4 C_DIM   (0.478f, 0.478f, 0.478f, 1.0f);
const ImVec4 C_BLUE  (0.184f, 0.435f, 0.871f, 1.0f);   // #2F6FDE
const ImVec4 C_BLUE_H(0.208f, 0.478f, 0.941f, 1.0f);
const ImVec4 C_SELROW(0.184f, 0.302f, 0.541f, 0.60f);  // #2F4D8A
const ImVec4 C_GREEN (0.165f, 0.420f, 0.196f, 1.0f);   // #2A6B32
const ImVec4 C_GREEN_H(0.200f, 0.498f, 0.235f, 1.0f);
const ImVec4 C_RED   (0.290f, 0.133f, 0.133f, 1.0f);   // #4A2222
const ImVec4 C_RED_TX(1.000f, 0.541f, 0.541f, 1.0f);   // #FF8A8A
const ImVec4 C_AMBER (0.95f, 0.75f, 0.30f, 1.0f);
const ImVec4 C_OKTXT (0.498f, 0.871f, 0.541f, 1.0f);   // #7FDE8A

// ------------------------------------------------------------ state
std::atomic_bool g_Visible{false};
std::atomic_bool g_Initialized{false};
std::atomic_bool g_ResetInput{false};
std::atomic_bool g_WantText{false};
std::atomic<float> g_TargetScale{1.1f};
std::atomic<float> g_Opacity{0.97f};
std::atomic<float> g_PosXPct{3.0f};
std::atomic<float> g_PosYPct{4.0f};
std::atomic<float> g_RectX{0}, g_RectY{0}, g_RectW{0}, g_RectH{0};

float g_AppliedScale = -1.0f;
double g_LastRebuild = 0.0, g_LastSave = 0.0;
bool  g_DeviceReady = false;
int   g_Width = 0, g_Height = 0;
EGLContext g_TargetContext = EGL_NO_CONTEXT;
EGLSurface g_TargetSurface = EGL_NO_SURFACE;

bool g_HasCfgCallback = false;

// status (scan thread bhi likhta hai)
std::mutex g_StatusMx;
std::string g_StatusStr = "Ready. Value likho aur First Scan dabao.";
void setStatus(const std::string& s) { std::lock_guard<std::mutex> l(g_StatusMx); g_StatusStr = s; }
std::string getStatus() { std::lock_guard<std::mutex> l(g_StatusMx); return g_StatusStr; }

// log: logcat + levire/memscan_log.txt (crash ke baad bhi dekh sakte ho kya chal raha tha)
std::mutex g_LogMx;
void logf(const char* fmt, ...) {
    char msg[400];
    va_list ap; va_start(ap, fmt);
    std::vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);
    __android_log_print(ANDROID_LOG_INFO, TAG, "%s", msg);
    std::lock_guard<std::mutex> l(g_LogMx);
    mkdir(kHomeDir, 0777);
    FILE* f = std::fopen(kLogPath, "a");
    if (!f) return;
    time_t t = time(nullptr); struct tm tmv; localtime_r(&t, &tmv);
    std::fprintf(f, "%02d:%02d:%02d %s\n", tmv.tm_hour, tmv.tm_min, tmv.tm_sec, msg);
    std::fclose(f);
}
void trimLog() {
    struct stat s;
    if (stat(kLogPath, &s) == 0 && s.st_size > 128 * 1024) std::remove(kLogPath);
}

double nowSec() {
    using namespace std::chrono;
    return duration_cast<duration<double>>(steady_clock::now().time_since_epoch()).count();
}

// ------------------------------------------------------------ config
void saveConfig() {
    mkdir(kHomeDir, 0777);
    char b[300];
    std::snprintf(b, sizeof(b), "scale=%f\nopacity=%f\nposx=%f\nposy=%f\n",
                  g_TargetScale.load(), g_Opacity.load(), g_PosXPct.load(), g_PosYPct.load());
    FILE* f = std::fopen(kCfgPath, "wb");
    if (!f) return;
    std::fwrite(b, 1, std::strlen(b), f);
    std::fclose(f);
}
void loadConfig() {
    FILE* f = std::fopen(kCfgPath, "rb");
    if (!f) return;
    char line[128];
    while (std::fgets(line, sizeof(line), f)) {
        char* eq = std::strchr(line, '=');
        if (!eq) continue;
        *eq = 0;
        const float v = (float)std::atof(eq + 1);
        if (!std::strcmp(line, "scale") && v >= kMinScale && v <= kMaxScale) g_TargetScale = v;
        else if (!std::strcmp(line, "opacity") && v >= 0.2f && v <= 1.0f) g_Opacity = v;
        else if (!std::strcmp(line, "posx") && v >= 0 && v <= 100) g_PosXPct = v;
        else if (!std::strcmp(line, "posy") && v >= 0 && v <= 100) g_PosYPct = v;
    }
    std::fclose(f);
}

// ============================================================ ENGINE
enum VType { VT_U8, VT_U16, VT_I32, VT_I64, VT_F32, VT_F64, VT_COUNT };
const int   kVSize[VT_COUNT]  = { 1, 2, 4, 8, 4, 8 };
const char* kVShort[VT_COUNT] = { "1B", "2B", "4B", "8B", "Flt", "Dbl" };
const char* kTypeNames[7] = { "Auto", "Byte", "2 Bytes", "4 Bytes", "8 Bytes", "Float", "Double" };

enum Cond { C_EXACT, C_BIGGER, C_SMALLER, C_BETWEEN, C_INC, C_INCBY, C_DEC, C_DECBY, C_CHANGED, C_UNCHANGED, C_COUNT };
const char* kCondNames[C_COUNT] = {
    "Exact Value", "Bigger than...", "Smaller than...", "Value between...",
    "Increased value", "Increased value by...", "Decreased value", "Decreased value by...",
    "Changed value", "Unchanged value",
};
bool condFirstOk(int c) { return c <= C_BETWEEN; }
bool condNeedsValue(int c) { return c == C_EXACT || c == C_BIGGER || c == C_SMALLER || c == C_BETWEEN || c == C_INCBY || c == C_DECBY; }

struct Result { uint64_t addr; uint64_t prev; uint8_t type; };
struct PageRec { uint64_t page; uint32_t start; uint32_t count; };

// --- apni arrays scan se bahar rakhne ke liye exclusion registry
std::mutex g_ExMx;
std::vector<std::pair<uintptr_t, uintptr_t>> g_Excl;
void exclAdd(void* p, size_t n) { std::lock_guard<std::mutex> l(g_ExMx); g_Excl.push_back({ (uintptr_t)p, (uintptr_t)p + n }); }
void exclRemove(void* p) {
    std::lock_guard<std::mutex> l(g_ExMx);
    for (size_t i = 0; i < g_Excl.size(); ++i) if (g_Excl[i].first == (uintptr_t)p) { g_Excl.erase(g_Excl.begin() + (long)i); return; }
}

// Result store: page-wise grouped. Har result = 2 byte (12 bit offset + 3 bit type). 40M results = 80MB.
// Sab kuch mmap me (registered) taaki scan apne hi results ko na dhoondhe.
struct Store {
    struct Map { void* p = nullptr; size_t b = 0; };
    PageRec* pages = nullptr; size_t np = 0, capPages = 0;
    uint16_t* ent = nullptr;  size_t n = 0, capEnt = 0;
    uint64_t* prev = nullptr; size_t capPrev = 0;
    Result* shown = nullptr;  size_t nshown = 0;
    bool hasPrev = true, capped = false, floatLoose = false, ok = false;
    int scanNo = 0;
    unsigned typeMask = 0;
    Map m[4];

    static void* amap(size_t bytes, Map& mm) {
        bytes = (std::max<size_t>(bytes, 1) + 4095) & ~(size_t)4095;
        void* p = mmap(nullptr, bytes, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (p == MAP_FAILED) return nullptr;
        mm.p = p; mm.b = bytes; exclAdd(p, bytes);
        return p;
    }
    Store(size_t entCap, size_t pageCap, size_t prevCap) {
        capEnt = std::max<size_t>(entCap, 1); capPages = std::max<size_t>(pageCap, 1); capPrev = prevCap;
        pages = (PageRec*)amap(capPages * sizeof(PageRec), m[0]);
        ent = (uint16_t*)amap(capEnt * 2, m[1]);
        prev = (uint64_t*)amap(std::max<size_t>(capPrev, 1) * 8, m[2]);
        shown = (Result*)amap(kShowMax * sizeof(Result), m[3]);
        ok = pages && ent && prev && shown;
    }
    ~Store() { for (auto& x : m) if (x.p) { exclRemove(x.p); munmap(x.p, x.b); } }
    Store(const Store&) = delete;
    Store& operator=(const Store&) = delete;

    bool add(uint64_t addr, int type, uint64_t prevRaw) {
        if (n >= capEnt) { capped = true; return false; }
        const uint64_t pg = addr & ~(uint64_t)4095;
        if (np == 0 || pages[np - 1].page != pg) {
            if (np >= capPages) { capped = true; return false; }
            pages[np++] = { pg, (uint32_t)n, 0 };
        }
        ent[n] = (uint16_t)((addr & 4095) | ((unsigned)type << 12));
        if (n < capPrev) prev[n] = prevRaw; else hasPrev = false;
        pages[np - 1].count++;
        if (nshown < kShowMax) shown[nshown++] = { addr, prevRaw, (uint8_t)type };
        typeMask |= 1u << type;
        ++n;
        return true;
    }
    void finalize() { std::sort(shown, shown + nshown, [](const Result& a, const Result& b) { return a.addr < b.addr; }); }
    size_t memBytes() const { return np * sizeof(PageRec) + n * 2 + std::min(n, capPrev) * 8; }
};
using StorePtr = std::shared_ptr<Store>;

// --- memory I/O (SAFE): kabhi direct deref nahi. Galat/stale address = sirf false, crash nahi.
int g_MemFd = -1;
bool g_MemRW = false;
std::mutex g_FdMx;
std::atomic<int> g_WriteMethod{-1};     // selftest se: 0 pwrite, 1 process_vm_writev, 2 direct (rw-checked)
std::string g_MemStatus = "mem: ?";
int memFd() {
    if (g_MemFd >= 0) return g_MemFd;
    std::lock_guard<std::mutex> l(g_FdMx);
    if (g_MemFd >= 0) return g_MemFd;
    int fd = open("/proc/self/mem", O_RDWR | O_CLOEXEC);
    if (fd >= 0) g_MemRW = true; else fd = open("/proc/self/mem", O_RDONLY | O_CLOEXEC);
    g_MemFd = fd;
    return fd;
}
bool readMem(uint64_t a, void* b, size_t n) {
    if (a < 0x10000) return false;
    const int fd = memFd();
    if (fd >= 0 && pread(fd, b, n, (off_t)a) == (ssize_t)n) return true;
    struct iovec l{ b, n }, r{ (void*)(uintptr_t)a, n };
    return process_vm_readv(getpid(), &l, 1, &r, 1, 0) == (ssize_t)n;   // fail = -1, crash nahi
}
// direct write sirf tab jab address abhi bhi rw mapping me ho (taza maps padh ke)
bool isRwMapped(uint64_t a, size_t n) {
    FILE* f = std::fopen("/proc/self/maps", "r");
    if (!f) return false;
    char line[1280]; bool ok = false;
    while (std::fgets(line, sizeof(line), f)) {
        unsigned long long s = 0, e = 0; char perms[8] = {};
        if (std::sscanf(line, "%llx-%llx %7s", &s, &e, perms) < 3) continue;
        if (a >= s && a + n <= e) { ok = (perms[0] == 'r' && perms[1] == 'w'); break; }
    }
    std::fclose(f);
    return ok;
}
bool writeVia(int method, uint64_t a, const void* b, size_t n) {
    if (a < 0x10000) return false;
    switch (method) {
        case 0: { const int fd = memFd(); return fd >= 0 && g_MemRW && pwrite(fd, b, n, (off_t)a) == (ssize_t)n; }
        case 1: { struct iovec l{ (void*)b, n }, r{ (void*)(uintptr_t)a, n };
                  return process_vm_writev(getpid(), &l, 1, &r, 1, 0) == (ssize_t)n; }
        case 2: { if (!isRwMapped(a, n)) return false; std::memcpy((void*)(uintptr_t)a, b, n); return true; }
    }
    return false;
}
bool writeMem(uint64_t a, const void* b, size_t n) {
    const int pref = g_WriteMethod.load();
    if (pref >= 0 && writeVia(pref, a, b, n)) return true;
    for (int m = 0; m < 3; ++m) if (m != pref && writeVia(m, a, b, n)) return true;
    return false;
}
void memSelfTest() {
    static volatile uint32_t var;
    var = 0x01020304;
    uint32_t cur = 0;
    const bool rd = readMem((uint64_t)(uintptr_t)&var, &cur, 4) && cur == 0x01020304;
    bool ok[3] = {};
    for (int m = 0; m < 3; ++m) {
        const uint32_t v = 0xA5A50000u + (uint32_t)m;
        ok[m] = writeVia(m, (uint64_t)(uintptr_t)&var, &v, 4) && var == v;
    }
    int pick = -1;
    for (int m = 0; m < 3; ++m) if (ok[m]) { pick = m; break; }
    g_WriteMethod = pick;
    static const char* nm[3] = { "pwrite", "pvm", "direct" };
    char b[120];
    std::snprintf(b, sizeof(b), pick >= 0 ? "mem OK (r:%d w:%s)" : "mem WRITE BLOCKED (r:%d)", rd ? 1 : 0, pick >= 0 ? nm[pick] : "-");
    g_MemStatus = b;
    logf("selftest: read=%d pwrite=%d pvm=%d direct=%d -> %s", rd, ok[0], ok[1], ok[2], b);
}

// --- value parse / format
struct Parsed { bool ok = false, frac = false; int64_t i = 0; double d = 0; int dec = 0; };
Parsed parseNum(const char* s, bool hex) {
    Parsed p;
    while (*s && std::isspace((unsigned char)*s)) ++s;
    if (!*s) return p;
    char* end = nullptr;
    if (hex) {
        const char* h = s; if (h[0] == '0' && (h[1] == 'x' || h[1] == 'X')) h += 2;
        if (!*h) return p;
        const long long v = std::strtoll(h, &end, 16);
        while (*end && std::isspace((unsigned char)*end)) ++end;
        if (*end) return p;
        p.ok = true; p.i = v; p.d = (double)v;
        return p;
    }
    bool hasFrac = false;
    for (const char* c = s; *c; ++c) if (*c == '.' || *c == 'e' || *c == 'E') hasFrac = true;
    if (hasFrac) {
        const double v = std::strtod(s, &end);
        while (*end && std::isspace((unsigned char)*end)) ++end;
        if (*end || end == s || !std::isfinite(v)) return p;
        p.ok = true; p.frac = true; p.d = v; p.i = (int64_t)std::llround(v);
        const char* dot = std::strchr(s, '.');
        if (dot) { int n = 0; for (const char* c = dot + 1; std::isdigit((unsigned char)*c); ++c) ++n; p.dec = n; }
        return p;
    }
    const long long v = std::strtoll(s, &end, 10);
    while (*end && std::isspace((unsigned char)*end)) ++end;
    if (*end || end == s) return p;
    p.ok = true; p.i = v; p.d = (double)v;
    return p;
}

bool fitsType(const Parsed& p, int vt) {
    switch (vt) {
        case VT_U8:  return !p.frac && p.i >= 0 && p.i <= 255;
        case VT_U16: return !p.frac && p.i >= 0 && p.i <= 65535;
        case VT_I32: return !p.frac && p.i >= INT32_MIN && p.i <= INT32_MAX;
        case VT_I64: return !p.frac;
        default:     return true;   // float / double
    }
}

bool parseForType(const char* s, int vt, bool hex, uint64_t& raw) {
    const Parsed p = parseNum(s, hex);
    if (!p.ok || !fitsType(p, vt)) return false;
    raw = 0;
    switch (vt) {
        case VT_U8:  raw = (uint64_t)p.i; return true;
        case VT_U16: raw = (uint64_t)p.i; return true;
        case VT_I32: { int32_t v = (int32_t)p.i; std::memcpy(&raw, &v, 4); return true; }
        case VT_I64: raw = (uint64_t)p.i; return true;
        case VT_F32: { float f = (float)p.d; std::memcpy(&raw, &f, 4); return true; }
        case VT_F64: { double d = p.d; std::memcpy(&raw, &d, 8); return true; }
    }
    return false;
}

void fmtRaw(uint64_t raw, int vt, char* out, size_t n) {
    switch (vt) {
        case VT_U8:  std::snprintf(out, n, "%u", (unsigned)(raw & 0xFF)); break;
        case VT_U16: std::snprintf(out, n, "%u", (unsigned)(raw & 0xFFFF)); break;
        case VT_I32: { int32_t v; std::memcpy(&v, &raw, 4); std::snprintf(out, n, "%d", v); break; }
        case VT_I64: { int64_t v; std::memcpy(&v, &raw, 8); std::snprintf(out, n, "%lld", (long long)v); break; }
        case VT_F32: { float f; std::memcpy(&f, &raw, 4); std::snprintf(out, n, "%.6g", (double)f); break; }
        case VT_F64: { double d; std::memcpy(&d, &raw, 8); std::snprintf(out, n, "%.8g", d); break; }
        default: std::snprintf(out, n, "?");
    }
}

// --- query (scan ka sawal)
struct Query {
    int cond = C_EXACT;
    bool typeOn[VT_COUNT] = {};
    int64_t i1 = 0, i2 = 0;
    double d1 = 0, d2 = 0;
    double eps = 0.5;
};

template <class T>
inline bool matchT(T cur, T prev, const Query& q) {
    if constexpr (std::is_floating_point_v<T>) {
        const double c = (double)cur, p = (double)prev;
        if (!std::isfinite(c)) return false;
        switch (q.cond) {
            case C_EXACT:   return std::fabs(c - q.d1) <= q.eps;
            case C_BIGGER:  return c > q.d1;
            case C_SMALLER: return c < q.d1;
            case C_BETWEEN: return c >= std::min(q.d1, q.d2) && c <= std::max(q.d1, q.d2);
            case C_INC:     return c > p;
            case C_INCBY:   return std::fabs((c - p) - q.d1) <= q.eps;
            case C_DEC:     return c < p;
            case C_DECBY:   return std::fabs((p - c) - q.d1) <= q.eps;
            case C_CHANGED: return c != p;
            case C_UNCHANGED: return c == p;
        }
    } else {
        const int64_t c = (int64_t)cur, p = (int64_t)prev;
        switch (q.cond) {
            case C_EXACT:   return c == q.i1;
            case C_BIGGER:  return c > q.i1;
            case C_SMALLER: return c < q.i1;
            case C_BETWEEN: return c >= std::min(q.i1, q.i2) && c <= std::max(q.i1, q.i2);
            case C_INC:     return c > p;
            case C_INCBY:   return (c - p) == q.i1;
            case C_DEC:     return c < p;
            case C_DECBY:   return (p - c) == q.i1;
            case C_CHANGED: return c != p;
            case C_UNCHANGED: return c == p;
        }
    }
    return false;
}

bool matchRaw(int vt, uint64_t cur, uint64_t prev, const Query& q) {
    switch (vt) {
        case VT_U8:  return matchT<uint8_t>((uint8_t)cur, (uint8_t)prev, q);
        case VT_U16: return matchT<uint16_t>((uint16_t)cur, (uint16_t)prev, q);
        case VT_I32: { int32_t a, b; std::memcpy(&a, &cur, 4); std::memcpy(&b, &prev, 4); return matchT<int32_t>(a, b, q); }
        case VT_I64: { int64_t a, b; std::memcpy(&a, &cur, 8); std::memcpy(&b, &prev, 8); return matchT<int64_t>(a, b, q); }
        case VT_F32: { float a, b; std::memcpy(&a, &cur, 4); std::memcpy(&b, &prev, 4); return matchT<float>(a, b, q); }
        case VT_F64: { double a, b; std::memcpy(&a, &cur, 8); std::memcpy(&b, &prev, 8); return matchT<double>(a, b, q); }
    }
    return false;
}

// first scan: ek page (4096 byte, page-aligned) ke andar ek type
template <class T>
inline void scanPageT(const uint8_t* buf, uint64_t base, int vt, const Query& q, Store& out) {
    constexpr size_t S = sizeof(T);
    if constexpr (std::is_same_v<T, uint8_t>) {
        if (q.cond == C_EXACT) {   // fast path: memchr
            const uint8_t* p = buf; const uint8_t* end = buf + 4096; const int c = (int)q.i1;
            while (p < end && (p = (const uint8_t*)std::memchr(p, c, (size_t)(end - p)))) {
                if (!out.add(base + (uint64_t)(p - buf), vt, (uint64_t)c)) return;
                ++p;
            }
            return;
        }
    }
    for (size_t off = 0; off + S <= 4096; off += S) {
        T v;
        std::memcpy(&v, buf + off, S);
        if (!matchT<T>(v, v, q)) continue;
        uint64_t raw = 0; std::memcpy(&raw, &v, S);
        if (!out.add(base + off, vt, raw)) return;
    }
}
void scanPage(const uint8_t* buf, uint64_t base, const Query& q, Store& out) {
    if (q.typeOn[VT_U8])  scanPageT<uint8_t>(buf, base, VT_U8, q, out);
    if (out.capped) return;
    if (q.typeOn[VT_U16]) scanPageT<uint16_t>(buf, base, VT_U16, q, out);
    if (out.capped) return;
    if (q.typeOn[VT_I32]) scanPageT<int32_t>(buf, base, VT_I32, q, out);
    if (out.capped) return;
    if (q.typeOn[VT_I64]) scanPageT<int64_t>(buf, base, VT_I64, q, out);
    if (out.capped) return;
    if (q.typeOn[VT_F32]) scanPageT<float>(buf, base, VT_F32, q, out);
    if (out.capped) return;
    if (q.typeOn[VT_F64]) scanPageT<double>(buf, base, VT_F64, q, out);
}

// --- memory regions (/proc/self/maps)
struct Seg { uint64_t s, e; };
struct Maps { std::vector<Seg> game, lib; };

Maps readMaps() {
    Maps m;
    FILE* f = std::fopen("/proc/self/maps", "r");
    if (!f) return m;
    char line[1280];
    while (std::fgets(line, sizeof(line), f)) {
        unsigned long long s = 0, e = 0, off = 0; char perms[8] = {}; int n = 0;
        if (std::sscanf(line, "%llx-%llx %7s %llx %*s %*s %n", &s, &e, perms, &off, &n) < 4) continue;
        std::string path = (n > 0 && n < (int)sizeof(line)) ? std::string(line + n) : std::string();
        while (!path.empty() && (path.back() == '\n' || path.back() == ' ')) path.pop_back();
        if (perms[0] != 'r' || perms[1] != 'w' || perms[3] != 'p') continue;
        const bool isLib = path.find(MS_LIB) != std::string::npos;
        const bool anon = path.empty() || path.compare(0, 6, "[anon:") == 0 || path == "[heap]";
        if (isLib) m.lib.push_back({ s, e });
        if (anon || isLib) m.game.push_back({ s, e });
    }
    std::fclose(f);
    return m;
}

std::vector<Seg> subtractExcl(Seg r, const std::vector<std::pair<uintptr_t, uintptr_t>>& ex) {
    std::vector<Seg> cur{ r };
    for (const auto& x : ex) {
        std::vector<Seg> nx;
        for (const Seg& sgm : cur) {
            if (x.second <= sgm.s || x.first >= sgm.e) { nx.push_back(sgm); continue; }
            if (x.first > sgm.s) nx.push_back({ sgm.s, x.first });
            if (x.second < sgm.e) nx.push_back({ x.second, sgm.e });
        }
        cur.swap(nx);
    }
    return cur;
}

// --- scan orchestration
std::mutex g_Mx;
StorePtr g_Store;
std::vector<StorePtr> g_Undo;
std::vector<Seg> g_LibRanges;
uint64_t g_Gen = 0;   // result list badli (UI selection reset)
std::atomic_bool g_Scanning{false};
std::atomic_bool g_Cancel{false};
std::atomic<uint64_t> g_PDone{0}, g_PTotal{1};

void niceSelf() { setpriority(PRIO_PROCESS, (id_t)syscall(SYS_gettid), 10); }   // game ko na rokne ke liye

void pushUndoLocked(const StorePtr& s) {   // g_Mx ke andar
    g_Undo.push_back(s);
    size_t mem = 0;
    for (const auto& u : g_Undo) mem += u->memBytes();
    while (!g_Undo.empty() && (g_Undo.size() > kUndoDepth || mem > kUndoMemMax)) {
        mem -= g_Undo.front()->memBytes();
        g_Undo.erase(g_Undo.begin());
    }
}

void publish(const StorePtr& st, const Maps* maps, const char* label, double secs) {
    st->finalize();
    size_t cnt[VT_COUNT] = {};
    for (size_t i = 0; i < st->n; ++i) cnt[(st->ent[i] >> 12) & 7]++;
    std::string detail;
    for (int t = 0; t < VT_COUNT; ++t) if (cnt[t]) { char b[48]; std::snprintf(b, sizeof(b), "%s%s:%zu", detail.empty() ? "" : " ", kVShort[t], cnt[t]); detail += b; }
    {
        std::lock_guard<std::mutex> l(g_Mx);
        st->scanNo = (g_Store ? g_Store->scanNo : 0) + 1;
        if (g_Store) pushUndoLocked(g_Store);
        g_Store = st->n > 0 ? st : nullptr;   // 0 result = first-scan mode, purani list Undo me
        ++g_Gen;
        if (maps) g_LibRanges = maps->lib;
    }
    char b[240];
    if (st->n == 0) std::snprintf(b, sizeof(b), "%s: 0 results (%.1fs). Undo se pichli list wapas aa jayegi.", label, secs);
    else std::snprintf(b, sizeof(b), "%s #%d: %zu results (%.1fs)  [%s]%s", label, st->scanNo, st->n, secs, detail.c_str(),
                       st->hasPrev ? "" : "  (bahut zyada: Changed/Increased abhi nahi, pehle Exact se narrow karo)");
    setStatus(b);
    logf("%s", b);
}

void runFirstScan(Query q, bool libOnly, bool floatLoose) {
    niceSelf();
    const double t0 = nowSec();
    g_PDone = 0; g_PTotal = 1;
    auto store = std::make_shared<Store>(kMaxEntries, kMaxPages, kPrevCap);
    constexpr size_t kChunk = 1 << 20;
    uint8_t* cb = (uint8_t*)mmap(nullptr, kChunk, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (!store->ok || cb == MAP_FAILED) {
        if (cb != MAP_FAILED) munmap(cb, kChunk);
        setStatus("Scan fail: memory nahi mili"); logf("first scan: mmap fail"); g_Scanning = false; return;
    }
    store->floatLoose = floatLoose;
    exclAdd(cb, kChunk);
    const Maps maps = readMaps();
    std::vector<std::pair<uintptr_t, uintptr_t>> ex;
    { std::lock_guard<std::mutex> l(g_ExMx); ex = g_Excl; }
    std::vector<Seg> segs;
    for (const Seg& r : (libOnly ? maps.lib : maps.game)) for (const Seg& s : subtractExcl(r, ex)) segs.push_back(s);
    uint64_t total = 0;
    for (const Seg& s : segs) total += s.e - s.s;
    g_PTotal = std::max<uint64_t>(total, 1);
    logf("first scan start: cond=%d types=%d%d%d%d%d%d regions=%zu bytes=%llu libOnly=%d", q.cond,
         q.typeOn[0], q.typeOn[1], q.typeOn[2], q.typeOn[3], q.typeOn[4], q.typeOn[5], segs.size(), (unsigned long long)total, libOnly);

    const int fd = memFd();
    unsigned chunkNo = 0;
    for (const Seg& sg : segs) {
        for (uint64_t cs = sg.s; cs < sg.e && !store->capped; cs += kChunk) {
            if (g_Cancel.load()) break;
            const size_t len = (size_t)std::min<uint64_t>(kChunk, sg.e - cs);
            unsigned char vec[kChunk / 4096 + 1];
            if (mincore((void*)cs, len, vec) != 0) { g_PDone += len; continue; }   // resident pages hi
            const size_t pages = len / 4096;
            size_t i = 0;
            while (i < pages && !store->capped) {
                if (!(vec[i] & 1)) { ++i; continue; }
                size_t j = i;
                while (j < pages && (vec[j] & 1)) ++j;
                const uint64_t rs = cs + (uint64_t)i * 4096;
                const size_t rl = (j - i) * 4096;
                const ssize_t got = (fd >= 0) ? pread(fd, cb, rl, (off_t)rs) : -1;   // fail = skip (direct read NAHI)
                if (got > 0)
                    for (size_t k = 0; k < (size_t)got / 4096 && !store->capped; ++k) scanPage(cb + k * 4096, rs + k * 4096, q, *store);
                i = j;
            }
            g_PDone += len;
            if ((++chunkNo & 7) == 0) sched_yield();
        }
        if (g_Cancel.load() || store->capped) break;
    }
    exclRemove(cb);
    munmap(cb, kChunk);
    const double secs = nowSec() - t0;
    if (g_Cancel.load()) { setStatus("Scan cancel kiya"); logf("first scan cancelled"); }
    else if (store->capped) {
        char b[260]; std::snprintf(b, sizeof(b), "TOO MANY results (>%zuM): ye value bahut common hai. Dusri value ya type (4 Bytes/Float) chuno. (Purani list safe hai)", kMaxEntries / 1000000);
        setStatus(b); logf("first scan: capped after %.1fs", secs);
    }
    else publish(store, &maps, "Scan", secs);
    g_Scanning = false;
}

void runNextScan(StorePtr src, Query q) {
    niceSelf();
    const double t0 = nowSec();
    g_PDone = 0; g_PTotal = std::max<uint64_t>(src->np, 1);
    auto store = std::make_shared<Store>(src->n, src->np + 16, std::min(src->n, kPrevCap));
    constexpr size_t kBuf = 4096;
    uint8_t* pb = (uint8_t*)mmap(nullptr, kBuf, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (!store->ok || pb == MAP_FAILED) {
        if (pb != MAP_FAILED) munmap(pb, kBuf);
        setStatus("Scan fail: memory nahi mili"); g_Scanning = false; return;
    }
    exclAdd(pb, kBuf);
    store->floatLoose = src->floatLoose;
    for (size_t pi = 0; pi < src->np; ++pi) {
        if ((pi & 1023) == 0) { g_PDone = pi; if (g_Cancel.load()) break; if ((pi & 8191) == 0) sched_yield(); }
        const PageRec& rec = src->pages[pi];
        const bool wholePage = rec.count > 3;
        bool pageOk = false;
        if (wholePage) pageOk = readMem(rec.page, pb, 4096);
        for (uint32_t k = 0; k < rec.count; ++k) {
            const size_t idx = (size_t)rec.start + k;
            const uint16_t e = src->ent[idx];
            const int vt = (e >> 12) & 7;
            if (vt >= VT_COUNT || !q.typeOn[vt]) continue;
            const size_t off = e & 4095, sz = (size_t)kVSize[vt];
            if (off + sz > 4096) continue;
            uint64_t raw = 0;
            if (wholePage) { if (!pageOk) continue; std::memcpy(&raw, pb + off, sz); }
            else if (!readMem(rec.page + off, &raw, sz)) continue;
            const uint64_t pv = (src->hasPrev && idx < src->capPrev) ? src->prev[idx] : 0;
            if (!matchRaw(vt, raw, pv, q)) continue;
            if (!store->add(rec.page + off, vt, raw)) break;
        }
    }
    exclRemove(pb);
    munmap(pb, kBuf);
    if (g_Cancel.load()) { setStatus("Scan cancel kiya"); logf("next scan cancelled"); }
    else publish(store, nullptr, "Next scan", nowSec() - t0);
    g_Scanning = false;
}

bool doUndo() {
    std::lock_guard<std::mutex> l(g_Mx);
    if (g_Undo.empty()) return false;
    g_Store = g_Undo.back();
    g_Undo.pop_back();
    ++g_Gen;
    return true;
}
void resetScan() {   // CE ka "New Scan": results hata do, type/value phir se chun sako
    std::lock_guard<std::mutex> l(g_Mx);
    if (g_Store) pushUndoLocked(g_Store);
    g_Store = nullptr;
    ++g_Gen;
}
bool condNeedsPrev(int c) { return c == C_INC || c == C_INCBY || c == C_DEC || c == C_DECBY || c == C_CHANGED || c == C_UNCHANGED; }

// --- query banana (UI text -> Query)
bool buildQuery(const char* t1, const char* t2, bool hex, int typeSel, int cond, bool nextScan, Query& q, std::string& err, bool floatLoose = false) {
    q = Query();
    q.cond = cond;
    Parsed p1, p2;
    if (condNeedsValue(cond)) {
        p1 = parseNum(t1, hex);
        if (!p1.ok) { err = "Value galat/khali hai"; return false; }
        if (cond == C_BETWEEN) {
            p2 = parseNum(t2, hex);
            if (!p2.ok) { err = "Between ke liye dono value chahiye"; return false; }
        }
        q.i1 = p1.i; q.i2 = p2.i; q.d1 = p1.d; q.d2 = p2.d;
        // CE "Rounded": decimals jitne type kiye utni tolerance. Integer text pe float: Auto me tight (1 -> 1.0, 2.5 nahi);
        // explicit Float/Double me CE jaisa (rounded). Next scan me store ka flag.
        q.eps = p1.frac ? 0.5 * std::pow(10.0, -(double)p1.dec) : (typeSel >= 5 ? 0.5 : 0.001);
    }
    if (nextScan) {
        // types results se aate hain; value jis type me fit ho wahi chalte hain
        if (condNeedsValue(cond) && !p1.frac && floatLoose) q.eps = 0.5;
        for (int t = 0; t < VT_COUNT; ++t)
            q.typeOn[t] = condNeedsValue(cond) ? (fitsType(p1, t) && (cond != C_BETWEEN || fitsType(p2, t))) : true;
        return true;
    }
    if (typeSel == 0) {   // Auto
        if (p1.frac) { q.typeOn[VT_F32] = true; q.typeOn[VT_F64] = true; }
        else {
            q.typeOn[VT_U8]  = fitsType(p1, VT_U8);
            q.typeOn[VT_U16] = fitsType(p1, VT_U16);
            q.typeOn[VT_I32] = fitsType(p1, VT_I32);
            q.typeOn[VT_F32] = true;
        }
    } else {
        const int vt = typeSel - 1;   // Byte,2B,4B,8B,Float,Double
        if (!fitsType(p1, vt) || (cond == C_BETWEEN && !fitsType(p2, vt))) { err = "Ye value is type me fit nahi hoti"; return false; }
        q.typeOn[vt] = true;
    }
    return true;
}

// ============================================================ ACTIVE LIST + LOCK
struct Active {
    uint64_t addr = 0;
    uint8_t type = 0;
    bool sel = false, locked = false;
    int fails = 0;
    uint64_t lockRaw = 0;
    char newBuf[40] = {};
};
std::mutex g_ActMx;
std::vector<Active> g_Active;

void lockThread() {
    for (;;) {
        usleep(100000);   // 100 ms
        std::lock_guard<std::mutex> l(g_ActMx);
        for (Active& a : g_Active) {
            if (!a.locked) continue;
            if (writeMem(a.addr, &a.lockRaw, (size_t)kVSize[a.type])) a.fails = 0;
            else if (++a.fails >= 5) {   // address ab valid nahi: lock band (bekar likhna = corruption)
                a.locked = false;
                setStatus("Lock band: address invalid ho gaya (write fail)");
                logf("lock off: write fail @0x%llX", (unsigned long long)a.addr);
            }
        }
    }
}

// ============================================================ INPUT (touch/key -> ImGui)
struct InEv {
    enum Type { Pos, Btn, Char, KeyDown, KeyUp } type;
    float x = 0, y = 0;
    bool down = false;
    unsigned int ch = 0;
    int code = 0;
};
std::mutex g_QMutex;
std::vector<InEv> g_Queue;
std::vector<int> g_ToRelease;
void pushEv(const InEv& e) { std::lock_guard<std::mutex> l(g_QMutex); if (g_Queue.size() < 512) g_Queue.push_back(e); }
bool insideRect(float x, float y) {
    const float m = 6.0f, rw = g_RectW.load(), rh = g_RectH.load();
    if (rw <= 0 || rh <= 0) return false;
    const float rx = g_RectX.load(), ry = g_RectY.load();
    return x >= rx - m && x <= rx + rw + m && y >= ry - m && y <= ry + rh + m;
}
int g_Follow = -1;
bool g_Owned = false;
bool onTouch(const pl::input::TouchEvent& e) {
    static std::atomic_bool logged{false};
    if (!logged.exchange(true)) LOGI("touch callback: alive");
    if (!g_Visible.load() || !g_Initialized.load()) { g_Follow = -1; g_Owned = false; return false; }
    const int act = e.action & 0xFF;
    const bool isDown = (act == AMOTION_EVENT_ACTION_DOWN || act == AMOTION_EVENT_ACTION_POINTER_DOWN);
    const bool isUp = (act == AMOTION_EVENT_ACTION_UP || act == AMOTION_EVENT_ACTION_POINTER_UP || act == AMOTION_EVENT_ACTION_CANCEL);
    const bool isMove = (act == AMOTION_EVENT_ACTION_MOVE);
    if (isDown && g_Follow == -1) {
        g_Follow = e.pointerId; g_Owned = insideRect(e.x, e.y);
        InEv p; p.type = InEv::Pos; p.x = e.x; p.y = e.y; pushEv(p);
        InEv b; b.type = InEv::Btn; b.down = true; pushEv(b);
        return g_Owned;
    }
    if (e.pointerId != g_Follow) return false;
    if (isMove) { InEv p; p.type = InEv::Pos; p.x = e.x; p.y = e.y; pushEv(p); return g_Owned; }
    if (isUp) {
        InEv p; p.type = InEv::Pos; p.x = e.x; p.y = e.y; pushEv(p);
        InEv b; b.type = InEv::Btn; b.down = false; pushEv(b);
        const bool owned = g_Owned; g_Follow = -1; g_Owned = false;
        return owned;
    }
    return false;
}
bool isSystemKey(int k) {
    return k == AKEYCODE_BACK || k == AKEYCODE_HOME || k == AKEYCODE_POWER || k == AKEYCODE_APP_SWITCH ||
           k == AKEYCODE_VOLUME_UP || k == AKEYCODE_VOLUME_DOWN || k == AKEYCODE_VOLUME_MUTE;
}
bool isEditKey(int k) {
    return k == AKEYCODE_DEL || k == AKEYCODE_FORWARD_DEL || k == AKEYCODE_ENTER || k == AKEYCODE_NUMPAD_ENTER ||
           k == AKEYCODE_DPAD_LEFT || k == AKEYCODE_DPAD_RIGHT || k == AKEYCODE_MOVE_HOME || k == AKEYCODE_MOVE_END;
}
bool onKey(const pl::input::KeyEvent& e) {   // sirf hardware/BT keyboard
    if (!g_Visible.load() || !g_Initialized.load() || !g_WantText.load()) return false;
    if (isSystemKey(e.keyCode)) return false;
    if (e.isKeyDown && e.unicodeChar >= 32 && e.unicodeChar != 127) { InEv c; c.type = InEv::Char; c.ch = e.unicodeChar; pushEv(c); }
    if (isEditKey(e.keyCode) && e.keyCode >= 0 && e.keyCode < 512) {
        InEv k; k.type = e.isKeyDown ? InEv::KeyDown : InEv::KeyUp; k.code = e.keyCode; pushEv(k);
    }
    return true;
}
void flushInput(ImGuiIO& io) {
    for (int c : g_ToRelease) if (c >= 0 && c < 512) io.KeysDown[c] = false;
    g_ToRelease.clear();
    std::vector<InEv> q;
    { std::lock_guard<std::mutex> l(g_QMutex); q.swap(g_Queue); }
    for (const InEv& e : q) {
        switch (e.type) {
            case InEv::Pos:     io.AddMousePosEvent(e.x, e.y); break;
            case InEv::Btn:     io.AddMouseButtonEvent(0, e.down); break;
            case InEv::Char:    io.AddInputCharacter(e.ch); break;
            case InEv::KeyDown: io.KeysDown[e.code] = true; break;
            case InEv::KeyUp:   g_ToRelease.push_back(e.code); break;
        }
    }
}

// ============================================================ STYLE
void applyFontAndStyle(float scale, bool rebuildTex) {
    ImGuiIO& io = ImGui::GetIO();
    if (rebuildTex) ImGui_ImplOpenGL3_DestroyFontsTexture();
    io.Fonts->Clear();
    ImFontConfig fc; fc.OversampleH = 2; fc.OversampleV = 2;
    ImFont* font = nullptr;
    for (const char* path : kFontCandidates) {
        if (access(path, R_OK) != 0) continue;
        font = io.Fonts->AddFontFromFileTTF(path, 20.0f * scale, &fc);
        if (font) break;
    }
    if (!font) { fc.SizePixels = 13.0f * scale * 1.6f; io.Fonts->AddFontDefault(&fc); }
    if (rebuildTex) ImGui_ImplOpenGL3_CreateFontsTexture();

    ImGuiStyle& st = ImGui::GetStyle();
    st = ImGuiStyle();
    st.ScaleAllSizes(scale);
    st.WindowRounding = 10; st.ChildRounding = 8; st.FrameRounding = 6; st.GrabRounding = 4; st.PopupRounding = 8;
    st.ScrollbarSize = 14.0f * scale; st.GrabMinSize = 18.0f * scale;
    st.TouchExtraPadding = ImVec2(4, 4);
    ImVec4* c = st.Colors;
    c[ImGuiCol_Text] = C_TEXT; c[ImGuiCol_TextDisabled] = C_DIM;
    c[ImGuiCol_WindowBg] = C_WIN; c[ImGuiCol_ChildBg] = C_CARD; c[ImGuiCol_PopupBg] = C_FRAME;
    c[ImGuiCol_Border] = C_BORDER;
    c[ImGuiCol_FrameBg] = C_FRAME; c[ImGuiCol_FrameBgHovered] = ImVec4(0.17f, 0.17f, 0.17f, 1); c[ImGuiCol_FrameBgActive] = ImVec4(0.20f, 0.20f, 0.20f, 1);
    c[ImGuiCol_Button] = ImVec4(0.227f, 0.227f, 0.227f, 1); c[ImGuiCol_ButtonHovered] = ImVec4(0.267f, 0.267f, 0.267f, 1);
    c[ImGuiCol_ButtonActive] = C_BLUE;
    c[ImGuiCol_Header] = C_SELROW; c[ImGuiCol_HeaderHovered] = ImVec4(0.2f, 0.33f, 0.58f, 0.7f); c[ImGuiCol_HeaderActive] = C_BLUE;
    c[ImGuiCol_CheckMark] = ImVec4(0.231f, 0.510f, 0.965f, 1);
    c[ImGuiCol_ScrollbarBg] = ImVec4(0.13f, 0.13f, 0.13f, 1); c[ImGuiCol_ScrollbarGrab] = ImVec4(0.29f, 0.29f, 0.29f, 1);
    c[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.35f, 0.35f, 0.35f, 1); c[ImGuiCol_ScrollbarGrabActive] = C_BLUE;
    c[ImGuiCol_Separator] = C_BORDER; c[ImGuiCol_PlotHistogram] = C_BLUE;
    c[ImGuiCol_TextSelectedBg] = ImVec4(0.18f, 0.43f, 0.87f, 0.40f);
}

void setup() {
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_IsTouchScreen;
    io.IniFilename = nullptr;
    io.MouseDragThreshold = 14.0f;
    ImGui_ImplAndroid_Init();
    ImGui_ImplOpenGL3_Init(nullptr);
    loadConfig();
    trimLog();
    logf("Mem Scanner v2 start");
    memSelfTest();
    const float s = std::min(std::max(g_TargetScale.load(), kMinScale), kMaxScale);
    applyFontAndStyle(s, false);
    g_AppliedScale = s;
    g_LastRebuild = nowSec();
    g_Initialized = true;
}

void syncMenuOff() {
#if defined(HAVE_SET_MODULE_ENABLED)
    pl::modmenu::setModuleEnabled(std::string(kModuleId), false);
#endif
}

// ============================================================ UI STATE
int  g_CondSel = C_EXACT, g_TypeSel = 0;
bool g_Hex = false, g_LibOnly = false, g_KbOpen = false;
char g_Val1[48] = "", g_Val2[48] = "";
uint64_t g_SeenGen = 0;
std::unordered_map<uint64_t, bool> g_SelFound;   // key = (addr<<3)|type
std::vector<Seg> g_LibSnap;

enum KbKind { KB_NONE, KB_VAL1, KB_VAL2, KB_ROW };
int g_KbKind = KB_NONE, g_KbRow = -1;

// keypad: target buffer (g_Active ke liye lock ke andar)
void kbApply(int op, const char* s) {   // op 0 append, 1 backspace, 2 clear
    char* buf = nullptr; size_t sz = 0;
    std::unique_lock<std::mutex> lk(g_ActMx, std::defer_lock);
    if (g_KbKind == KB_VAL1) { buf = g_Val1; sz = sizeof(g_Val1); }
    else if (g_KbKind == KB_VAL2) { buf = g_Val2; sz = sizeof(g_Val2); }
    else if (g_KbKind == KB_ROW) {
        lk.lock();
        if (g_KbRow >= 0 && g_KbRow < (int)g_Active.size()) { buf = g_Active[(size_t)g_KbRow].newBuf; sz = sizeof(g_Active[0].newBuf); }
    }
    if (!buf) return;
    size_t l = std::strlen(buf);
    if (op == 0) { const size_t n = std::strlen(s); if (l + n + 1 <= sz) std::memcpy(buf + l, s, n + 1); }
    else if (op == 1) { if (l) buf[l - 1] = 0; }
    else buf[0] = 0;
}
float kbHeight(float S) { return 2.0f * (34.0f * S + ImGui::GetStyle().ItemSpacing.y) + ImGui::GetFrameHeightWithSpacing() + 16.0f * S; }
void drawKeypad(float S) {
    const char* names[] = { "-", "Value", "Value 2", "New value" };
    ImGui::TextDisabled("Keypad -> %s", names[g_KbKind]);
    const float sp = ImGui::GetStyle().ItemSpacing.x;
    const float bw = std::max(24.0f * S, (ImGui::GetContentRegionAvail().x - sp * 9) / 10.0f);
    const ImVec2 bsz(bw, 34.0f * S);
    static const char* r1 = "1234567890";
    for (int i = 0; r1[i]; ++i) {
        if (i) ImGui::SameLine();
        const char lab[2] = { r1[i], 0 };
        ImGui::PushID(i);
        if (ImGui::Button(lab, bsz)) kbApply(0, lab);
        ImGui::PopID();
    }
    static const char* r2[] = { ".", "-", "A", "B", "C", "D", "E", "F" };
    for (int i = 0; i < 8; ++i) {
        if (i) ImGui::SameLine();
        ImGui::PushID(100 + i);
        if (ImGui::Button(r2[i], bsz)) kbApply(0, r2[i]);
        ImGui::PopID();
    }
    ImGui::SameLine();
    if (ImGui::Button("DEL", bsz)) kbApply(1, "");
    ImGui::SameLine();
    if (ImGui::Button("CLR", bsz)) kbApply(2, "");
}

// ------------------------------------------------------------ helpers (UI)
void touchScroll(bool itemDragging) {
    ImGuiIO& io = ImGui::GetIO();
    if (!ImGui::IsMouseDragging(0)) return;
    const ImVec2 cp = io.MouseClickedPos[0], wp = ImGui::GetWindowPos(), ws = ImGui::GetWindowSize();
    if (cp.x < wp.x || cp.y < wp.y || cp.x > wp.x + ws.x || cp.y > wp.y + ws.y) return;
    if (itemDragging || (!ImGui::IsAnyItemActive() && ImGui::IsWindowHovered())) {
        ImGui::SetScrollY(ImGui::GetScrollY() - io.MouseDelta.y);
        ImGui::SetScrollX(ImGui::GetScrollX() - io.MouseDelta.x);
    }
}

void fmtAddr(uint64_t a, char* out, size_t n) { std::snprintf(out, n, "0x%llX", (unsigned long long)a); }   // hamesha plain 0x

// live value cache: har row ke liye har 0.2s me ek hi read (heat/syscalls kam)
struct Live { double t = -1; uint64_t raw = 0; bool ok = false; };
std::unordered_map<uint64_t, Live> g_Live;
const Live& liveOf(uint64_t addr, int vt) {
    if (g_Live.size() > 6000) g_Live.clear();
    Live& l = g_Live[(addr << 3) | (uint64_t)vt];
    const double t = nowSec();
    if (t - l.t > 0.2) { l.ok = readMem(addr, &l.raw, (size_t)kVSize[vt]); l.t = t; }
    return l;
}
void liveInvalidate(uint64_t addr, int vt) { auto it = g_Live.find((addr << 3) | (uint64_t)vt); if (it != g_Live.end()) it->second.t = -1; }

bool smallButton(const char* label, const ImVec4& bg, const ImVec4& bgH, const ImVec4& tx, ImVec2 size = ImVec2(0, 0)) {
    ImGui::PushStyleColor(ImGuiCol_Button, bg);
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, bgH);
    ImGui::PushStyleColor(ImGuiCol_Text, tx);
    const bool r = ImGui::Button(label, size);
    ImGui::PopStyleColor(3);
    return r;
}

// ------------------------------------------------------------ UI: top bar
void drawTopBar(float S) {
    ImGui::AlignTextToFramePadding();
    ImGui::TextColored(ImVec4(0.231f, 0.510f, 0.965f, 1), "Mem Scanner");
    ImGui::SameLine(0, 18.0f * S);
    if (g_Scanning.load()) {
        const float f = (float)((double)g_PDone.load() / (double)std::max<uint64_t>(g_PTotal.load(), 1));
        ImGui::TextColored(C_AMBER, "SCANNING %d%%", (int)(std::min(f, 1.0f) * 100));
    } else ImGui::TextDisabled("idle");
    ImGui::SameLine(0, 18.0f * S);
    ImGui::TextDisabled("%s", g_MemStatus.c_str());
    const float fh = ImGui::GetFrameHeight();
    ImGui::SameLine(ImGui::GetWindowWidth() - fh * 1.6f - ImGui::GetStyle().WindowPadding.x);
    if (smallButton("X", C_RED, ImVec4(0.36f, 0.16f, 0.16f, 1), C_RED_TX, ImVec2(fh * 1.6f, fh))) {
        g_Visible = false; g_WantText = false; g_RectW = 0; g_RectH = 0;
        saveConfig(); syncMenuOff();
    }
}

// ------------------------------------------------------------ UI: scan card
void typePreview(const StorePtr& st, bool hasRes, char* out, size_t n) {
    unsigned mask = 0;
    if (hasRes) mask = st->typeMask;
    else {
        Query q; std::string e;
        if (buildQuery(g_Val1, g_Val2, g_Hex, g_TypeSel, g_CondSel, false, q, e))
            for (int t = 0; t < VT_COUNT; ++t) if (q.typeOn[t]) mask |= 1u << t;
    }
    std::string s;
    for (int t = 0; t < VT_COUNT; ++t) if (mask & (1u << t)) { if (!s.empty()) s += ' '; s += kVShort[t]; }
    if (hasRes) std::snprintf(out, n, "locked: %s", s.c_str());
    else if (g_TypeSel == 0 && !s.empty()) std::snprintf(out, n, "Auto [%s]", s.c_str());
    else std::snprintf(out, n, "%s", kTypeNames[g_TypeSel]);
}

void drawScanCard(const StorePtr& st, float S) {
    const bool scanning = g_Scanning.load();
    const bool hasRes = st && st->n > 0;
    const float fh = ImGui::GetFrameHeight();
    const ImGuiStyle& sty = ImGui::GetStyle();
    const float cardH = fh * 2.0f + sty.ItemSpacing.y * 2 + sty.WindowPadding.y * 2 + 6.0f * S;
    ImGui::BeginChild("##card", ImVec2(0, cardH), true, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    if (scanning) ImGui::BeginDisabled(true);

    // row 1: scan type | value (and value2) | hex | value type
    ImGui::SetNextItemWidth(230.0f * S);
    if (ImGui::BeginCombo("##cond", kCondNames[g_CondSel])) {
        for (int i = 0; i < C_COUNT; ++i) {
            const bool dis = !hasRes && !condFirstOk(i);
            if (dis) ImGui::BeginDisabled(true);
            if (ImGui::Selectable(kCondNames[i], g_CondSel == i)) g_CondSel = i;
            if (dis) ImGui::EndDisabled();
        }
        ImGui::EndCombo();
    }
    if (!hasRes && !condFirstOk(g_CondSel)) g_CondSel = C_EXACT;
    ImGui::SameLine();
    const bool needVal = condNeedsValue(g_CondSel);
    if (!needVal) ImGui::BeginDisabled(true);
    ImGui::SetNextItemWidth(150.0f * S);
    ImGui::InputTextWithHint("##v1", needVal ? "value" : "-", g_Val1, sizeof(g_Val1),
                             g_Hex ? ImGuiInputTextFlags_CharsHexadecimal : ImGuiInputTextFlags_CharsDecimal);
    if (ImGui::IsItemActive()) { g_KbKind = KB_VAL1; g_KbRow = -1; }
    if (g_CondSel == C_BETWEEN) {
        ImGui::SameLine();
        ImGui::SetNextItemWidth(150.0f * S);
        ImGui::InputTextWithHint("##v2", "and", g_Val2, sizeof(g_Val2),
                                 g_Hex ? ImGuiInputTextFlags_CharsHexadecimal : ImGuiInputTextFlags_CharsDecimal);
        if (ImGui::IsItemActive()) { g_KbKind = KB_VAL2; g_KbRow = -1; }
    }
    if (!needVal) ImGui::EndDisabled();
    ImGui::SameLine();
    ImGui::Checkbox("Hex", &g_Hex);
    if (g_Hex) {
        const Parsed hp = parseNum(g_Val1, true);
        ImGui::SameLine();
        if (hp.ok) ImGui::TextDisabled("=%lld", (long long)hp.i); else ImGui::TextDisabled("=?");
    }
    ImGui::SameLine();
    char tprev[96]; typePreview(st, hasRes, tprev, sizeof(tprev));
    if (hasRes) ImGui::BeginDisabled(true);   // CE jaisa: type results ke baad lock; badalna ho to "New Scan"
    ImGui::SetNextItemWidth(230.0f * S);
    if (ImGui::BeginCombo("##vtype", tprev)) {
        for (int i = 0; i < 7; ++i) if (ImGui::Selectable(kTypeNames[i], g_TypeSel == i)) g_TypeSel = i;
        ImGui::EndCombo();
    }
    if (hasRes) ImGui::EndDisabled();
    if (scanning) ImGui::EndDisabled();

    // row 2: buttons + progress
    if (scanning) ImGui::BeginDisabled(true);
    bool doFirst = false, doNew = false;
    if (!hasRes) doFirst = smallButton("First Scan", C_BLUE, C_BLUE_H, ImVec4(1, 1, 1, 1), ImVec2(130.0f * S, 0));
    else doNew = ImGui::Button("New Scan", ImVec2(130.0f * S, 0));
    ImGui::SameLine();
    if (!hasRes) ImGui::BeginDisabled(true);
    const bool doNext = smallButton("Next Scan", C_BLUE, C_BLUE_H, ImVec4(1, 1, 1, 1), ImVec2(120.0f * S, 0));
    if (!hasRes) ImGui::EndDisabled();
    ImGui::SameLine();
    bool undoAvail; { std::lock_guard<std::mutex> l(g_Mx); undoAvail = !g_Undo.empty(); }
    if (!undoAvail) ImGui::BeginDisabled(true);
    const bool doUndoBtn = ImGui::Button("Undo", ImVec2(90.0f * S, 0));
    if (!undoAvail) ImGui::EndDisabled();
    ImGui::SameLine();
    ImGui::Checkbox("Only game lib", &g_LibOnly);
    if (scanning) ImGui::EndDisabled();
    ImGui::SameLine();
    if (scanning) {
        if (smallButton("Cancel", C_RED, ImVec4(0.36f, 0.16f, 0.16f, 1), C_RED_TX, ImVec2(100.0f * S, 0))) g_Cancel = true;
        ImGui::SameLine();
        const float f = (float)((double)g_PDone.load() / (double)std::max<uint64_t>(g_PTotal.load(), 1));
        ImGui::ProgressBar(std::min(f, 1.0f), ImVec2(-FLT_MIN, 0));
    } else {
        ImGui::TextDisabled("Scan #%d", st ? st->scanNo : 0);
    }
    ImGui::EndChild();

    // actions
    if (doNew) { resetScan(); setStatus("New Scan: type/value chuno, phir First Scan dabao"); }
    if (doFirst || doNext) {
        if (doFirst && !condFirstOk(g_CondSel)) setStatus("First scan me ye type nahi chalta (Exact/Bigger/Smaller/Between)");
        else {
            Query q; std::string err;
            if (!buildQuery(g_Val1, g_Val2, g_Hex, g_TypeSel, g_CondSel, doNext, q, err, doNext && st->floatLoose)) setStatus(err);
            else if (doNext && condNeedsPrev(g_CondSel) && !st->hasPrev)
                setStatus("Results bahut zyada (>4M): Changed/Increased ke liye pehle Exact se narrow karo");
            else {
                g_Scanning = true; g_Cancel = false;
                if (doFirst) {
                    const Parsed vp = parseNum(g_Val1, g_Hex);
                    const bool loose = g_TypeSel >= 5 && vp.ok && !vp.frac;   // explicit Float + integer text = CE rounded
                    setStatus("Scanning...");
                    std::thread(runFirstScan, q, g_LibOnly, loose).detach();
                } else { setStatus("Next scan..."); std::thread(runNextScan, st, q).detach(); }
            }
        }
    }
    if (doUndoBtn) { if (doUndo()) setStatus("Undo: pichli list wapas"); }
}

// ------------------------------------------------------------ UI: FOUND (left)
void drawFound(const StorePtr& st, float width, float height, float S) {
    ImGui::BeginChild("##found", ImVec2(width, height), true, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    const size_t total = st ? st->n : 0, shown = st ? st->nshown : 0;
    bool allSel = shown > 0;
    for (size_t i = 0; i < shown && allSel; ++i) if (!g_SelFound.count((st->shown[i].addr << 3) | st->shown[i].type)) allSel = false;
    if (ImGui::Checkbox("##fall", &allSel)) {
        g_SelFound.clear();
        if (allSel) for (size_t i = 0; i < shown; ++i) g_SelFound[(st->shown[i].addr << 3) | st->shown[i].type] = true;
    }
    ImGui::SameLine();
    ImGui::Text("FOUND: %zu", total);
    if (total > shown) { ImGui::SameLine(); ImGui::TextDisabled("(first %zu shown - Next Scan se narrow karo)", shown); }
    ImGui::SameLine();
    ImGui::TextDisabled("| %zu selected", g_SelFound.size());

    const float cw = ImGui::GetContentRegionAvail().x;
    ImGui::TextDisabled("ADDRESS");
    ImGui::SameLine(cw * 0.46f); ImGui::TextDisabled("VALUE");
    ImGui::SameLine(cw * 0.84f); ImGui::TextDisabled("TYPE");

    const float footH = ImGui::GetFrameHeightWithSpacing() + 4.0f * S;
    ImGui::BeginChild("##flist", ImVec2(0, -footH), false);
    ImGuiIO& io = ImGui::GetIO();
    const float rowH = ImGui::GetTextLineHeight() + 12.0f * S;
    bool dragItem = false;
    ImGuiListClipper clipper;
    clipper.Begin((int)shown, rowH + ImGui::GetStyle().ItemSpacing.y);
    while (clipper.Step()) {
        for (int i = clipper.DisplayStart; i < clipper.DisplayEnd; ++i) {
            const Result& r = st->shown[i];
            const uint64_t key = (r.addr << 3) | r.type;
            const bool sel = g_SelFound.count(key) > 0;
            ImGui::PushID(i);
            const ImVec2 p = ImGui::GetCursorScreenPos();
            const float w = std::max(ImGui::GetContentRegionAvail().x, 10.0f);
            const bool clicked = ImGui::InvisibleButton("##r", ImVec2(w, rowH));
            ImDrawList* dl = ImGui::GetWindowDrawList();
            if (sel) dl->AddRectFilled(p, ImVec2(p.x + w, p.y + rowH), ImGui::GetColorU32(C_SELROW), 4.0f);
            else if (ImGui::IsItemActive()) dl->AddRectFilled(p, ImVec2(p.x + w, p.y + rowH), ImGui::GetColorU32(ImVec4(1, 1, 1, 0.06f)), 4.0f);
            if (ImGui::IsItemActive() && ImGui::IsMouseDragging(0)) dragItem = true;
            char a[40], v[48] = "?";
            fmtAddr(r.addr, a, sizeof(a));
            const Live& lv = liveOf(r.addr, r.type);
            if (lv.ok) fmtRaw(lv.raw, r.type, v, sizeof(v));
            const float ty = p.y + (rowH - ImGui::GetTextLineHeight()) * 0.5f;
            const ImU32 col = ImGui::GetColorU32(C_TEXT);
            dl->AddText(ImVec2(p.x + 6, ty), col, a);
            dl->AddText(ImVec2(p.x + w * 0.46f, ty), col, v);
            dl->AddText(ImVec2(p.x + w * 0.84f, ty), ImGui::GetColorU32(C_DIM), kVShort[r.type]);
            if (clicked && io.MouseDragMaxDistanceSqr[0] < io.MouseDragThreshold * io.MouseDragThreshold) {
                if (sel) g_SelFound.erase(key); else g_SelFound[key] = true;
            }
            ImGui::PopID();
        }
    }
    clipper.End();
    touchScroll(dragItem);
    ImGui::EndChild();

    char lab[48]; std::snprintf(lab, sizeof(lab), "Add Selected (%zu) >", g_SelFound.size());
    if (g_SelFound.empty()) ImGui::BeginDisabled(true);
    if (ImGui::Button(lab)) {
        size_t added = 0;
        std::lock_guard<std::mutex> l(g_ActMx);
        for (size_t i = 0; i < shown && g_Active.size() < kMaxActive; ++i) {
            const Result& r = st->shown[i];
            if (!g_SelFound.count((r.addr << 3) | r.type)) continue;
            bool dup = false;
            for (const Active& x : g_Active) if (x.addr == r.addr && x.type == r.type) { dup = true; break; }
            if (dup) continue;
            Active a; a.addr = r.addr; a.type = r.type;
            uint64_t raw = 0;
            if (readMem(r.addr, &raw, (size_t)kVSize[r.type])) fmtRaw(raw, r.type, a.newBuf, sizeof(a.newBuf));
            g_Active.push_back(a); ++added;
        }
        g_SelFound.clear();
        char b[96]; std::snprintf(b, sizeof(b), "%zu address Active list me gaye%s", added, g_Active.size() >= kMaxActive ? " (list full)" : "");
        setStatus(b);
    }
    if (g_SelFound.empty()) ImGui::EndDisabled();
    ImGui::SameLine();
    if (ImGui::Button("Select all")) { g_SelFound.clear(); for (size_t i = 0; i < shown; ++i) g_SelFound[(st->shown[i].addr << 3) | st->shown[i].type] = true; }
    ImGui::EndChild();
}

// ------------------------------------------------------------ UI: ACTIVE (right)
void drawActive(float width, float height, float S) {
    ImGui::BeginChild("##act", ImVec2(width, height), true, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    std::lock_guard<std::mutex> lk(g_ActMx);
    bool allSel = !g_Active.empty();
    for (const Active& a : g_Active) if (!a.sel) { allSel = false; break; }
    if (ImGui::Checkbox("##aall", &allSel)) for (Active& a : g_Active) a.sel = allSel;
    ImGui::SameLine();
    bool anySel = false; int nLocked = 0;
    for (const Active& a : g_Active) { anySel = anySel || a.sel; nLocked += a.locked ? 1 : 0; }
    if (!anySel) ImGui::BeginDisabled(true);
    if (smallButton("Lock Sel", ImVec4(0.18f, 0.435f, 0.87f, 0.25f), ImVec4(0.18f, 0.435f, 0.87f, 0.40f), ImVec4(0.5f, 0.69f, 1.0f, 1))) {
        for (Active& a : g_Active) if (a.sel) {
            uint64_t raw = 0;
            if (!(a.newBuf[0] && parseForType(a.newBuf, a.type, g_Hex, raw)) && !readMem(a.addr, &raw, (size_t)kVSize[a.type])) continue;
            a.lockRaw = raw; a.locked = true; a.fails = 0;
        }
        setStatus("Selected rows lock (100ms par likhta rahega)");
    }
    ImGui::SameLine();
    if (ImGui::Button("Unlock")) { for (Active& a : g_Active) if (a.sel) a.locked = false; }
    ImGui::SameLine();
    const bool rm = smallButton("RM Sel", C_RED, ImVec4(0.36f, 0.16f, 0.16f, 1), C_RED_TX);
    ImGui::SameLine();
    const bool en = smallButton("EN Sel", ImVec4(0.118f, 0.227f, 0.141f, 1), ImVec4(0.14f, 0.29f, 0.17f, 1), C_OKTXT);
    if (!anySel) ImGui::EndDisabled();
    ImGui::SameLine();
    ImGui::TextDisabled("%zu active | %d locked", g_Active.size(), nLocked);

    const float cw = ImGui::GetContentRegionAvail().x;
    const float addrX = ImGui::GetFrameHeight() + ImGui::GetStyle().ItemSpacing.x;
    ImGui::Dummy(ImVec2(addrX, 0)); ImGui::SameLine(0, 0);
    ImGui::TextDisabled("ADDRESS");
    ImGui::SameLine(cw * 0.29f); ImGui::TextDisabled("VALUE");
    ImGui::SameLine(cw * 0.50f); ImGui::TextDisabled("NEW VALUE");
    ImGui::SameLine(cw * 0.74f); ImGui::TextDisabled("EN");
    ImGui::SameLine(cw * 0.86f); ImGui::TextDisabled("LOCK");

    const float footH = ImGui::GetTextLineHeightWithSpacing() + 4.0f * S;
    ImGui::BeginChild("##alist", ImVec2(0, -footH), false);
    const float rowH = ImGui::GetFrameHeight();
    bool eraseSelected = rm;
    if (g_Active.empty()) ImGui::TextDisabled("No active addresses. FOUND se select karke \"Add Selected >\" dabao.");
    ImGuiListClipper clipper;
    clipper.Begin((int)g_Active.size(), rowH + ImGui::GetStyle().ItemSpacing.y);
    while (clipper.Step()) {
        for (int i = clipper.DisplayStart; i < clipper.DisplayEnd; ++i) {
            Active& a = g_Active[(size_t)i];
            ImGui::PushID(i);
            ImGui::Checkbox("##s", &a.sel);
            ImGui::SameLine();
            char ad[40], v[48] = "?";
            fmtAddr(a.addr, ad, sizeof(ad));
            const Live& lv = liveOf(a.addr, a.type);
            if (lv.ok) fmtRaw(lv.raw, a.type, v, sizeof(v));
            ImGui::AlignTextToFramePadding();
            ImGui::TextUnformatted(ad);
            ImGui::SameLine(cw * 0.29f);
            ImGui::TextColored(a.locked ? ImVec4(0.5f, 0.69f, 1.0f, 1) : C_TEXT, "%s", v);
            ImGui::SameLine(cw * 0.50f);
            ImGui::SetNextItemWidth(cw * 0.22f);
            ImGui::InputText("##nv", a.newBuf, sizeof(a.newBuf), g_Hex ? ImGuiInputTextFlags_CharsHexadecimal : ImGuiInputTextFlags_CharsDecimal);
            if (ImGui::IsItemActive()) { g_KbKind = KB_ROW; g_KbRow = i; }
            ImGui::SameLine(cw * 0.74f);
            if (smallButton("EN", C_GREEN, C_GREEN_H, ImVec4(1, 1, 1, 1), ImVec2(cw * 0.11f, 0))) {
                uint64_t w = 0;
                if (!parseForType(a.newBuf, a.type, g_Hex, w)) setStatus("New value is type me fit nahi hoti / galat hai");
                else if (!writeMem(a.addr, &w, (size_t)kVSize[a.type])) { setStatus("Write fail (address ab valid nahi / read-only)"); logf("write FAIL @%s %s=%s", ad, kVShort[a.type], a.newBuf); }
                else {
                    if (a.locked) a.lockRaw = w;
                    liveInvalidate(a.addr, a.type);
                    setStatus(std::string("Likha: ") + a.newBuf + " @ " + ad + "  (game me refresh ke liye inventory/screen touch karo)");
                    logf("write OK @%s %s=%s", ad, kVShort[a.type], a.newBuf);
                }
            }
            ImGui::SameLine(cw * 0.86f);
            if (smallButton(a.locked ? "LOCK" : "lock", a.locked ? C_BLUE : ImVec4(0.17f, 0.17f, 0.17f, 1), C_BLUE_H,
                            a.locked ? ImVec4(1, 1, 1, 1) : C_DIM, ImVec2(cw * 0.12f, 0))) {
                if (a.locked) a.locked = false;
                else {
                    uint64_t w = 0;
                    if ((a.newBuf[0] && parseForType(a.newBuf, a.type, g_Hex, w)) || readMem(a.addr, &w, (size_t)kVSize[a.type])) { a.lockRaw = w; a.locked = true; a.fails = 0; logf("lock ON @%s %s", ad, kVShort[a.type]); }
                    else setStatus("Lock fail: value padh/parse nahi hui");
                }
            }
            ImGui::PopID();
        }
    }
    clipper.End();
    touchScroll(false);
    ImGui::EndChild();
    ImGui::TextDisabled("Lock = 100ms par value wapas likhta hai (random address pe lock mat karo: game crash kar sakta hai)");

    if (en) {   // EN Selected: har selected row ki apni new value
        int ok = 0, bad = 0;
        for (Active& a : g_Active) if (a.sel) {
            uint64_t w = 0;
            if (parseForType(a.newBuf, a.type, g_Hex, w) && writeMem(a.addr, &w, (size_t)kVSize[a.type])) { ++ok; if (a.locked) a.lockRaw = w; liveInvalidate(a.addr, a.type); } else ++bad;
        }
        char b[96]; std::snprintf(b, sizeof(b), "EN Selected: %d likhe, %d fail", ok, bad);
        setStatus(b);
        logf("%s", b);
    }
    if (eraseSelected) {
        g_Active.erase(std::remove_if(g_Active.begin(), g_Active.end(), [](const Active& a) { return a.sel; }), g_Active.end());
        g_KbKind = KB_NONE; g_KbRow = -1;
    }
    ImGui::EndChild();
}

// ------------------------------------------------------------ UI: window
void drawMenu(const StorePtr& st) {
    if (!g_Visible.load()) return;
    ImGuiIO& io = ImGui::GetIO();
    const float S = g_AppliedScale;
    const ImVec2 ds = io.DisplaySize;
    const float W = std::min(kBaseW * S, ds.x * kScreenFrac);
    const float H = std::min(kBaseH * S, ds.y * kScreenFrac);
    const float px = std::min(std::max(g_PosXPct.load(), 0.0f), 100.0f) / 100.0f * std::max(0.0f, ds.x - W);
    const float py = std::min(std::max(g_PosYPct.load(), 0.0f), 100.0f) / 100.0f * std::max(0.0f, ds.y - H);
    ImGui::SetNextWindowPos(ImVec2(px, py), ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(W, H), ImGuiCond_Always);
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, std::min(std::max(g_Opacity.load(), 0.2f), 1.0f));
    ImGui::Begin("##memscan", nullptr,
                 ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize |
                 ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings |
                 ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    const ImVec2 wp = ImGui::GetWindowPos(), wsz = ImGui::GetWindowSize();
    g_RectX = wp.x; g_RectY = wp.y; g_RectW = wsz.x; g_RectH = wsz.y;

    drawTopBar(S);
    ImGui::Separator();
    drawScanCard(st, S);

    const float bottomH = ImGui::GetFrameHeightWithSpacing() + 6.0f * S;
    const float kbH = g_KbOpen ? kbHeight(S) : 0.0f;
    const float bodyH = std::max(80.0f * S, ImGui::GetContentRegionAvail().y - bottomH - kbH);
    const float availW = ImGui::GetContentRegionAvail().x;
    const float leftW = std::floor(availW * 0.40f);
    drawFound(st, leftW, bodyH, S);
    ImGui::SameLine();
    drawActive(0.0f, bodyH, S);

    if (g_KbOpen) {
        ImGui::BeginChild("##kp", ImVec2(0, kbH - ImGui::GetStyle().ItemSpacing.y), true, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
        drawKeypad(S);
        ImGui::EndChild();
    }

    // bottom bar
    if (ImGui::Button(g_KbOpen ? "KB: ON" : "KB: OFF")) g_KbOpen = !g_KbOpen;
    ImGui::SameLine();
    ImGui::TextDisabled("%s", getStatus().c_str());

    ImGui::End();
    ImGui::PopStyleVar();
    g_WantText = io.WantTextInput;
}

void render() {
    ImGuiIO& io = ImGui::GetIO();
    if (g_ResetInput.exchange(false)) {
        { std::lock_guard<std::mutex> l(g_QMutex); g_Queue.clear(); }
        g_ToRelease.clear();
        std::memset(io.KeysDown, 0, sizeof(io.KeysDown));
        io.AddMouseButtonEvent(0, false);
    }
    const float tgt = std::min(std::max(g_TargetScale.load(), kMinScale), kMaxScale);
    const double t = nowSec();
    if (std::fabs(tgt - g_AppliedScale) > 0.005f && t - g_LastRebuild > 0.25) {
        applyFontAndStyle(tgt, g_DeviceReady);
        g_AppliedScale = tgt; g_LastRebuild = t;
    }
    flushInput(io);

    StorePtr st; uint64_t gen = 0;
    {
        std::lock_guard<std::mutex> l(g_Mx);
        st = g_Store; gen = g_Gen;
        if (gen != g_SeenGen) { g_LibSnap = g_LibRanges; }
    }
    if (gen != g_SeenGen) { g_SeenGen = gen; g_SelFound.clear(); }

    ImGui_ImplOpenGL3_NewFrame();
    g_DeviceReady = true;
    ImGui_ImplAndroid_NewFrame(g_Width, g_Height);
    ImGui::NewFrame();
    drawMenu(st);
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    if (g_Visible.load() && t - g_LastSave > 2.0) { g_LastSave = t; saveConfig(); }
}

using SwapFn = EGLBoolean (*)(EGLDisplay, EGLSurface);
SwapFn g_OrigSwap = nullptr;
pl::memory::HookHandle g_SwapHook;

EGLBoolean hook_swap(EGLDisplay dpy, EGLSurface surf) {
    if (!g_OrigSwap) return EGL_FALSE;
    EGLContext ctx = eglGetCurrentContext();
    if (ctx == EGL_NO_CONTEXT) return g_OrigSwap(dpy, surf);
    EGLint w = 0, h = 0;
    eglQuerySurface(dpy, surf, EGL_WIDTH, &w);
    eglQuerySurface(dpy, surf, EGL_HEIGHT, &h);
    if (w < 500 || h < 500) return g_OrigSwap(dpy, surf);
    if (g_TargetContext == EGL_NO_CONTEXT) {
        EGLint buf = 0;
        eglQuerySurface(dpy, surf, EGL_RENDER_BUFFER, &buf);
        if (buf == EGL_BACK_BUFFER) { g_TargetContext = ctx; g_TargetSurface = surf; }
    }
    if (ctx != g_TargetContext || surf != g_TargetSurface) return g_OrigSwap(dpy, surf);
    g_Width = w; g_Height = h;
    if (g_Visible.load()) {
        if (!g_Initialized.load()) setup();
        render();
    }
    return g_OrigSwap(dpy, surf);
}

void* mainThread(void*) {
    sleep(3);
    void* egl = dlopen("libEGL.so", RTLD_NOW);
    if (egl) {
        void* swap = dlsym(egl, "eglSwapBuffers");
        if (swap) g_SwapHook = pl::memory::HookHandle(swap, (void*)&hook_swap, (void**)&g_OrigSwap);
        LOGI("EGL hook: %s", g_SwapHook.installed() ? "OK" : "FAIL");
    } else LOGW("libEGL.so open fail");
    std::thread(lockThread).detach();
    return nullptr;
}

// ------------------------------------------------------------ mod menu
void onToggle(std::string_view moduleId, bool enabled) {
    if (moduleId != kModuleId) return;
    if (enabled) { g_ResetInput = true; g_Visible = true; }
    else g_Visible = false;
}

template <class T>
std::string toStr(const T& v) {
    if constexpr (std::is_same_v<T, bool>) return v ? "1" : "0";
    else if constexpr (std::is_convertible_v<const T&, std::string_view>) return std::string(std::string_view(v));
    else if constexpr (std::is_arithmetic_v<T>) return std::to_string(v);
    else return std::string();
}
template <class... A>
void onConfig(const A&... a) {
    std::vector<std::string> v;
    (v.push_back(toStr(a)), ...);
    for (size_t i = 0; i + 1 < v.size(); ++i) {
        const float x = static_cast<float>(std::atof(v[i + 1].c_str()));
        if (v[i] == "scale")        { if (x >= kMinScale && x <= kMaxScale) g_TargetScale = x; return; }
        else if (v[i] == "opacity") { if (x >= 0.2f && x <= 1.0f) g_Opacity = x; return; }
        else if (v[i] == "posx")    { if (x >= 0 && x <= 100) g_PosXPct = x; return; }
        else if (v[i] == "posy")    { if (x >= 0 && x <= 100) g_PosYPct = x; return; }
    }
}
struct CfgFn {
    template <class... A>
    void operator()(const A&... a) const { onConfig(a...); }
};
template <class B>
constexpr bool kHasCfgCallback = requires(B b) { b.onConfigChanged(CfgFn{}); };
template <class B>
B attachCfg(B b) {
    if constexpr (kHasCfgCallback<B>) return b.onConfigChanged(CfgFn{});
    else return b;
}

bool registerMenu(ll::mod::NativeMod& self) {
    using CT = pl::modmenu::ConfigType;
    auto b = pl::modmenu::ModuleBuilder(std::string(kModuleId), "Mem Scanner")
                 .modId(self.getId())
                 .description("Cheat Engine jaisa memory scanner. Sliders: Scale / Opacity / Position. X = hide.")
                 .defaultEnabled(false)
                 .onToggle(onToggle)
                 .config("scale",   "Panel Size",   CT::SliderFloat, "1.1",  "0.7", "2.0")
                 .config("opacity", "Opacity",      CT::SliderFloat, "0.97", "0.2", "1.0")
                 .config("posx",    "Position X %", CT::SliderFloat, "3",    "0",   "100")
                 .config("posy",    "Position Y %", CT::SliderFloat, "4",    "0",   "100");
    g_HasCfgCallback = kHasCfgCallback<pl::modmenu::ModuleBuilder>;
    b = attachCfg(b);
    return b.registerModule();
}

std::once_flag g_CbOnce, g_HookOnce;

}  // namespace

class MemScanMod {
public:
    static MemScanMod& instance() { static MemScanMod m; return m; }
    MemScanMod() : mSelf(*ll::mod::NativeMod::current()) {}
    ll::mod::NativeMod& getSelf() const { return mSelf; }

    bool load() { getSelf().getLogger().info("Mem Scanner loaded"); return true; }

    bool enable() {
        std::call_once(g_CbOnce, [] {
            pl::input::registerTouchCallback(onTouch);
            pl::input::registerKeyCallback(onKey);
        });
        std::call_once(g_HookOnce, [] {
            pthread_t t;
            pthread_create(&t, nullptr, mainThread, nullptr);
        });
        const bool ok = registerMenu(getSelf());
        LOGI("Menu register: %s (cfg callback: %s)", ok ? "OK" : "FAIL", g_HasCfgCallback ? "yes" : "no");
        if (!ok) g_Visible = true;
        return true;
    }

    bool disable() {
        g_Visible = false;
        g_WantText = false;
        pl::modmenu::unregisterModule(kModuleId);
        return true;
    }

    bool unload() { return true; }

private:
    ll::mod::NativeMod& mSelf;
};

PL_REGISTER_MOD(MemScanMod, MemScanMod::instance())
