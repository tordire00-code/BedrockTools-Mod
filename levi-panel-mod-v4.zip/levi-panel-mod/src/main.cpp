// Levi Panel Mod v4
//  Theme (eye-comfort) + Roboto font + persistence + scale/opacity + on-screen keyboard
//  + Zaphkiel file-bridge sections (Terminal / Output / Process / Config)
//  Base = v3: official pl::input callbacks, ModMenu toggle (+ "Panel Size"), EGL swap hook.
#include <jni.h>
#include <android/input.h>
#include <android/keycodes.h>
#include <android/log.h>
#include <EGL/egl.h>
#include <pthread.h>
#include <unistd.h>
#include <dlfcn.h>
#include <sys/stat.h>

#include <algorithm>
#include <atomic>
#include <cfloat>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <string>
#include <string_view>
#include <thread>
#include <type_traits>
#include <vector>

#include <pl/Mod.hpp>
#include <pl/ModMenu.hpp>
#include <pl/Input.hpp>
#include <pl/Logger.hpp>
#include <pl/memory/Hook.hpp>

#include "ImGui/imgui.h"
#include "ImGui/backends/imgui_impl_android.h"
#include "ImGui/backends/imgui_impl_opengl3.h"

#define TAG "PanelMod"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)

namespace {

constexpr std::string_view kModuleId = "panelmod.main";

// ------------------------------------------------------------ paths (yahan edit karo)
const char* kKurumiDir = "/storage/emulated/0/Android/media/org.levimc.launcher/kurumi/";
const char* kCfgDir    = "/storage/emulated/0/Android/media/org.levimc.launcher/panelmod/";
const char* kFontCandidates[] = {
    "/system/fonts/Roboto-Regular.ttf",
    "/system/fonts/RobotoStatic-Regular.ttf",
    "/system/fonts/NotoSans-Regular.ttf",
    "/system/fonts/DroidSans.ttf",
};

constexpr float kMinScale = 0.8f;
constexpr float kMaxScale = 2.5f;
constexpr float kDefBaseW = 560.0f;   // base units (pixels = units * scale)
constexpr float kDefBaseH = 400.0f;
constexpr float kMinBaseW = 360.0f;
constexpr float kMinBaseH = 240.0f;

// ------------------------------------------------------------ theme: 3 eye-comfort colors
const ImVec4 C_BG    (0.133f, 0.125f, 0.114f, 1.0f);   // #22201D warm dark
const ImVec4 C_BG2   (0.165f, 0.157f, 0.145f, 1.0f);
const ImVec4 C_TEXT  (0.918f, 0.902f, 0.867f, 1.0f);   // #EAE6DD cream
const ImVec4 C_ACC   (0.561f, 0.737f, 0.561f, 1.0f);   // #8FBC8F sage
const ImVec4 C_ACC_H (0.639f, 0.796f, 0.639f, 1.0f);
const ImVec4 C_ACC_A (0.435f, 0.627f, 0.435f, 1.0f);
const ImVec4 C_BORDER(0.227f, 0.216f, 0.200f, 1.0f);
const ImVec4 C_TITLE (0.106f, 0.102f, 0.094f, 1.0f);
const ImVec4 C_BTN_TXT(0.10f, 0.12f, 0.10f, 1.0f);     // sage button pe dark text (readable)

// ------------------------------------------------------------ state
std::atomic_bool g_Visible{false};       // == launcher toggle (X dabane par bhi false)
std::atomic_bool g_Initialized{false};
std::atomic_bool g_ResetInput{false};
std::atomic_bool g_WantText{false};
std::atomic_bool g_RefreshNow{false};
std::atomic<float> g_TargetScale{1.0f};  // menu slider / in-panel slider (release par)

std::atomic<float> g_RectX{0}, g_RectY{0}, g_RectW{0}, g_RectH{0};

// render-thread only
float g_PosX = 0, g_PosY = 0;
float g_BaseW = kDefBaseW, g_BaseH = kDefBaseH;
bool  g_HavePos = false;
bool  g_ApplyGeom = true;
bool  g_ScaleChanged = false;
float g_AppliedScale = -1.0f;
float g_PendingScale = 1.0f;
double g_LastRebuild = 0.0;
double g_LastSave = 0.0;
bool  g_DeviceReady = false;
float g_Opacity = 1.0f;
bool  g_EffectOn = false;
bool  g_UseNativeKb = true;
bool  g_KbOpen = false;
bool  g_KbShift = false;
bool  g_KbShown = false;
bool  g_AutoScroll = true;
int   g_Section = 0;
char  g_TextBuf[256] = "";
char  g_ZInput[8192] = "";
char  g_Status[200] = "Ready";

// on-screen keyboard target (last active text field)
char*       g_KbTarget = nullptr;
size_t      g_KbSize = 0;
const char* g_KbName = "-";

int g_Width = 0, g_Height = 0;
EGLContext g_TargetContext = EGL_NO_CONTEXT;
EGLSurface g_TargetSurface = EGL_NO_SURFACE;

// bridge snapshots (bg thread writes, render thread reads)
std::mutex  g_SnapMx;
std::string g_SnapOut, g_SnapLog, g_SnapCfg;

using SwapFn = EGLBoolean (*)(EGLDisplay, EGLSurface);
SwapFn g_OrigSwap = nullptr;
pl::memory::HookHandle g_SwapHook;

double nowSec() {
    using namespace std::chrono;
    return duration_cast<duration<double>>(steady_clock::now().time_since_epoch()).count();
}

void setStatus(const char* s) { std::snprintf(g_Status, sizeof(g_Status), "%s", s); }

// ------------------------------------------------------------ file helpers
bool readFile(const char* path, std::string& out) {
    FILE* f = std::fopen(path, "rb");
    if (!f) return false;
    char buf[4096]; size_t n;
    out.clear();
    while ((n = std::fread(buf, 1, sizeof(buf), f)) > 0) out.append(buf, n);
    std::fclose(f);
    return true;
}
// sirf aakhri maxBytes (bade output me UI halka rahe)
bool readTail(const char* path, std::string& out, size_t maxBytes) {
    FILE* f = std::fopen(path, "rb");
    if (!f) return false;
    std::fseek(f, 0, SEEK_END);
    long sz = std::ftell(f);
    long start = sz > (long)maxBytes ? sz - (long)maxBytes : 0;
    std::fseek(f, start, SEEK_SET);
    out.resize((size_t)(sz - start));
    size_t n = out.empty() ? 0 : std::fread(&out[0], 1, out.size(), f);
    out.resize(n);
    std::fclose(f);
    if (start > 0) out.insert(0, "...(purana hissa hata diya)...\n");
    return true;
}
bool writeFile(const char* path, const char* data, size_t len) {
    FILE* f = std::fopen(path, "wb");
    if (!f) return false;
    std::fwrite(data, 1, len, f);
    std::fclose(f);
    return true;
}

// ------------------------------------------------------------ persistence
void saveConfig() {
    mkdir(kCfgDir, 0777);
    std::string p = std::string(kCfgDir) + "panel.cfg";
    char b[640];
    std::snprintf(b, sizeof(b),
        "posx=%f\nposy=%f\nbasew=%f\nbaseh=%f\nscale=%f\nopacity=%f\neffect=%d\nsection=%d\nnativekb=%d\n",
        g_PosX, g_PosY, g_BaseW, g_BaseH, g_TargetScale.load(), g_Opacity,
        g_EffectOn ? 1 : 0, g_Section, g_UseNativeKb ? 1 : 0);
    writeFile(p.c_str(), b, std::strlen(b));
}

void loadConfig() {
    std::string s;
    if (!readFile((std::string(kCfgDir) + "panel.cfg").c_str(), s)) return;
    size_t i = 0;
    while (i < s.size()) {
        size_t e = s.find('\n', i);
        if (e == std::string::npos) e = s.size();
        std::string line = s.substr(i, e - i);
        i = e + 1;
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string k = line.substr(0, eq);
        float v = (float)std::atof(line.c_str() + eq + 1);
        if (k == "posx") { g_PosX = v; g_HavePos = true; }
        else if (k == "posy") g_PosY = v;
        else if (k == "basew" && v >= kMinBaseW && v < 4000) g_BaseW = v;
        else if (k == "baseh" && v >= kMinBaseH && v < 4000) g_BaseH = v;
        else if (k == "scale" && v >= kMinScale && v <= kMaxScale) g_TargetScale = v;
        else if (k == "opacity" && v >= 0.2f && v <= 1.0f) g_Opacity = v;
        else if (k == "effect") g_EffectOn = v != 0;
        else if (k == "section" && v >= 0 && v <= 5) g_Section = (int)v;
        else if (k == "nativekb") g_UseNativeKb = v != 0;
    }
}

// ------------------------------------------------------------ input queue (input thread -> render thread)
struct InEv {
    enum Type { Pos, Btn, Char, KeyDown, KeyUp } type;
    float x = 0, y = 0;
    bool down = false;
    unsigned int ch = 0;
    int code = 0;
};
std::mutex g_QMutex;
std::vector<InEv> g_Queue;
std::vector<int> g_ToRelease;   // render thread only

void pushEv(const InEv& e) {
    std::lock_guard<std::mutex> l(g_QMutex);
    if (g_Queue.size() < 512) g_Queue.push_back(e);
}

bool insideRect(float x, float y) {
    const float m = 6.0f;
    const float rw = g_RectW.load(), rh = g_RectH.load();
    if (rw <= 0 || rh <= 0) return false;
    const float rx = g_RectX.load(), ry = g_RectY.load();
    return x >= rx - m && x <= rx + rw + m && y >= ry - m && y <= ry + rh + m;
}

int  g_Follow = -1;     // input thread only
bool g_Owned = false;

bool onTouch(const pl::input::TouchEvent& e) {
    static std::atomic_bool logged{false};
    if (!logged.exchange(true)) LOGI("touch callback: alive");
    if (!g_Visible.load() || !g_Initialized.load()) {
        g_Follow = -1; g_Owned = false;
        return false;
    }
    const int act = e.action & 0xFF;
    const bool isDown = (act == AMOTION_EVENT_ACTION_DOWN || act == AMOTION_EVENT_ACTION_POINTER_DOWN);
    const bool isUp   = (act == AMOTION_EVENT_ACTION_UP || act == AMOTION_EVENT_ACTION_POINTER_UP ||
                         act == AMOTION_EVENT_ACTION_CANCEL);
    const bool isMove = (act == AMOTION_EVENT_ACTION_MOVE);

    if (isDown && g_Follow == -1) {
        g_Follow = e.pointerId;
        g_Owned = insideRect(e.x, e.y);
        InEv p; p.type = InEv::Pos; p.x = e.x; p.y = e.y; pushEv(p);
        InEv b; b.type = InEv::Btn; b.down = true; pushEv(b);
        return g_Owned;
    }
    if (e.pointerId != g_Follow) return false;
    if (isMove) {
        InEv p; p.type = InEv::Pos; p.x = e.x; p.y = e.y; pushEv(p);
        return g_Owned;
    }
    if (isUp) {
        InEv p; p.type = InEv::Pos; p.x = e.x; p.y = e.y; pushEv(p);
        InEv b; b.type = InEv::Btn; b.down = false; pushEv(b);
        const bool owned = g_Owned;
        g_Follow = -1; g_Owned = false;
        return owned;
    }
    return false;
}

bool isSystemKey(int k) {
    return k == AKEYCODE_BACK || k == AKEYCODE_HOME || k == AKEYCODE_POWER ||
           k == AKEYCODE_APP_SWITCH || k == AKEYCODE_VOLUME_UP ||
           k == AKEYCODE_VOLUME_DOWN || k == AKEYCODE_VOLUME_MUTE;
}
bool isEditKey(int k) {
    return k == AKEYCODE_DEL || k == AKEYCODE_FORWARD_DEL || k == AKEYCODE_ENTER ||
           k == AKEYCODE_NUMPAD_ENTER || k == AKEYCODE_DPAD_LEFT || k == AKEYCODE_DPAD_RIGHT ||
           k == AKEYCODE_DPAD_UP || k == AKEYCODE_DPAD_DOWN || k == AKEYCODE_MOVE_HOME ||
           k == AKEYCODE_MOVE_END || k == AKEYCODE_TAB;
}

bool onKey(const pl::input::KeyEvent& e) {
    static std::atomic_bool logged{false};
    if (!logged.exchange(true)) LOGI("key callback: alive");
    if (!g_Visible.load() || !g_Initialized.load()) return false;
    if (!g_WantText.load()) return false;
    if (isSystemKey(e.keyCode)) return false;

    if (e.isKeyDown && e.unicodeChar >= 32 && e.unicodeChar != 127) {
        InEv c; c.type = InEv::Char; c.ch = e.unicodeChar; pushEv(c);
    }
    if (isEditKey(e.keyCode) && e.keyCode >= 0 && e.keyCode < 512) {
        InEv k; k.type = e.isKeyDown ? InEv::KeyDown : InEv::KeyUp; k.code = e.keyCode; pushEv(k);
    }
    return true;
}

void flushInput(ImGuiIO& io) {
    for (int c : g_ToRelease) if (c >= 0 && c < 512) io.KeysDown[c] = false;
    g_ToRelease.clear();
    std::vector<InEv> q;
    { std::lock_guard<std::mutex> l(g_QMutex); q.swap(g_Queue); }
    for (const InEv& e : q) {
        switch (e.type) {
            case InEv::Pos:     io.AddMousePosEvent(e.x, e.y); break;
            case InEv::Btn:     io.AddMouseButtonEvent(0, e.down); break;
            case InEv::Char:    io.AddInputCharacter(e.ch); break;
            case InEv::KeyDown: io.KeysDown[e.code] = true; break;
            case InEv::KeyUp:   g_ToRelease.push_back(e.code); break;
        }
    }
}

// ------------------------------------------------------------ font + style
// NewFrame() se pehle hi call karo. rebuildTex=false => pehli baar (texture NewFrame banayega)
void applyFontAndStyle(float scale, bool rebuildTex) {
    ImGuiIO& io = ImGui::GetIO();
    if (rebuildTex) ImGui_ImplOpenGL3_DestroyFontsTexture();
    io.Fonts->Clear();

    ImFontConfig fc;
    fc.OversampleH = 2; fc.OversampleV = 2;
    ImFont* font = nullptr;
    for (const char* path : kFontCandidates) {
        if (access(path, R_OK) != 0) continue;
        font = io.Fonts->AddFontFromFileTTF(path, 22.0f * scale, &fc);
        if (font) break;
    }
    if (!font) {                                   // fallback: default font, bada karke
        fc.SizePixels = 13.0f * scale * 1.7f;
        io.Fonts->AddFontDefault(&fc);
    }
    if (rebuildTex) ImGui_ImplOpenGL3_CreateFontsTexture();

    ImGuiStyle& st = ImGui::GetStyle();
    st = ImGuiStyle();
    st.ScaleAllSizes(scale);
    st.WindowRounding = 8; st.ChildRounding = 6; st.FrameRounding = 5;
    st.GrabRounding = 4; st.PopupRounding = 6;
    st.ScrollbarSize = 18.0f * scale;
    st.GrabMinSize = 22.0f * scale;
    st.TouchExtraPadding = ImVec2(4, 4);
    ImVec4* c = st.Colors;
    c[ImGuiCol_Text] = C_TEXT;
    c[ImGuiCol_TextDisabled] = ImVec4(0.62f, 0.60f, 0.56f, 1);
    c[ImGuiCol_WindowBg] = C_BG;
    c[ImGuiCol_ChildBg] = C_BG2;
    c[ImGuiCol_PopupBg] = C_BG2;
    c[ImGuiCol_Border] = C_BORDER;
    c[ImGuiCol_FrameBg] = ImVec4(0.20f, 0.19f, 0.175f, 1);
    c[ImGuiCol_FrameBgHovered] = ImVec4(0.24f, 0.23f, 0.21f, 1);
    c[ImGuiCol_FrameBgActive] = ImVec4(0.28f, 0.27f, 0.25f, 1);
    c[ImGuiCol_TitleBg] = C_TITLE;
    c[ImGuiCol_TitleBgActive] = ImVec4(0.16f, 0.15f, 0.14f, 1);
    c[ImGuiCol_Button] = C_ACC;
    c[ImGuiCol_ButtonHovered] = C_ACC_H;
    c[ImGuiCol_ButtonActive] = C_ACC_A;
    c[ImGuiCol_Header] = ImVec4(0.30f, 0.40f, 0.30f, 1);
    c[ImGuiCol_HeaderHovered] = ImVec4(0.36f, 0.48f, 0.36f, 1);
    c[ImGuiCol_HeaderActive] = C_ACC_A;
    c[ImGuiCol_SliderGrab] = C_ACC;
    c[ImGuiCol_SliderGrabActive] = C_ACC_H;
    c[ImGuiCol_CheckMark] = C_ACC;
    c[ImGuiCol_ScrollbarBg] = ImVec4(0.12f, 0.115f, 0.105f, 1);
    c[ImGuiCol_ScrollbarGrab] = ImVec4(0.40f, 0.38f, 0.35f, 1);
    c[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.48f, 0.46f, 0.42f, 1);
    c[ImGuiCol_ScrollbarGrabActive] = C_ACC;
    c[ImGuiCol_Separator] = C_BORDER;
    c[ImGuiCol_TextSelectedBg] = ImVec4(0.56f, 0.74f, 0.56f, 0.35f);
}

void setup() {
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_IsTouchScreen;
    io.IniFilename = nullptr;
    ImGui_ImplAndroid_Init();
    ImGui_ImplOpenGL3_Init(nullptr);
    loadConfig();
    float s = std::min(std::max(g_TargetScale.load(), kMinScale), kMaxScale);
    applyFontAndStyle(s, false);
    g_AppliedScale = s;
    g_PendingScale = s;
    g_LastRebuild = nowSec();
    std::string z;
    if (readFile((std::string(kKurumiDir) + "zinput.txt").c_str(), z))
        std::snprintf(g_ZInput, sizeof(g_ZInput), "%s", z.c_str());
    g_Initialized = true;
}

// ------------------------------------------------------------ menu sync
void syncMenuOff() {
#if defined(HAVE_SET_MODULE_ENABLED)
    pl::modmenu::setModuleEnabled(std::string(kModuleId), false);
#endif
}

// ------------------------------------------------------------ on-screen keyboard
void kbAppend(const char* s) {
    if (!g_KbTarget) return;
    const size_t l = std::strlen(g_KbTarget), n = std::strlen(s);
    if (l + n + 1 <= g_KbSize) std::memcpy(g_KbTarget + l, s, n + 1);
}
void kbBackspace() {
    if (!g_KbTarget) return;
    size_t l = std::strlen(g_KbTarget);
    if (!l) return;
    do { --l; } while (l > 0 && ((unsigned char)g_KbTarget[l] & 0xC0) == 0x80);
    g_KbTarget[l] = 0;
}
void trackTarget(char* buf, size_t sz, const char* name) {   // InputText ke turant baad
    if (ImGui::IsItemActive()) { g_KbTarget = buf; g_KbSize = sz; g_KbName = name; }
}

float kbHeight(float S) { return 6.0f * (34.0f * S + ImGui::GetStyle().ItemSpacing.y) + 22.0f * S; }

void drawOnScreenKb(float S) {
    if (!g_KbTarget) { g_KbTarget = g_TextBuf; g_KbSize = sizeof(g_TextBuf); g_KbName = "Home"; }
    ImGui::TextDisabled("Keyboard -> %s", g_KbName);
    static const char* rows[] = { "1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm", "./-_:=\"'()" };
    const float sp = ImGui::GetStyle().ItemSpacing.x;
    const float bw = std::max(20.0f * S, (ImGui::GetContentRegionAvail().x - sp * 9) / 10.0f);
    const ImVec2 bsz(bw, 34.0f * S);
    ImGui::PushStyleColor(ImGuiCol_Text, C_BTN_TXT);
    for (int r = 0; r < 5; r++) {
        const char* row = rows[r];
        for (int i = 0; row[i]; i++) {
            if (i) ImGui::SameLine();
            char ch = row[i];
            if (g_KbShift && ch >= 'a' && ch <= 'z') ch = (char)(ch - 'a' + 'A');
            char lab[24]; std::snprintf(lab, sizeof(lab), "%c##k%d_%d", ch, r, i);
            if (ImGui::Button(lab, bsz)) { char one[2] = { ch, 0 }; kbAppend(one); }
        }
    }
    if (ImGui::Button(g_KbShift ? "SHIFT*##ksh" : "SHIFT##ksh", ImVec2(bw * 2 + sp, bsz.y))) g_KbShift = !g_KbShift;
    ImGui::SameLine();
    if (ImGui::Button(",##kc", bsz)) kbAppend(",");
    ImGui::SameLine();
    if (ImGui::Button("SPACE##ksp", ImVec2(bw * 3 + sp * 2, bsz.y))) kbAppend(" ");
    ImGui::SameLine();
    if (ImGui::Button("DEL##kbs", ImVec2(bw * 2 + sp, bsz.y))) kbBackspace();
    ImGui::SameLine();
    if (ImGui::Button("ENTER##ken", ImVec2(bw * 2 + sp, bsz.y))) kbAppend("\n");
    ImGui::PopStyleColor();
}

// ------------------------------------------------------------ section views
void viewHome(float S) {
    ImGui::PushStyleColor(ImGuiCol_Text, C_BTN_TXT);
    if (ImGui::Button(g_EffectOn ? "EFFECT: ON" : "EFFECT: OFF", ImVec2(-FLT_MIN, 44 * S)))
        g_EffectOn = !g_EffectOn;
    ImGui::PopStyleColor();
    ImGui::TextUnformatted("Type here");
    ImGui::SetNextItemWidth(-FLT_MIN);
    ImGui::InputTextWithHint("##home", "yahan likho...", g_TextBuf, sizeof(g_TextBuf));
    trackTarget(g_TextBuf, sizeof(g_TextBuf), "Home");
    ImGui::PushStyleColor(ImGuiCol_Text, C_BTN_TXT);
    if (ImGui::Button(g_KbOpen ? "On-screen KB: ON" : "On-screen KB: OFF")) g_KbOpen = !g_KbOpen;
    ImGui::PopStyleColor();
    ImGui::TextWrapped("Tumne likha: %s", g_TextBuf);
    ImGui::Separator();
    ImGui::TextDisabled("FPS: %.1f | Scale: %.2f | Opacity: %.0f%%",
                        ImGui::GetIO().Framerate, g_AppliedScale, g_Opacity * 100.0f);
    if (g_KbOpen) { ImGui::Separator(); drawOnScreenKb(S); }
}

void viewSettings(float S) {
    static bool dragging = false;
    if (!dragging) g_PendingScale = g_AppliedScale;
    ImGui::SetNextItemWidth(-FLT_MIN);
    ImGui::SliderFloat("##scale", &g_PendingScale, kMinScale, kMaxScale, "UI Scale %.2f");
    dragging = ImGui::IsItemActive();
    if (ImGui::IsItemDeactivatedAfterEdit()) g_TargetScale = g_PendingScale;   // chhodne par apply
    ImGui::TextDisabled("Slider chhodte hi poora panel bada/chhota hoga");
    ImGui::SetNextItemWidth(-FLT_MIN);
    ImGui::SliderFloat("##opacity", &g_Opacity, 0.2f, 1.0f, "Opacity %.2f");
    ImGui::Checkbox("Phone keyboard use karo (text box tap par)", &g_UseNativeKb);
    ImGui::PushStyleColor(ImGuiCol_Text, C_BTN_TXT);
    if (ImGui::Button("Save now", ImVec2(160 * S, 38 * S))) { saveConfig(); setStatus("Config saved"); }
    ImGui::PopStyleColor();
    ImGui::TextDisabled("Save: %spanel.cfg", kCfgDir);
    ImGui::TextDisabled("X = hide. Launcher toggle OFF->ON se wapas, same jagah.");
}

void viewTerminal(float S) {
    ImGui::TextDisabled("kurumi/zinput.txt editor (Run neeche)");
    float reserve = ImGui::GetFrameHeightWithSpacing() + 4 * S;
    if (g_KbOpen) reserve += kbHeight(S);
    float h = std::max(60.0f * S, ImGui::GetContentRegionAvail().y - reserve);
    ImGui::InputTextMultiline("##zin", g_ZInput, sizeof(g_ZInput), ImVec2(-FLT_MIN, h));
    trackTarget(g_ZInput, sizeof(g_ZInput), "zinput");
    ImGui::PushStyleColor(ImGuiCol_Text, C_BTN_TXT);
    if (ImGui::Button(g_KbOpen ? "On-screen KB: ON" : "On-screen KB: OFF")) g_KbOpen = !g_KbOpen;
    ImGui::PopStyleColor();
    if (g_KbOpen) drawOnScreenKb(S);
}

void viewOutput() {
    ImGui::Checkbox("Auto-scroll", &g_AutoScroll);
    ImGui::BeginChild("##out", ImVec2(0, 0), true);
    {
        std::lock_guard<std::mutex> l(g_SnapMx);
        ImGui::TextUnformatted(g_SnapOut.empty() ? "(abhi koi output nahi)" : g_SnapOut.c_str());
    }
    if (g_AutoScroll) ImGui::SetScrollHereY(1.0f);
    ImGui::EndChild();
}

void viewProcess() {
    std::string log;
    { std::lock_guard<std::mutex> l(g_SnapMx); log = g_SnapLog; }
    const size_t run = log.rfind("=== run");
    const size_t done = log.rfind("=== DONE");
    const char* state = (run == std::string::npos) ? "Idle"
                      : (done != std::string::npos && done > run) ? "Done" : "Running...";
    ImGui::Text("Engine state: %s", state);
    ImGui::TextDisabled("(state log ke '=== run' / '=== DONE' lines se guess hota hai)");
    ImGui::Separator();
    ImGui::BeginChild("##log", ImVec2(0, 0), true);
    ImGui::TextUnformatted(log.empty() ? "(log khali)" : log.c_str());
    ImGui::EndChild();
}

void viewConfig() {
    ImGui::TextDisabled("zaphkiel_config.txt (read-only)");
    ImGui::BeginChild("##cfg", ImVec2(0, 0), true);
    {
        std::lock_guard<std::mutex> l(g_SnapMx);
        ImGui::TextUnformatted(g_SnapCfg.empty() ? "(config nahi mili)" : g_SnapCfg.c_str());
    }
    ImGui::EndChild();
}

// ------------------------------------------------------------ main window
void drawMenu() {
    if (!g_Visible.load()) return;
    ImGuiIO& io = ImGui::GetIO();
    const float S = g_AppliedScale;
    const ImVec2 ds = io.DisplaySize;

    if (g_ApplyGeom) {
        float px = g_HavePos ? g_PosX : ds.x * 0.06f;
        float py = g_HavePos ? g_PosY : ds.y * 0.12f;
        px = std::min(std::max(px, 0.0f), std::max(0.0f, ds.x - 80.0f));
        py = std::min(std::max(py, 0.0f), std::max(0.0f, ds.y - 60.0f));
        ImGui::SetNextWindowPos(ImVec2(px, py), ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImVec2(g_BaseW * S, g_BaseH * S), ImGuiCond_Always);
        g_ApplyGeom = false; g_ScaleChanged = false;
    } else if (g_ScaleChanged) {
        ImGui::SetNextWindowSize(ImVec2(g_BaseW * S, g_BaseH * S), ImGuiCond_Always);
        g_ScaleChanged = false;
    }
    ImGui::SetNextWindowSizeConstraints(ImVec2(kMinBaseW * S, kMinBaseH * S),
                                        ImVec2(std::max(ds.x, 100.0f), std::max(ds.y, 100.0f)));
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, g_Opacity);

    bool open = true;
    ImGui::Begin("Mera Panel", &open, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings);

    const ImVec2 wp = ImGui::GetWindowPos(), wsz = ImGui::GetWindowSize();
    g_PosX = wp.x; g_PosY = wp.y; g_HavePos = true;
    g_BaseW = wsz.x / S; g_BaseH = wsz.y / S;
    g_RectX = wp.x; g_RectY = wp.y; g_RectW = wsz.x; g_RectH = wsz.y;

    const float footer = ImGui::GetFrameHeightWithSpacing() + 4 * S;

    // left: sections
    ImGui::BeginChild("##sec", ImVec2(150 * S, -footer), true);
    static const char* names[6] = { "1. Home", "2. Settings", "3. Terminal", "4. Output", "5. Process", "6. Config" };
    for (int i = 0; i < 6; i++) {
        const bool sel = (g_Section == i);
        if (sel) ImGui::PushStyleColor(ImGuiCol_Button, C_ACC_A);
        ImGui::PushStyleColor(ImGuiCol_Text, C_BTN_TXT);
        if (ImGui::Button(names[i], ImVec2(-FLT_MIN, 34 * S))) g_Section = i;
        ImGui::PopStyleColor();
        if (sel) ImGui::PopStyleColor();
    }
    ImGui::EndChild();

    // right: function area
    ImGui::SameLine();
    ImGui::BeginChild("##func", ImVec2(0, -footer), true);
    switch (g_Section) {
        case 0: viewHome(S); break;
        case 1: viewSettings(S); break;
        case 2: viewTerminal(S); break;
        case 3: viewOutput(); break;
        case 4: viewProcess(); break;
        case 5: viewConfig(); break;
    }
    ImGui::EndChild();

    // bottom bar
    ImGui::PushStyleColor(ImGuiCol_Text, C_BTN_TXT);
    if (ImGui::Button("Refresh")) g_RefreshNow = true;
    ImGui::SameLine();
    if (ImGui::Button("Run")) {
        mkdir(kKurumiDir, 0777);
        const std::string p = std::string(kKurumiDir) + "zinput.txt";
        if (writeFile(p.c_str(), g_ZInput, std::strlen(g_ZInput))) {
            setStatus("zinput likha - engine mtime se uthayega");
            g_RefreshNow = true;
        } else {
            setStatus("WRITE FAIL (folder/permission?)");
        }
    }
    ImGui::PopStyleColor();
    ImGui::SameLine();
    ImGui::BeginDisabled(true);
    ImGui::Button("Stop");
    ImGui::EndDisabled();
    if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled))
        ImGui::SetTooltip("File-bridge me stop nahi hota (v5: direct engine call)");
    ImGui::SameLine();
    ImGui::TextDisabled("%s", g_Status);

    ImGui::End();
    ImGui::PopStyleVar();

    // text-input state: native keyboard + key consume
    const bool typing = io.WantTextInput;
    g_WantText = typing;
    if (g_UseNativeKb) {
        if (typing && !g_KbShown) { pl::input::showKeyboard(); g_KbShown = true; }
        if (!typing && g_KbShown) { pl::input::hideKeyboard(); g_KbShown = false; }
    }

    // geometry autosave (2s me ek baar, sirf badla ho tab)
    const double t = nowSec();
    if (t - g_LastSave > 2.0) { g_LastSave = t; saveConfig(); }

    if (!open) {                        // X
        g_Visible = false;
        g_WantText = false;
        g_RectW = 0; g_RectH = 0;
        if (g_KbShown) { pl::input::hideKeyboard(); g_KbShown = false; }
        saveConfig();
        syncMenuOff();
    }
}

void render() {
    ImGuiIO& io = ImGui::GetIO();
    if (g_ResetInput.exchange(false)) {
        { std::lock_guard<std::mutex> l(g_QMutex); g_Queue.clear(); }
        g_ToRelease.clear();
        std::memset(io.KeysDown, 0, sizeof(io.KeysDown));
        io.AddMouseButtonEvent(0, false);
    }
    // scale badla? (debounce 0.25s) => font atlas + style rebuild, NewFrame se pehle
    const float tgt = std::min(std::max(g_TargetScale.load(), kMinScale), kMaxScale);
    const double t = nowSec();
    if (std::fabs(tgt - g_AppliedScale) > 0.005f && t - g_LastRebuild > 0.25) {
        applyFontAndStyle(tgt, g_DeviceReady);
        g_AppliedScale = tgt;
        g_LastRebuild = t;
        g_ScaleChanged = true;
    }
    flushInput(io);

    ImGui_ImplOpenGL3_NewFrame();
    g_DeviceReady = true;
    ImGui_ImplAndroid_NewFrame(g_Width, g_Height);
    ImGui::NewFrame();
    drawMenu();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

EGLBoolean hook_swap(EGLDisplay dpy, EGLSurface surf) {
    if (!g_OrigSwap) return EGL_FALSE;
    EGLContext ctx = eglGetCurrentContext();
    if (ctx == EGL_NO_CONTEXT) return g_OrigSwap(dpy, surf);
    EGLint w = 0, h = 0;
    eglQuerySurface(dpy, surf, EGL_WIDTH, &w);
    eglQuerySurface(dpy, surf, EGL_HEIGHT, &h);
    if (w < 500 || h < 500) return g_OrigSwap(dpy, surf);
    if (g_TargetContext == EGL_NO_CONTEXT) {
        EGLint buf = 0;
        eglQuerySurface(dpy, surf, EGL_RENDER_BUFFER, &buf);
        if (buf == EGL_BACK_BUFFER) { g_TargetContext = ctx; g_TargetSurface = surf; }
    }
    if (ctx != g_TargetContext || surf != g_TargetSurface) return g_OrigSwap(dpy, surf);
    g_Width = w; g_Height = h;

    if (g_Visible.load()) {
        if (!g_Initialized.load()) setup();
        render();
    } else if (g_KbShown) {
        pl::input::hideKeyboard();
        g_KbShown = false;
        g_WantText = false;
    }
    return g_OrigSwap(dpy, surf);
}

// ------------------------------------------------------------ background reader (UI thread pe file I/O nahi)
struct FileStamp { time_t mt = 0; off_t sz = -1; };
bool changed(const std::string& path, FileStamp& st, bool force) {
    struct stat s;
    if (stat(path.c_str(), &s) != 0) { bool was = st.sz != -1; st = FileStamp(); return was || force; }
    if (!force && s.st_mtime == st.mt && s.st_size == st.sz) return false;
    st.mt = s.st_mtime; st.sz = s.st_size;
    return true;
}

void bgReader() {
    FileStamp fo, fl, fc;
    const std::string po = std::string(kKurumiDir) + "zaphkiel_out.txt";
    const std::string pl_ = std::string(kKurumiDir) + "zaphkiel_log.txt";
    const std::string pc = std::string(kKurumiDir) + "zaphkiel_config.txt";
    for (;;) {
        const bool force = g_RefreshNow.exchange(false);
        if (force || g_Visible.load()) {
            std::string o, l, c;
            if (changed(po, fo, force)) { readTail(po.c_str(), o, 64 * 1024); std::lock_guard<std::mutex> k(g_SnapMx); g_SnapOut = o; }
            if (changed(pl_, fl, force)) { readTail(pl_.c_str(), l, 32 * 1024); std::lock_guard<std::mutex> k(g_SnapMx); g_SnapLog = l; }
            if (changed(pc, fc, force)) { readTail(pc.c_str(), c, 32 * 1024); std::lock_guard<std::mutex> k(g_SnapMx); g_SnapCfg = c; }
        }
        for (int i = 0; i < 15 && !g_RefreshNow.load(); i++) usleep(100000);   // ~1.5s ya refresh
    }
}

void* mainThread(void*) {
    sleep(3);
    void* egl = dlopen("libEGL.so", RTLD_NOW);
    if (egl) {
        void* swap = dlsym(egl, "eglSwapBuffers");
        if (swap)
            g_SwapHook = pl::memory::HookHandle(swap, (void*)&hook_swap, (void**)&g_OrigSwap);
        LOGI("EGL hook: %s", g_SwapHook.installed() ? "OK" : "FAIL");
    } else {
        LOGW("libEGL.so open fail");
    }
    std::thread(bgReader).detach();
    return nullptr;
}

// ------------------------------------------------------------ mod menu
void onToggle(std::string_view moduleId, bool enabled) {
    if (moduleId != kModuleId) return;
    if (enabled) {
        g_ApplyGeom = true;       // wahi purani position/size
        g_ResetInput = true;
        g_Visible = true;
    } else {
        g_Visible = false;
    }
}

template <class T>
std::string toStr(const T& v) {
    if constexpr (std::is_same_v<T, bool>) return v ? "1" : "0";
    else if constexpr (std::is_convertible_v<const T&, std::string_view>) return std::string(std::string_view(v));
    else if constexpr (std::is_arithmetic_v<T>) return std::to_string(v);
    else return std::string();
}

template <class... A>
void onConfig(const A&... a) {
    std::vector<std::string> v;
    (v.push_back(toStr(a)), ...);
    for (size_t i = 0; i + 1 < v.size(); ++i) {
        if (v[i] == "scale") {
            const float s = static_cast<float>(std::atof(v[i + 1].c_str()));
            if (s >= kMinScale && s <= kMaxScale) g_TargetScale = s;
            return;
        }
    }
}

struct CfgFn {
    template <class... A>
    void operator()(const A&... a) const { onConfig(a...); }
};

template <class B>
constexpr bool kHasCfgCallback = requires(B b) { b.onConfigChanged(CfgFn{}); };

template <class B>
B attachCfg(B b) {
    if constexpr (kHasCfgCallback<B>) {
        return b.onConfigChanged(CfgFn{});
    } else {
        return b;
    }
}

bool g_HasCfgCallback = false;

bool registerMenu(ll::mod::NativeMod& self) {
    auto b = pl::modmenu::ModuleBuilder(std::string(kModuleId), "Mera Panel")
                 .modId(self.getId())
                 .description("v4 panel. X dabane par hide; toggle OFF->ON se wapas.")
                 .defaultEnabled(false)
                 .onToggle(onToggle)
                 .config("scale", "Panel Size", pl::modmenu::ConfigType::SliderFloat,
                         "1.0", "0.8", "2.5");
    g_HasCfgCallback = kHasCfgCallback<pl::modmenu::ModuleBuilder>;
    b = attachCfg(b);
    return b.registerModule();
}

std::once_flag g_CbOnce;
std::once_flag g_HookOnce;

}  // namespace

class PanelMod {
public:
    static PanelMod& instance() { static PanelMod m; return m; }
    PanelMod() : mSelf(*ll::mod::NativeMod::current()) {}
    ll::mod::NativeMod& getSelf() const { return mSelf; }

    bool load() {
        getSelf().getLogger().info("PanelMod v4 loaded");
        return true;
    }

    bool enable() {
        std::call_once(g_CbOnce, [] {
            pl::input::registerTouchCallback(onTouch);
            pl::input::registerKeyCallback(onKey);
        });
        std::call_once(g_HookOnce, [] {
            pthread_t t;
            pthread_create(&t, nullptr, mainThread, nullptr);
        });
        const bool ok = registerMenu(getSelf());
        LOGI("Menu register: %s (cfg callback: %s)", ok ? "OK" : "FAIL",
             g_HasCfgCallback ? "yes" : "no");
        if (!ok) { g_ApplyGeom = true; g_Visible = true; }   // fallback: panel hamesha ON
        return true;
    }

    bool disable() {
        g_Visible = false;
        g_WantText = false;
        pl::modmenu::unregisterModule(kModuleId);
        return true;
    }

    bool unload() { return true; }

private:
    ll::mod::NativeMod& mSelf;
};

PL_REGISTER_MOD(PanelMod, PanelMod::instance())
