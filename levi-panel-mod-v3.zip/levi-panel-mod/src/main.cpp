// Levi Panel Mod v3
//  - Launcher Mod Menu toggle (ModuleBuilder) + "Panel Size" slider
//  - Cross (X) => panel band, toggle OFF (jahan SDK allow kare)
//  - Soft keyboard: InputText active => pl::input::showKeyboard()
//  - Panel geometry yaad rehti hai (cross karke wapas ON => wahi position/size)
//  - Touch/Key events official pl::input callbacks se (libinput hook ki zaroorat nahi)
#include <jni.h>
#include <android/input.h>
#include <android/keycodes.h>
#include <android/log.h>
#include <EGL/egl.h>
#include <pthread.h>
#include <unistd.h>
#include <dlfcn.h>

#include <algorithm>
#include <atomic>
#include <cfloat>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <string>
#include <string_view>
#include <type_traits>
#include <vector>

#include <pl/Mod.hpp>
#include <pl/ModMenu.hpp>
#include <pl/Input.hpp>
#include <pl/Logger.hpp>
#include <pl/memory/Hook.hpp>

#include "ImGui/imgui.h"
#include "ImGui/backends/imgui_impl_android.h"
#include "ImGui/backends/imgui_impl_opengl3.h"

#define TAG "PanelMod"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)

namespace {

constexpr std::string_view kModuleId = "panelmod.main";

// ---------------------------------------------------------------- tuning
constexpr float kBaseUI   = 1.6f;    // touch-friendly base multiplier
constexpr float kMinScale = 0.5f;
constexpr float kMaxScale = 2.5f;
constexpr float kDefBaseW = 250.0f;  // panel size in "base units" (pixels = units * effScale)
constexpr float kDefBaseH = 170.0f;
constexpr float kMinBaseW = 150.0f;
constexpr float kMinBaseH = 110.0f;

// ---------------------------------------------------------------- state
std::atomic_bool  g_Visible{false};      // == launcher toggle state
std::atomic_bool  g_Initialized{false};
std::atomic_bool  g_ResetInput{false};
std::atomic_bool  g_WantText{false};     // InputText active (render thread -> input thread)
std::atomic<float> g_Scale{1.0f};        // menu slider value (0.5 .. 2.5)

// panel rect for touch hit-testing (render thread writes, input thread reads)
std::atomic<float> g_RectX{0}, g_RectY{0}, g_RectW{0}, g_RectH{0};

// remembered geometry (render thread only)
float g_PosX = 0, g_PosY = 0;
float g_BaseW = kDefBaseW, g_BaseH = kDefBaseH;   // size / effScale
bool  g_HavePos = false;
bool  g_ApplyGeom = true;     // next shown frame: force saved pos+size
bool  g_ScaleChanged = false; // next frame: resize panel to new scale
float g_LastEff = -1.0f;
bool  g_KbShown = false;

int g_Width = 0, g_Height = 0;
EGLContext g_TargetContext = EGL_NO_CONTEXT;
EGLSurface g_TargetSurface = EGL_NO_SURFACE;

char g_TextBuf[256] = "";
bool g_EffectOn = false;

ImGuiStyle* g_BaseStyle = nullptr;

using SwapFn = EGLBoolean (*)(EGLDisplay, EGLSurface);
SwapFn g_OrigSwap = nullptr;
pl::memory::HookHandle g_SwapHook;

// ---------------------------------------------------------------- input queue
struct InEv {
    enum Type { Pos, Btn, Char, KeyDown, KeyUp } type;
    float x = 0, y = 0;
    bool down = false;
    unsigned int ch = 0;
    int code = 0;
};
std::mutex g_QMutex;
std::vector<InEv> g_Queue;
std::vector<int> g_ToRelease;   // render thread only

void pushEv(const InEv& e) {
    std::lock_guard<std::mutex> l(g_QMutex);
    if (g_Queue.size() < 512) g_Queue.push_back(e);
}

bool insideRect(float x, float y) {
    const float m = 6.0f;
    const float rx = g_RectX.load(), ry = g_RectY.load();
    const float rw = g_RectW.load(), rh = g_RectH.load();
    if (rw <= 0 || rh <= 0) return false;
    return x >= rx - m && x <= rx + rw + m && y >= ry - m && y <= ry + rh + m;
}

// touch: input thread only (g_Follow/g_Owned)
int  g_Follow = -1;
bool g_Owned = false;

bool onTouch(const pl::input::TouchEvent& e) {
    if (!g_Visible.load() || !g_Initialized.load()) {
        g_Follow = -1; g_Owned = false;
        return false;
    }
    const int act = e.action & 0xFF;
    const bool isDown = (act == AMOTION_EVENT_ACTION_DOWN || act == AMOTION_EVENT_ACTION_POINTER_DOWN);
    const bool isUp   = (act == AMOTION_EVENT_ACTION_UP || act == AMOTION_EVENT_ACTION_POINTER_UP ||
                         act == AMOTION_EVENT_ACTION_CANCEL);
    const bool isMove = (act == AMOTION_EVENT_ACTION_MOVE);

    if (isDown && g_Follow == -1) {
        g_Follow = e.pointerId;
        g_Owned = insideRect(e.x, e.y);          // panel pe shuru hua touch = panel ka
        InEv p; p.type = InEv::Pos; p.x = e.x; p.y = e.y; pushEv(p);
        InEv b; b.type = InEv::Btn; b.down = true; pushEv(b);
        return g_Owned;                          // consume => game ko nahi jayega
    }
    if (e.pointerId != g_Follow) return false;   // dusri ungli game ke liye
    if (isMove) {
        InEv p; p.type = InEv::Pos; p.x = e.x; p.y = e.y; pushEv(p);
        return g_Owned;
    }
    if (isUp) {
        InEv p; p.type = InEv::Pos; p.x = e.x; p.y = e.y; pushEv(p);
        InEv b; b.type = InEv::Btn; b.down = false; pushEv(b);
        const bool owned = g_Owned;
        g_Follow = -1; g_Owned = false;
        return owned;
    }
    return false;
}

bool isSystemKey(int k) {
    return k == AKEYCODE_BACK || k == AKEYCODE_HOME || k == AKEYCODE_POWER ||
           k == AKEYCODE_APP_SWITCH || k == AKEYCODE_VOLUME_UP ||
           k == AKEYCODE_VOLUME_DOWN || k == AKEYCODE_VOLUME_MUTE;
}

bool isEditKey(int k) {
    return k == AKEYCODE_DEL || k == AKEYCODE_FORWARD_DEL || k == AKEYCODE_ENTER ||
           k == AKEYCODE_NUMPAD_ENTER || k == AKEYCODE_DPAD_LEFT || k == AKEYCODE_DPAD_RIGHT ||
           k == AKEYCODE_DPAD_UP || k == AKEYCODE_DPAD_DOWN || k == AKEYCODE_MOVE_HOME ||
           k == AKEYCODE_MOVE_END || k == AKEYCODE_TAB;
}

bool onKey(const pl::input::KeyEvent& e) {
    if (!g_Visible.load() || !g_Initialized.load()) return false;
    if (!g_WantText.load()) return false;        // text box active nahi => game ko do
    if (isSystemKey(e.keyCode)) return false;

    if (e.isKeyDown && e.unicodeChar >= 32 && e.unicodeChar != 127) {
        InEv c; c.type = InEv::Char; c.ch = e.unicodeChar; pushEv(c);
    }
    if (isEditKey(e.keyCode) && e.keyCode >= 0 && e.keyCode < 512) {
        InEv k; k.type = e.isKeyDown ? InEv::KeyDown : InEv::KeyUp; k.code = e.keyCode; pushEv(k);
    }
    return true;                                 // typing ke time game ko keys nahi
}

void flushInput(ImGuiIO& io) {
    for (int c : g_ToRelease) if (c >= 0 && c < 512) io.KeysDown[c] = false;
    g_ToRelease.clear();

    std::vector<InEv> q;
    { std::lock_guard<std::mutex> l(g_QMutex); q.swap(g_Queue); }
    for (const InEv& e : q) {
        switch (e.type) {
            case InEv::Pos:     io.AddMousePosEvent(e.x, e.y); break;
            case InEv::Btn:     io.AddMouseButtonEvent(0, e.down); break;
            case InEv::Char:    io.AddInputCharacter(e.ch); break;
            case InEv::KeyDown: io.KeysDown[e.code] = true; break;
            case InEv::KeyUp:   g_ToRelease.push_back(e.code); break;   // 1 frame down rehne do
        }
    }
}

// ---------------------------------------------------------------- style / scale
float effScale() {
    float s = g_Scale.load();
    s = std::min(std::max(s, kMinScale), kMaxScale);
    return kBaseUI * s;
}

void buildBaseStyle() {
    ImGui::StyleColorsLight();
    ImGuiStyle& st = ImGui::GetStyle();
    st.Colors[ImGuiCol_Button]        = ImVec4(0.74f, 0.74f, 0.74f, 1.0f);  // grey
    st.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.30f, 0.69f, 0.31f, 1.0f);  // green
    st.Colors[ImGuiCol_ButtonActive]  = ImVec4(0.20f, 0.55f, 0.24f, 1.0f);
    st.TouchExtraPadding = ImVec2(4, 4);
    st.WindowRounding = 8.0f;
    st.FrameRounding  = 4.0f;
    st.GrabRounding   = 4.0f;
    g_BaseStyle = new ImGuiStyle(st);   // scale lagane se pehle ka clean copy
}

// style + font scale: NewFrame() se PEHLE call hona chahiye
void applyScaleIfChanged() {
    const float eff = effScale();
    if (g_LastEff > 0 && std::fabs(eff - g_LastEff) < 0.001f) return;
    ImGuiStyle& st = ImGui::GetStyle();
    st = *g_BaseStyle;
    st.ScaleAllSizes(eff);
    ImGui::GetIO().FontGlobalScale = eff;
    if (g_LastEff > 0) g_ScaleChanged = true;     // slider hila => panel bhi resize
    g_LastEff = eff;
}

void setup() {
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_IsTouchScreen;
    io.IniFilename = nullptr;
    ImGui_ImplAndroid_Init();
    ImGui_ImplOpenGL3_Init(nullptr);
    buildBaseStyle();
    g_Initialized = true;
}

// ---------------------------------------------------------------- menu sync
void syncMenuOff() {
#if defined(HAVE_SET_MODULE_ENABLED)
    pl::modmenu::setModuleEnabled(std::string(kModuleId), false);
#endif
}

// ---------------------------------------------------------------- draw
bool g_HasCfgCallback = false;   // set in registerMenu()

void drawMenu() {
    if (!g_Visible.load()) return;
    ImGuiIO& io = ImGui::GetIO();
    const float eff = effScale();
    const ImVec2 ds = io.DisplaySize;

    if (g_ApplyGeom) {
        float px = g_HavePos ? g_PosX : ds.x * 0.08f;
        float py = g_HavePos ? g_PosY : ds.y * 0.18f;
        px = std::min(std::max(px, 0.0f), std::max(0.0f, ds.x - 80.0f));
        py = std::min(std::max(py, 0.0f), std::max(0.0f, ds.y - 60.0f));
        ImGui::SetNextWindowPos(ImVec2(px, py), ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImVec2(g_BaseW * eff, g_BaseH * eff), ImGuiCond_Always);
        g_ApplyGeom = false;
        g_ScaleChanged = false;
    } else if (g_ScaleChanged) {
        ImGui::SetNextWindowSize(ImVec2(g_BaseW * eff, g_BaseH * eff), ImGuiCond_Always);
        g_ScaleChanged = false;
    }
    ImGui::SetNextWindowSizeConstraints(ImVec2(kMinBaseW * eff, kMinBaseH * eff),
                                        ImVec2(std::max(ds.x, 100.0f), std::max(ds.y, 100.0f)));

    bool open = true;
    ImGui::Begin("Mera Panel", &open, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings);

    // geometry yaad rakho + touch hit-rect update
    const ImVec2 wp = ImGui::GetWindowPos();
    const ImVec2 wsz = ImGui::GetWindowSize();
    g_PosX = wp.x; g_PosY = wp.y; g_HavePos = true;
    g_BaseW = wsz.x / eff; g_BaseH = wsz.y / eff;
    g_RectX = wp.x; g_RectY = wp.y; g_RectW = wsz.x; g_RectH = wsz.y;

    if (ImGui::Button(g_EffectOn ? "EFFECT: ON" : "EFFECT: OFF",
                      ImVec2(ImGui::GetContentRegionAvail().x, ImGui::GetFrameHeight() * 1.5f)))
        g_EffectOn = !g_EffectOn;

    ImGui::TextUnformatted("Type here");
    ImGui::SetNextItemWidth(-FLT_MIN);
    ImGui::InputTextWithHint("##txt", "yahan likho...", g_TextBuf, sizeof(g_TextBuf));
    const bool typing = ImGui::IsItemActive();
    g_WantText = typing;

    if (typing && !g_KbShown) { pl::input::showKeyboard(); g_KbShown = true; }
    if (!typing && g_KbShown) { pl::input::hideKeyboard(); g_KbShown = false; }

    ImGui::TextWrapped("Tumne likha: %s", g_TextBuf);

    if (!g_HasCfgCallback) {   // menu slider kaam na kare to backup slider
        float s = g_Scale.load();
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::SliderFloat("##size", &s, kMinScale, kMaxScale, "Size %.2f")) g_Scale = s;
    }

    ImGui::End();

    if (!open) {                       // cross dabaya
        g_Visible = false;
        g_WantText = false;
        g_RectW = 0; g_RectH = 0;
        if (g_KbShown) { pl::input::hideKeyboard(); g_KbShown = false; }
        syncMenuOff();                 // launcher toggle bhi OFF (agar SDK me API ho)
    }
}

void render() {
    ImGuiIO& io = ImGui::GetIO();
    if (g_ResetInput.exchange(false)) {
        { std::lock_guard<std::mutex> l(g_QMutex); g_Queue.clear(); }
        g_ToRelease.clear();
        std::memset(io.KeysDown, 0, sizeof(io.KeysDown));
        io.AddMouseButtonEvent(0, false);
    }
    applyScaleIfChanged();
    flushInput(io);

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(g_Width, g_Height);
    ImGui::NewFrame();
    drawMenu();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

EGLBoolean hook_swap(EGLDisplay dpy, EGLSurface surf) {
    if (!g_OrigSwap) return EGL_FALSE;
    EGLContext ctx = eglGetCurrentContext();
    if (ctx == EGL_NO_CONTEXT) return g_OrigSwap(dpy, surf);
    EGLint w = 0, h = 0;
    eglQuerySurface(dpy, surf, EGL_WIDTH, &w);
    eglQuerySurface(dpy, surf, EGL_HEIGHT, &h);
    if (w < 500 || h < 500) return g_OrigSwap(dpy, surf);
    if (g_TargetContext == EGL_NO_CONTEXT) {
        EGLint buf = 0;
        eglQuerySurface(dpy, surf, EGL_RENDER_BUFFER, &buf);
        if (buf == EGL_BACK_BUFFER) { g_TargetContext = ctx; g_TargetSurface = surf; }
    }
    if (ctx != g_TargetContext || surf != g_TargetSurface) return g_OrigSwap(dpy, surf);
    g_Width = w; g_Height = h;

    if (g_Visible.load()) {
        if (!g_Initialized.load()) setup();
        render();
    } else if (g_KbShown) {            // toggle OFF hua to keyboard bhi band
        pl::input::hideKeyboard();
        g_KbShown = false;
        g_WantText = false;
    }
    return g_OrigSwap(dpy, surf);
}

void* mainThread(void*) {
    sleep(3);   // game libs load hone do
    void* egl = dlopen("libEGL.so", RTLD_NOW);
    if (egl) {
        void* swap = dlsym(egl, "eglSwapBuffers");
        if (swap)
            g_SwapHook = pl::memory::HookHandle(swap, (void*)&hook_swap, (void**)&g_OrigSwap);
        LOGI("EGL hook: %s", g_SwapHook.installed() ? "OK" : "FAIL");
    } else {
        LOGW("libEGL.so open fail");
    }
    return nullptr;
}

// ---------------------------------------------------------------- mod menu callbacks
void onToggle(std::string_view moduleId, bool enabled) {
    if (moduleId != kModuleId) return;
    if (enabled) {
        g_ApplyGeom = true;            // wahi purani position/size
        g_ResetInput = true;
        g_Visible = true;
    } else {
        g_Visible = false;
    }
}

template <class T>
std::string toStr(const T& v) {
    if constexpr (std::is_same_v<T, bool>) return v ? "1" : "0";
    else if constexpr (std::is_convertible_v<const T&, std::string_view>) return std::string(std::string_view(v));
    else if constexpr (std::is_arithmetic_v<T>) return std::to_string(v);
    else return std::string();
}

// SDK ka exact callback signature header se alag ho sakta hai, isliye generic.
template <class... A>
void onConfig(const A&... a) {
    std::vector<std::string> v;
    (v.push_back(toStr(a)), ...);
    for (size_t i = 0; i + 1 < v.size(); ++i) {
        if (v[i] == "scale") {
            const float s = static_cast<float>(std::atof(v[i + 1].c_str()));
            if (s >= kMinScale && s <= kMaxScale) g_Scale = s;
            return;
        }
    }
}

struct CfgFn {
    template <class... A>
    void operator()(const A&... a) const { onConfig(a...); }
};

template <class B>
constexpr bool kHasCfgCallback = requires(B b) { b.onConfigChanged(CfgFn{}); };

template <class B>
B attachCfg(B b) {
    if constexpr (kHasCfgCallback<B>) {
        return b.onConfigChanged(CfgFn{});
    } else {
        return b;
    }
}

bool registerMenu(ll::mod::NativeMod& self) {
    auto b = pl::modmenu::ModuleBuilder(std::string(kModuleId), "Mera Panel")
                 .modId(self.getId())
                 .description("ImGui panel. Cross dabane par ye toggle OFF hota hai.")
                 .defaultEnabled(false)
                 .onToggle(onToggle)
                 .config("scale", "Panel Size", pl::modmenu::ConfigType::SliderFloat,
                         "1.0", "0.5", "2.5");
    g_HasCfgCallback = kHasCfgCallback<pl::modmenu::ModuleBuilder>;
    b = attachCfg(b);
    return b.registerModule();
}

std::once_flag g_CbOnce;
std::once_flag g_HookOnce;

}  // namespace

class PanelMod {
public:
    static PanelMod& instance() { static PanelMod m; return m; }
    PanelMod() : mSelf(*ll::mod::NativeMod::current()) {}
    ll::mod::NativeMod& getSelf() const { return mSelf; }

    bool load() {
        getSelf().getLogger().info("PanelMod v3 loaded");
        return true;
    }

    bool enable() {
        // input callbacks ka unregister API nahi hai => process me sirf 1 baar
        std::call_once(g_CbOnce, [] {
            pl::input::registerTouchCallback(onTouch);
            pl::input::registerKeyCallback(onKey);
        });
        std::call_once(g_HookOnce, [] {
            pthread_t t;
            pthread_create(&t, nullptr, mainThread, nullptr);
        });

        const bool ok = registerMenu(getSelf());
        LOGI("Menu register: %s (cfg callback: %s)", ok ? "OK" : "FAIL",
             g_HasCfgCallback ? "yes" : "no");
        if (!ok) {                      // fallback: panel hamesha ON
            g_ApplyGeom = true;
            g_Visible = true;
        }
        return true;
    }

    bool disable() {
        g_Visible = false;
        g_WantText = false;
        pl::modmenu::unregisterModule(kModuleId);
        return true;   // hooks fail-soft rehne do (mid-frame unhook = crash risk)
    }

    bool unload() { return true; }

private:
    ll::mod::NativeMod& mSelf;
};

PL_REGISTER_MOD(PanelMod, PanelMod::instance())
